import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  // Store quiz rooms
  const rooms = new Map<string, {
    quiz: any;
    players: Map<string, { name: string; score: number; completed: boolean; lastActive: number }>;
    createdAt: number;
  }>();

  // Cleanup inactive rooms every hour
  setInterval(() => {
    const now = Date.now();
    rooms.forEach((room, roomId) => {
      if (now - room.createdAt > 24 * 60 * 60 * 1000) { // 24 hours
        rooms.delete(roomId);
      }
    });
  }, 60 * 60 * 1000);

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join-room", ({ roomId, playerName, quiz }) => {
      if (!roomId || !playerName) return;
      
      const cleanRoomId = roomId.trim().toUpperCase();
      socket.join(cleanRoomId);
      
      if (!rooms.has(cleanRoomId)) {
        console.log(`Creating new room: ${cleanRoomId}`);
        rooms.set(cleanRoomId, {
          quiz: quiz,
          players: new Map(),
          createdAt: Date.now()
        });
      }

      const room = rooms.get(cleanRoomId)!;
      // If quiz is provided and room doesn't have one, set it (Host joining)
      if (quiz && !room.quiz) {
        room.quiz = quiz;
        console.log(`Quiz data set for room: ${cleanRoomId}`);
      }

      room.players.set(socket.id, { 
        name: playerName, 
        score: 0, 
        completed: false,
        lastActive: Date.now()
      });

      console.log(`Player ${playerName} joined room ${cleanRoomId}. Total players: ${room.players.size}`);

      // Broadcast updated player list to everyone in the room
      io.to(cleanRoomId).emit("room-update", {
        quiz: room.quiz,
        players: Array.from(room.players.entries()).map(([id, data]) => ({ id, ...data }))
      });
    });

    socket.on("update-score", ({ roomId, score, completed }) => {
      const cleanRoomId = roomId?.trim().toUpperCase();
      const room = rooms.get(cleanRoomId);
      if (room && room.players.has(socket.id)) {
        const player = room.players.get(socket.id)!;
        player.score = score;
        player.completed = completed;
        player.lastActive = Date.now();

        io.to(cleanRoomId).emit("room-update", {
          quiz: room.quiz,
          players: Array.from(room.players.entries()).map(([id, data]) => ({ id, ...data }))
        });
      }
    });

    socket.on("disconnect", () => {
      rooms.forEach((room, roomId) => {
        if (room.players.has(socket.id)) {
          room.players.delete(socket.id);
          if (room.players.size === 0) {
            rooms.delete(roomId);
          } else {
            io.to(roomId).emit("room-update", {
              quiz: room.quiz,
              players: Array.from(room.players.entries()).map(([id, data]) => ({ id, ...data }))
            });
          }
        }
      });
    });
  });

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
