import React, { useState, useEffect } from 'react';
import { Languages, ArrowRightLeft, Copy, Check, Loader2, Trash2, AlertCircle, Download } from 'lucide-react';
import { motion } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

type Language = 'English' | 'Hindi' | 'Hinglish';

export default function Translator() {
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [fromLang, setFromLang] = useState<Language>('English');
  const [toLang, setToLang] = useState<Language>('Hindi');
  const [isTranslating, setIsTranslating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('translator');
      if (savedState) {
        setInputText(savedState.inputText || '');
        setTranslatedText(savedState.translatedText || '');
        setFromLang(savedState.fromLang || 'English');
        setToLang(savedState.toLang || 'Hindi');
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('translator', { inputText, translatedText, fromLang, toLang, filename });
    }
  }, [inputText, translatedText, fromLang, toLang, filename, isLoaded]);

  const downloadTranslation = () => {
    if (translatedText) {
      const element = document.createElement('a');
      const file = new Blob([translatedText], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'translation', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    setIsTranslating(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `Translate the following text from ${fromLang} to ${toLang}. 
      If the target is Hinglish, it means Hindi written in English script (e.g., "How are you?" -> "Aap kaise hain?").
      Only return the translated text, nothing else.
      
      Text: ${inputText}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      setTranslatedText(response.text?.trim() || '');
    } catch (err: any) {
      setError(handleGeminiError(err));
    } finally {
      setIsTranslating(false);
    }
  };

  const swapLanguages = () => {
    setFromLang(toLang);
    setToLang(fromLang);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(translatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clearAll = () => {
    setInputText('');
    setTranslatedText('');
    setFilename('');
  };

  const languages: Language[] = ['English', 'Hindi', 'Hinglish'];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Languages className="w-5 h-5 text-blue-500" />
          <h2>AI Translator</h2>
        </div>
        <div className="flex items-center gap-2">
          {(inputText || translatedText) && (
            <button
              onClick={clearAll}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto">
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Source */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Source Text</label>
              <div className="flex items-center gap-2">
                <select
                  value={fromLang}
                  onChange={(e) => setFromLang(e.target.value as Language)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-bold text-blue-600 dark:text-blue-400 focus:border-blue-500 outline-none"
                >
                  {languages.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <span className="text-slate-400">→</span>
                <select
                  value={toLang}
                  onChange={(e) => setToLang(e.target.value as Language)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs font-bold text-blue-600 dark:text-blue-400 focus:border-blue-500 outline-none"
                >
                  {languages.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter text to translate..."
              className="w-full h-48 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900/30 outline-none resize-none text-sm leading-relaxed text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600 transition-all"
            />
            
            <div className="flex items-center gap-4">
              <button
                onClick={handleTranslate}
                disabled={!inputText.trim() || isTranslating}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-100 dark:shadow-none disabled:opacity-50 disabled:shadow-none"
              >
                {isTranslating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Languages className="w-5 h-5" />}
                Translate Now
              </button>
              <button
                onClick={swapLanguages}
                className="p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors shadow-sm"
                title="Swap Languages"
              >
                <ArrowRightLeft className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Target */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Translation</label>
              {translatedText && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadTranslation}
                    className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    title="Download translation"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            <div className="relative flex-1 min-h-[192px]">
              <div className="w-full h-full p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm leading-relaxed overflow-y-auto whitespace-pre-wrap text-slate-700 dark:text-slate-200 custom-scrollbar transition-colors">
                {isTranslating ? (
                  <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 italic">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Translating...
                  </div>
                ) : (
                  translatedText || <span className="text-slate-400 dark:text-slate-600 italic">Translation will appear here...</span>
                )}
              </div>
              {translatedText && (
                <div className="absolute bottom-2 right-2 flex gap-2">
                  <button
                    onClick={copyToClipboard}
                    className="p-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-lg shadow-sm hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                    title="Copy translation"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
