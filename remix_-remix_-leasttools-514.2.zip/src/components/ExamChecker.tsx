import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { ClipboardCheck, Upload, Loader2, Image as ImageIcon, Sparkles, Trash2, FileText, AlertCircle, CheckCircle2, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { cleanAIJsonResponse, getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';
import { Download } from 'lucide-react';

interface ExamResult {
  marksObtained: number;
  maxMarks: number;
  feedback: string;
  mistakes: string[];
  strengths: string[];
  suggestion: string;
}

export default function ExamChecker() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [maxMarks, setMaxMarks] = useState('10');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isOcrProcessing, setIsOcrProcessing] = useState(false);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('exam-checker');
      if (savedState) {
        setQuestion(savedState.question || '');
        setAnswer(savedState.answer || '');
        setMaxMarks(savedState.maxMarks || '10');
        setResult(savedState.result || null);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('exam-checker', { question, answer, maxMarks, result, filename });
    }
  }, [question, answer, maxMarks, result, filename, isLoaded]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageForOCR(file);
  };

  const processImageForOCR = async (file: File) => {
    setIsOcrProcessing(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const reader = new FileReader();
      
      const base64Promise = new Promise<string>((resolve) => {
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
      });

      const base64Data = await base64Promise;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            parts: [
              { inlineData: { mimeType: file.type, data: base64Data } },
              { text: "Extract all the handwritten or printed text from this image accurately. If it's an answer to a question, just provide the text of the answer." }
            ]
          }
        ]
      });

      const extractedText = response.text || '';
      setAnswer(prev => prev ? prev + '\n' + extractedText : extractedText);
    } catch (err) {
      const userMessage = handleGeminiError(err);
      setError(userMessage);
    } finally {
      setIsOcrProcessing(false);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const file = new File([blob], `pasted-image-${Math.random().toString(36).substring(7)}.png`, { type: blob.type });
            processImageForOCR(file);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const downloadResult = () => {
    if (result) {
      let content = `Exam Evaluation Result\n`;
      content += `======================\n\n`;
      content += `Question: ${question}\n\n`;
      content += `Student's Answer: ${answer}\n\n`;
      content += `Score: ${result.marksObtained} / ${result.maxMarks}\n\n`;
      content += `Feedback: ${result.feedback}\n\n`;
      content += `Strengths:\n${result.strengths.map(s => `- ${s}`).join('\n')}\n\n`;
      content += `Mistakes:\n${result.mistakes.map(m => `- ${m}`).join('\n')}\n\n`;
      content += `Suggestion: ${result.suggestion}\n`;

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'evaluation', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const checkAnswer = async () => {
    if (!question.trim() || !answer.trim()) {
      setError("Please enter both the question and the answer.");
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Evaluate the following exam answer.
        
        Question: ${question}
        Student's Answer: ${answer}
        Maximum Marks: ${maxMarks}
        
        Provide a detailed evaluation including marks obtained, specific mistakes, strengths, and suggestions for improvement.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              marksObtained: { type: Type.NUMBER },
              maxMarks: { type: Type.NUMBER },
              feedback: { type: Type.STRING },
              mistakes: { type: Type.ARRAY, items: { type: Type.STRING } },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              suggestion: { type: Type.STRING }
            },
            required: ["marksObtained", "maxMarks", "feedback", "mistakes", "strengths", "suggestion"]
          }
        }
      });

      const evaluation = cleanAIJsonResponse(response) as ExamResult;
      setResult(evaluation);
    } catch (err: any) {
      const userMessage = handleGeminiError(err);
      setError(userMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const clearAll = () => {
    setQuestion('');
    setAnswer('');
    setMaxMarks('10');
    setResult(null);
    setError(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ClipboardCheck className="w-5 h-5 text-indigo-500" />
          <h2>AI Exam Checker</h2>
        </div>
        <button
          onClick={clearAll}
          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          title="Clear all"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2 ml-1">
                <FileText className="w-4 h-4 text-slate-400 dark:text-slate-500" />
                Question
              </label>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Enter the exam question here..."
                className="w-full h-32 p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:focus:ring-indigo-900/30 outline-none transition-all resize-none text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between ml-1">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Award className="w-4 h-4 text-slate-400 dark:text-slate-500" />
                  Your Answer
                </label>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    <button onClick={() => document.getElementById('file-upload-exam')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                    {" or "}
                    <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                    {" an image"}
                  </p>
                  <input
                    id="file-upload-exam"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    disabled={isOcrProcessing}
                  />
                </div>
              </div>
              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="Type your answer here or scan an image..."
                className="w-full h-48 p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:focus:ring-indigo-900/30 outline-none transition-all resize-none text-sm text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600"
              />
            </div>

            <div className="flex items-end gap-4">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 ml-1">Maximum Marks</label>
                <input
                  type="number"
                  value={maxMarks}
                  onChange={(e) => setMaxMarks(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:focus:ring-indigo-900/30 outline-none transition-all text-sm text-slate-700 dark:text-slate-200"
                />
              </div>
              <button
                onClick={checkAnswer}
                disabled={isProcessing || !question || !answer}
                className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold flex items-center gap-2 transition-all shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50 disabled:shadow-none"
              >
                {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                Check Answer
              </button>
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-xl flex items-center gap-2 text-red-600 dark:text-red-400 text-sm"
              >
                <AlertCircle className="w-4 h-4" />
                {error}
              </motion.div>
            )}
          </div>

          {/* Result Section */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-700 dark:text-slate-300 block ml-1">Evaluation Result</label>
              {result && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadResult}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              )}
            </div>
            <div className="min-h-[400px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 relative overflow-hidden transition-colors shadow-inner">
              <AnimatePresence mode="wait">
                {isProcessing ? (
                  <motion.div 
                    key="loading"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 gap-4"
                  >
                    <div className="relative">
                      <Loader2 className="w-12 h-12 animate-spin text-indigo-500" />
                      <Sparkles className="w-6 h-6 text-indigo-400 absolute -top-2 -right-2 animate-pulse" />
                    </div>
                    <p className="text-sm font-medium animate-pulse">Evaluating your answer...</p>
                  </motion.div>
                ) : result ? (
                  <motion.div 
                    key="result"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-6"
                  >
                    {/* Score Card */}
                    <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between transition-colors">
                      <div>
                        <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">Score Obtained</p>
                        <div className="flex items-baseline gap-1">
                          <span className="text-4xl font-black text-indigo-600 dark:text-indigo-400">{result.marksObtained}</span>
                          <span className="text-slate-400 dark:text-slate-500 font-medium">/ {result.maxMarks}</span>
                        </div>
                      </div>
                      <div className={`p-4 rounded-2xl ${result.marksObtained / result.maxMarks >= 0.7 ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' : result.marksObtained / result.maxMarks >= 0.4 ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' : 'bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400'}`}>
                        {result.marksObtained / result.maxMarks >= 0.7 ? <Award className="w-8 h-8" /> : <AlertCircle className="w-8 h-8" />}
                      </div>
                    </div>

                    {/* Feedback */}
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                          Strengths
                        </h4>
                        <ul className="space-y-1">
                          {result.strengths.map((s, i) => (
                            <li key={i} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                              {s}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-red-500" />
                          Mistakes / Areas for Improvement
                        </h4>
                        <ul className="space-y-1">
                          {result.mistakes.map((m, i) => (
                            <li key={i} className="text-sm text-slate-600 dark:text-slate-400 flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
                              {m}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-4 bg-indigo-50/50 dark:bg-indigo-900/10 rounded-xl border border-indigo-100 dark:border-indigo-900/30 transition-colors">
                        <h4 className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2">Expert Suggestion</h4>
                        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic">"{result.suggestion}"</p>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50 text-center px-8">
                    <Award className="w-16 h-16 mb-4" />
                    <p className="text-sm">Submit your answer to see the detailed evaluation and marks.</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
