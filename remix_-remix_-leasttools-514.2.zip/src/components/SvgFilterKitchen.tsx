import React, { useState, useEffect } from 'react';
import { Copy, Check, RefreshCw, Wand2, Upload, Trash2, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function SvgFilterKitchen() {
  const [image, setImage] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'turbulence' | 'displacement' | 'matrix' | 'blur'>('turbulence');
  const [baseFrequency, setBaseFrequency] = useState(0.05);
  const [numOctaves, setNumOctaves] = useState(2);
  const [scale, setScale] = useState(20);
  const [blur, setBlur] = useState(5);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('svg-filter-kitchen');
      if (savedState) {
        setImage(savedState.image ?? null);
        setFilterType(savedState.filterType ?? 'turbulence');
        setBaseFrequency(savedState.baseFrequency ?? 0.05);
        setNumOctaves(savedState.numOctaves ?? 2);
        setScale(savedState.scale ?? 20);
        setBlur(savedState.blur ?? 5);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('svg-filter-kitchen', { image, filterType, baseFrequency, numOctaves, scale, blur });
    }
  }, [image, filterType, baseFrequency, numOctaves, scale, blur, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const getFilterId = () => `svg-filter-${filterType}`;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Wand2 className="w-5 h-5 text-indigo-500" />
          <h2>SVG Filter Kitchen</h2>
        </div>
        <div className="flex items-center gap-2">
          {image && (
            <button
              onClick={() => setImage(null)}
              className="p-2 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
              title="Clear Image"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => {
              setFilterType('turbulence');
              setBaseFrequency(0.05);
              setNumOctaves(2);
              setScale(20);
              setBlur(5);
            }}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Reset"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Filter Type</label>
              <div className="grid grid-cols-2 gap-2">
                {(['turbulence', 'displacement', 'matrix', 'blur'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setFilterType(t)}
                    className={`py-1.5 px-3 rounded-lg text-xs font-bold capitalize transition-all border ${filterType === t ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {filterType === 'turbulence' && (
              <>
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Base Frequency ({baseFrequency})</label>
                  <input 
                    type="range" min="0.001" max="0.2" step="0.001" 
                    value={baseFrequency} onChange={(e) => setBaseFrequency(parseFloat(e.target.value))}
                    className="w-1/2 accent-indigo-500"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Num Octaves ({numOctaves})</label>
                  <input 
                    type="range" min="1" max="5" step="1" 
                    value={numOctaves} onChange={(e) => setNumOctaves(parseInt(e.target.value))}
                    className="w-1/2 accent-indigo-500"
                  />
                </div>
              </>
            )}

            {filterType === 'displacement' && (
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Scale ({scale})</label>
                <input 
                  type="range" min="0" max="100" step="1" 
                  value={scale} onChange={(e) => setScale(parseInt(e.target.value))}
                  className="w-1/2 accent-indigo-500"
                />
              </div>
            )}

            {filterType === 'blur' && (
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Blur StdDev ({blur})</label>
                <input 
                  type="range" min="0" max="20" step="0.5" 
                  value={blur} onChange={(e) => setBlur(parseFloat(e.target.value))}
                  className="w-1/2 accent-indigo-500"
                />
              </div>
            )}
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">SVG Filters</h3>
            <p className="text-[10px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
              SVG filters allow for complex visual effects like noise, displacement, and color manipulation. 
              These effects are calculated mathematically and applied in real-time.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden">
          <svg width="0" height="0" className="absolute">
            <defs>
              <filter id="svg-filter-turbulence">
                <feTurbulence type="turbulence" baseFrequency={baseFrequency} numOctaves={numOctaves} result="noise" />
                <feColorMatrix in="noise" type="saturate" values="0" result="destat" />
                <feComponentTransfer in="destat" result="contrast">
                  <feFuncR type="linear" slope="2" intercept="-0.5" />
                  <feFuncG type="linear" slope="2" intercept="-0.5" />
                  <feFuncB type="linear" slope="2" intercept="-0.5" />
                </feComponentTransfer>
                <feComposite in="SourceGraphic" in2="contrast" operator="in" />
              </filter>
              <filter id="svg-filter-displacement">
                <feTurbulence type="fractalNoise" baseFrequency="0.01" numOctaves="2" result="noise" />
                <feDisplacementMap in="SourceGraphic" in2="noise" scale={scale} xChannelSelector="R" yChannelSelector="G" />
              </filter>
              <filter id="svg-filter-matrix">
                <feColorMatrix type="matrix" values="0.33 0.33 0.33 0 0 0.33 0.33 0.33 0 0 0.33 0.33 0.33 0 0 0 0 0 1 0" />
              </filter>
              <filter id="svg-filter-blur">
                <feGaussianBlur stdDeviation={blur} />
              </filter>
            </defs>
          </svg>

          {image ? (
            <img 
              src={image} 
              alt="Filtered" 
              className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
              style={{ filter: `url(#${getFilterId()})` }}
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto">
                <ImageIcon className="w-8 h-8 text-slate-400" />
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-500">Upload an image to start</p>
                <button 
                  onClick={() => document.getElementById('svg-filter-upload')?.click()}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
                >
                  Select Image
                </button>
                <input 
                  id="svg-filter-upload" 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="hidden" 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
