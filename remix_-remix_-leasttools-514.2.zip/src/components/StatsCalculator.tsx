import React, { useState, useEffect } from 'react';
import { Hash, Sigma, BarChart2, Activity, Trash2, Download } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

export default function StatsCalculator() {
  const [input, setInput] = useState('');
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('stats-calculator');
      if (savedState) {
        setInput(savedState.input || '');
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('stats-calculator', { input, filename });
    }
  }, [input, filename, isLoaded]);

  const calculateStats = () => {
    const numbers = input
      .split(/[\s,]+/)
      .map(n => parseFloat(n))
      .filter(n => !isNaN(n));

    if (numbers.length === 0) return null;

    // Mean
    const sum = numbers.reduce((a, b) => a + b, 0);
    const mean = sum / numbers.length;

    // Median
    const sorted = [...numbers].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    const median = sorted.length % 2 !== 0 
      ? sorted[mid] 
      : (sorted[mid - 1] + sorted[mid]) / 2;

    // Mode
    const counts: Record<number, number> = {};
    let maxCount = 0;
    numbers.forEach(n => {
      counts[n] = (counts[n] || 0) + 1;
      if (counts[n] > maxCount) maxCount = counts[n];
    });
    
    const modes = Object.keys(counts)
      .filter(k => counts[Number(k)] === maxCount)
      .map(Number);
    
    const mode = maxCount === 1 && numbers.length > 1 ? 'None' : modes.join(', ');

    // Additional stats
    const min = Math.min(...numbers);
    const max = Math.max(...numbers);
    const range = max - min;

    return { mean, median, mode, count: numbers.length, sum, min, max, range };
  };

  const stats = calculateStats();

  const downloadStats = () => {
    if (stats) {
      let content = `Statistics Report\n`;
      content += `=================\n\n`;
      content += `Input Data: ${input}\n\n`;
      content += `Mean: ${stats.mean}\n`;
      content += `Median: ${stats.median}\n`;
      content += `Mode: ${stats.mode}\n`;
      content += `Count: ${stats.count}\n`;
      content += `Sum: ${stats.sum}\n`;
      content += `Range: ${stats.range}\n`;
      content += `Min: ${stats.min}\n`;
      content += `Max: ${stats.max}\n`;

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'stats', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Sigma className="w-5 h-5 text-blue-600" />
          <h2>Stats Calculator</h2>
        </div>
        <div className="flex items-center gap-2">
          {stats && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-blue-500 outline-none text-slate-700 dark:text-slate-200"
                />
                <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
              </div>
              <button
                onClick={downloadStats}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                title="Download Stats"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          )}
          {input && (
            <button
              onClick={() => setInput('')}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear input"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Enter Numbers</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter numbers separated by spaces or commas (e.g., 10, 20, 30, 40)..."
            className="w-full h-32 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900/30 outline-none resize-none text-sm font-mono leading-relaxed text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
          />
          <p className="text-[10px] text-slate-400 dark:text-slate-500 italic ml-1">Tip: You can paste a list of numbers from Excel or any text file.</p>
        </div>

        {stats ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl border border-blue-100 dark:border-blue-900/30 transition-colors">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 mb-1">
                <Activity className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Mean</span>
              </div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.mean.toLocaleString(undefined, { maximumFractionDigits: 4 })}</p>
            </div>
            <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-xl border border-indigo-100 dark:border-indigo-900/30 transition-colors">
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 mb-1">
                <BarChart2 className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Median</span>
              </div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.median.toLocaleString()}</p>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-900/30 transition-colors">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 mb-1">
                <Hash className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Mode</span>
              </div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white">{stats.mode}</p>
            </div>

            {/* Secondary Stats */}
            <div className="sm:col-span-3 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800 transition-colors">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase mb-1">Count</p>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{stats.count}</p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800 transition-colors">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase mb-1">Sum</p>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{stats.sum.toLocaleString()}</p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800 transition-colors">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase mb-1">Range</p>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{stats.range.toLocaleString()}</p>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-lg border border-slate-100 dark:border-slate-800 transition-colors">
                <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase mb-1">Min / Max</p>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{stats.min} / {stats.max}</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-40 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl transition-colors">
            <Sigma className="w-8 h-8 mb-2 opacity-20" />
            <p className="text-sm">Enter numbers to see statistics</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
