import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Settings, Volume2, VolumeX, Coffee, Brain, Bell, Wind, Waves, Trees as Tree, CloudRain as Rain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

type TimerMode = 'work' | 'shortBreak' | 'longBreak';

interface TimerSettings {
  work: number;
  shortBreak: number;
  longBreak: number;
  autoStart: boolean;
}

export default function PomodoroTimer() {
  const [mode, setMode] = useState<TimerMode>('work');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [settings, setSettings] = useState<TimerSettings>({
    work: 25,
    shortBreak: 5,
    longBreak: 15,
    autoStart: false
  });
  const [showSettings, setShowSettings] = useState(false);
  const [noiseType, setNoiseType] = useState<'none' | 'white' | 'pink' | 'brown'>('none');
  const [volume, setVolume] = useState(0.5);
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseNodeRef = useRef<AudioNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Initialize settings from DB
  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('pomodoro-timer');
      if (saved) {
        setSettings(saved.settings || { work: 25, shortBreak: 5, longBreak: 15, autoStart: false });
        setVolume(saved.volume ?? 0.5);
      }
    };
    init();
  }, []);

  // Save settings to DB
  useEffect(() => {
    saveToolState('pomodoro-timer', { settings, volume });
  }, [settings, volume]);

  // Timer logic
  useEffect(() => {
    let interval: number | undefined;

    if (isActive && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimerComplete();
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const handleTimerComplete = () => {
    setIsActive(false);
    playAlarm();
    
    if (mode === 'work') {
      setMode('shortBreak');
      setTimeLeft(settings.shortBreak * 60);
    } else {
      setMode('work');
      setTimeLeft(settings.work * 60);
    }

    if (settings.autoStart) {
      setIsActive(true);
    }
  };

  const playAlarm = () => {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.5);
    
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  };

  // Noise Generation
  const stopNoise = () => {
    if (noiseNodeRef.current) {
      noiseNodeRef.current.disconnect();
      noiseNodeRef.current = null;
    }
    setNoiseType('none');
  };

  const startNoise = (type: 'white' | 'pink' | 'brown') => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') ctx.resume();

    stopNoise();

    const bufferSize = 2 * ctx.sampleRate;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = buffer.getChannelData(0);

    if (type === 'white') {
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
    } else if (type === 'pink') {
      let b0, b1, b2, b3, b4, b5, b6;
      b0 = b1 = b2 = b3 = b4 = b5 = b6 = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.11; // (roughly) compensate for gain
        b6 = white * 0.115926;
      }
    } else if (type === 'brown') {
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        const out = (lastOut + (0.02 * white)) / 1.02;
        output[i] = out * 3.5;
        lastOut = out;
      }
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;

    if (!gainNodeRef.current) {
      gainNodeRef.current = ctx.createGain();
      gainNodeRef.current.connect(ctx.destination);
    }
    gainNodeRef.current.gain.value = volume;

    source.connect(gainNodeRef.current);
    source.start();
    noiseNodeRef.current = source;
    setNoiseType(type);
  };

  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = volume;
    }
  }, [volume]);

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(settings[mode] * 60);
  };

  const switchMode = (newMode: TimerMode) => {
    setMode(newMode);
    setIsActive(false);
    setTimeLeft(settings[newMode] * 60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = (timeLeft / (settings[mode] * 60)) * 100;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Brain className="w-5 h-5 text-red-500" />
          <h2>Pomodoro Focus Timer</h2>
        </div>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      <div className="p-8 flex flex-col items-center justify-center flex-1 gap-12 overflow-y-auto custom-scrollbar">
        {/* Mode Switcher */}
        <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl gap-1">
          {(['work', 'shortBreak', 'longBreak'] as const).map((m) => (
            <button
              key={m}
              onClick={() => switchMode(m)}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === m 
                  ? 'bg-white dark:bg-slate-700 text-red-500 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              {m === 'work' ? 'Focus' : m === 'shortBreak' ? 'Short Break' : 'Long Break'}
            </button>
          ))}
        </div>

        {/* Timer Display */}
        <div className="relative flex items-center justify-center">
          <svg className="w-64 h-64 -rotate-90">
            <circle
              cx="128"
              cy="128"
              r="120"
              className="stroke-slate-200 dark:stroke-slate-800 fill-none"
              strokeWidth="8"
            />
            <motion.circle
              cx="128"
              cy="128"
              r="120"
              className="stroke-red-500 fill-none"
              strokeWidth="8"
              strokeDasharray="753.98"
              animate={{ strokeDashoffset: 753.98 * (1 - progress / 100) }}
              transition={{ duration: 1, ease: "linear" }}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-6xl font-mono font-bold text-slate-800 dark:text-slate-100 tabular-nums">
              {formatTime(timeLeft)}
            </span>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">
              {mode === 'work' ? 'Time to Focus' : 'Take a Break'}
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6">
          <button
            onClick={resetTimer}
            className="p-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
          >
            <RotateCcw className="w-6 h-6" />
          </button>
          <button
            onClick={toggleTimer}
            className="w-20 h-20 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-xl shadow-red-500/20 transition-all hover:scale-105 active:scale-95"
          >
            {isActive ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
          </button>
          <div className="w-6 h-6" /> {/* Spacer */}
        </div>

        {/* Nature Sounds / Noise */}
        <div className="w-full max-w-md space-y-4">
          <div className="flex items-center justify-between px-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Focus Sounds</label>
            <div className="flex items-center gap-2">
              <Volume2 className="w-3 h-3 text-slate-400" />
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={volume} 
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-20 h-1 accent-red-500"
              />
            </div>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={stopNoise}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                noiseType === 'none' 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-500' 
                  : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-red-200'
              }`}
            >
              <VolumeX className="w-4 h-4" />
              <span className="text-[10px] font-bold">None</span>
            </button>
            <button
              onClick={() => startNoise('white')}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                noiseType === 'white' 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-500' 
                  : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-red-200'
              }`}
            >
              <Wind className="w-4 h-4" />
              <span className="text-[10px] font-bold">White</span>
            </button>
            <button
              onClick={() => startNoise('pink')}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                noiseType === 'pink' 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-500' 
                  : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-red-200'
              }`}
            >
              <Rain className="w-4 h-4" />
              <span className="text-[10px] font-bold">Pink</span>
            </button>
            <button
              onClick={() => startNoise('brown')}
              className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                noiseType === 'brown' 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-500' 
                  : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-400 hover:border-red-200'
              }`}
            >
              <Waves className="w-4 h-4" />
              <span className="text-[10px] font-bold">Brown</span>
            </button>
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-slate-100/95 dark:bg-slate-900/95 p-8 flex flex-col"
          >
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Timer Settings</h3>
              <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600">
                <Pause className="w-5 h-5 rotate-45" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Focus</label>
                  <input
                    type="number"
                    value={settings.work}
                    onChange={(e) => setSettings({ ...settings, work: parseInt(e.target.value) || 1 })}
                    className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-center font-bold"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Short</label>
                  <input
                    type="number"
                    value={settings.shortBreak}
                    onChange={(e) => setSettings({ ...settings, shortBreak: parseInt(e.target.value) || 1 })}
                    className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-center font-bold"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Long</label>
                  <input
                    type="number"
                    value={settings.longBreak}
                    onChange={(e) => setSettings({ ...settings, longBreak: parseInt(e.target.value) || 1 })}
                    className="w-full p-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-center font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                <div className="space-y-1">
                  <p className="text-sm font-bold text-slate-700 dark:text-slate-200">Auto-start Breaks</p>
                  <p className="text-[10px] text-slate-500">Automatically start the next timer</p>
                </div>
                <button
                  onClick={() => setSettings({ ...settings, autoStart: !settings.autoStart })}
                  className={`w-12 h-6 rounded-full transition-all relative ${
                    settings.autoStart ? 'bg-red-500' : 'bg-slate-300 dark:bg-slate-600'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                    settings.autoStart ? 'left-7' : 'left-1'
                  }`} />
                </button>
              </div>
            </div>

            <button
              onClick={() => {
                setShowSettings(false);
                resetTimer();
              }}
              className="mt-auto w-full py-4 bg-red-500 text-white rounded-2xl font-bold shadow-lg shadow-red-500/20"
            >
              Apply Changes
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
