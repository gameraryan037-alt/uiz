import React, { useState, useEffect } from 'react';
import { Copy, Check, RefreshCw, Grid, Circle, Square, Hash } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function CssPatternMaker() {
  const [type, setType] = useState<'polka' | 'stripes' | 'checkers' | 'grid'>('polka');
  const [color1, setColor1] = useState('#ffffff');
  const [color2, setColor2] = useState('#6366f1');
  const [scale, setScale] = useState(40);
  const [opacity, setOpacity] = useState(0.2);
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('css-pattern-maker');
      if (savedState) {
        setType(savedState.type ?? 'polka');
        setColor1(savedState.color1 ?? '#ffffff');
        setColor2(savedState.color2 ?? '#6366f1');
        setScale(savedState.scale ?? 40);
        setOpacity(savedState.opacity ?? 0.2);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('css-pattern-maker', { type, color1, color2, scale, opacity });
    }
  }, [type, color1, color2, scale, opacity, isLoaded]);

  const hexToRgba = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  const getPatternStyle = () => {
    const c1 = hexToRgba(color1, 1);
    const c2 = hexToRgba(color2, opacity);
    const s = scale;

    switch (type) {
      case 'polka':
        return {
          backgroundColor: c1,
          backgroundImage: `radial-gradient(${c2} ${s / 10}px, transparent ${s / 10}px)`,
          backgroundSize: `${s}px ${s}px`,
        };
      case 'stripes':
        return {
          backgroundColor: c1,
          backgroundImage: `linear-gradient(45deg, ${c2} 25%, transparent 25%, transparent 50%, ${c2} 50%, ${c2} 75%, transparent 75%, transparent)`,
          backgroundSize: `${s}px ${s}px`,
        };
      case 'checkers':
        return {
          backgroundColor: c1,
          backgroundImage: `linear-gradient(45deg, ${c2} 25%, transparent 25%), linear-gradient(-45deg, ${c2} 25%, transparent 25%), linear-gradient(45deg, transparent 75%, ${c2} 75%), linear-gradient(-45deg, transparent 75%, ${c2} 75%)`,
          backgroundSize: `${s}px ${s}px`,
          backgroundPosition: `0 0, 0 ${s / 2}px, ${s / 2}px -${s / 2}px, -${s / 2}px 0px`,
        };
      case 'grid':
        return {
          backgroundColor: c1,
          backgroundImage: `linear-gradient(${c2} 1px, transparent 1px), linear-gradient(90deg, ${c2} 1px, transparent 1px)`,
          backgroundSize: `${s}px ${s}px`,
        };
      default:
        return {};
    }
  };

  const cssCode = `background-color: ${hexToRgba(color1, 1)};
background-image: ${getPatternStyle().backgroundImage};
background-size: ${scale}px ${scale}px;`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(cssCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Grid className="w-5 h-5 text-indigo-500" />
          <h2>CSS Pattern Maker</h2>
        </div>
        <button
          onClick={() => {
            setType('polka');
            setColor1('#ffffff');
            setColor2('#6366f1');
            setScale(40);
            setOpacity(0.2);
          }}
          className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
          title="Reset"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pattern Type</label>
              <div className="flex gap-2">
                {(['polka', 'stripes', 'checkers', 'grid'] as const).map((t) => (
                  <button 
                    key={t}
                    onClick={() => setType(t)}
                    className={`p-2 rounded-lg border transition-all ${type === t ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                  >
                    {t === 'polka' && <Circle className="w-4 h-4" />}
                    {t === 'stripes' && <Hash className="w-4 h-4" />}
                    {t === 'checkers' && <Square className="w-4 h-4" />}
                    {t === 'grid' && <Grid className="w-4 h-4" />}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Scale ({scale}px)</label>
              <input 
                type="range" min="10" max="200" step="1" 
                value={scale} onChange={(e) => setScale(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pattern Opacity ({opacity})</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={opacity} onChange={(e) => setOpacity(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Background Color</label>
              <input 
                type="color" 
                value={color1} onChange={(e) => setColor1(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pattern Color</label>
              <input 
                type="color" 
                value={color2} onChange={(e) => setColor2(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">CSS Output</label>
              <button 
                onClick={copyToClipboard}
                className="text-xs flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied!' : 'Copy CSS'}
              </button>
            </div>
            <pre className="p-4 bg-slate-950 text-indigo-300 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800 max-h-[200px]">
              {cssCode}
            </pre>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[300px] overflow-hidden relative">
          <div 
            style={getPatternStyle()} 
            className="absolute inset-0 transition-all duration-300"
          />
          <div className="relative z-10 bg-white/80 dark:bg-slate-900/80 p-4 rounded-xl backdrop-blur-sm border border-white/20 dark:border-slate-800/20 shadow-xl">
            <span className="text-slate-900 dark:text-white font-bold text-xs uppercase tracking-widest">Pattern Preview</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
