import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { QrCode, Download, Copy, Check, Trash2, Link as LinkIcon, Type, Wifi, Mail, Phone, Share2, Palette, Settings2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

type QRType = 'url' | 'text' | 'wifi' | 'email' | 'phone';

interface QRState {
  type: QRType;
  value: string;
  fgColor: string;
  bgColor: string;
  level: 'L' | 'M' | 'Q' | 'H';
  includeMargin: boolean;
  size: number;
}

export default function QRCodeGenerator() {
  const [qrState, setQrState] = useState<QRState>({
    type: 'url',
    value: 'https://leasttools.com',
    fgColor: '#000000',
    bgColor: '#ffffff',
    level: 'M',
    includeMargin: true,
    size: 256,
  });

  const [copied, setCopied] = useState(false);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const qrRef = useRef<SVGSVGElement>(null);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('qr-generator');
      if (savedState) {
        setQrState(savedState.qrState || savedState); // Handle old format
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('qr-generator', { ...qrState, filename });
    }
  }, [qrState, filename, isLoaded]);

  const handleDownload = () => {
    if (!qrRef.current) return;
    
    const svg = qrRef.current;
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      canvas.width = qrState.size;
      canvas.height = qrState.size;
      ctx?.drawImage(img, 0, 0);
      const pngFile = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.download = getDownloadFilename(filename, 'qrcode', 'png');
      downloadLink.href = pngFile;
      downloadLink.click();
    };
    
    img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(qrState.value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const updateState = (updates: Partial<QRState>) => {
    setQrState(prev => ({ ...prev, ...updates }));
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <QrCode className="w-5 h-5 text-indigo-500" />
          <h2>QR Code Generator</h2>
        </div>
        <button
          onClick={() => updateState({ value: '' })}
          className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          title="Clear"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Controls Section */}
          <div className="space-y-6">
            {/* Type Selection */}
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'url', icon: LinkIcon, label: 'URL' },
                { id: 'text', icon: Type, label: 'Text' },
                { id: 'wifi', icon: Wifi, label: 'WiFi' },
                { id: 'email', icon: Mail, label: 'Email' },
                { id: 'phone', icon: Phone, label: 'Phone' },
              ].map((type) => (
                <button
                  key={type.id}
                  onClick={() => updateState({ type: type.id as QRType })}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    qrState.type === type.id
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <type.icon className="w-4 h-4" />
                  {type.label}
                </button>
              ))}
            </div>

            {/* Input Section */}
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2">
                  <Share2 className="w-4 h-4" />
                  {qrState.type === 'url' ? 'Website URL' : 
                   qrState.type === 'text' ? 'Text Content' :
                   qrState.type === 'wifi' ? 'WiFi Details' :
                   qrState.type === 'email' ? 'Email Address' : 'Phone Number'}
                </label>
                <textarea
                  value={qrState.value}
                  onChange={(e) => updateState({ value: e.target.value })}
                  placeholder={
                    qrState.type === 'url' ? 'https://example.com' :
                    qrState.type === 'text' ? 'Enter your message here...' :
                    qrState.type === 'wifi' ? 'WIFI:S:NetworkName;T:WPA;P:Password;;' :
                    qrState.type === 'email' ? 'mailto:hello@example.com' : 'tel:+1234567890'
                  }
                  className="w-full px-4 py-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200 min-h-[100px] resize-none transition-all"
                />
              </div>

              {/* Customization Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <Palette className="w-3 h-3" />
                    Foreground
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={qrState.fgColor}
                      onChange={(e) => updateState({ fgColor: e.target.value })}
                      className="w-8 h-8 rounded cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={qrState.fgColor}
                      onChange={(e) => updateState({ fgColor: e.target.value })}
                      className="flex-1 px-2 py-1 text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded text-slate-600 dark:text-slate-400"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-2">
                    <Palette className="w-3 h-3" />
                    Background
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={qrState.bgColor}
                      onChange={(e) => updateState({ bgColor: e.target.value })}
                      className="w-8 h-8 rounded cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={qrState.bgColor}
                      onChange={(e) => updateState({ bgColor: e.target.value })}
                      className="flex-1 px-2 py-1 text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded text-slate-600 dark:text-slate-400"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-2">
                  <Settings2 className="w-3 h-3" />
                  Error Correction Level
                </label>
                <div className="flex gap-2">
                  {['L', 'M', 'Q', 'H'].map((level) => (
                    <button
                      key={level}
                      onClick={() => updateState({ level: level as any })}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        qrState.level === level
                          ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      {level === 'L' ? 'Low (7%)' : 
                       level === 'M' ? 'Medium (15%)' :
                       level === 'Q' ? 'Quartile (25%)' : 'High (30%)'}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Preview Section */}
          <div className="flex flex-col items-center justify-center space-y-6">
            <div className="relative p-8 bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl transition-all group">
              <div className="absolute inset-0 bg-indigo-500/5 dark:bg-indigo-500/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <QRCodeSVG
                  ref={qrRef}
                  value={qrState.value || ' '}
                  size={qrState.size}
                  fgColor={qrState.fgColor}
                  bgColor={qrState.bgColor}
                  level={qrState.level}
                  includeMargin={qrState.includeMargin}
                />
              </div>
            </div>

            <div className="flex flex-col gap-3 w-full max-w-xs">
              <div className="relative w-full">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-full px-4 py-2 text-sm border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200 transition-all"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-slate-400 dark:text-slate-600 pointer-events-none">.png</span>
              </div>
              <div className="flex gap-3 w-full">
                <button
                  onClick={copyToClipboard}
                  className="flex-1 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-750 transition-all shadow-sm"
                >
                  {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy Link'}
                </button>
                <button
                  onClick={handleDownload}
                  className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg"
                >
                  <Download className="w-4 h-4" />
                  Download
                </button>
              </div>
            </div>

            <p className="text-[10px] text-slate-400 dark:text-slate-600 text-center max-w-[200px]">
              Tip: For images and videos, upload them to a hosting service and paste the link here.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
