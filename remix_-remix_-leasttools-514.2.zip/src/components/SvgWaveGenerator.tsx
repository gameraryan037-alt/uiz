import React, { useState, useEffect } from 'react';
import { Copy, Check, RefreshCw, Waves, Square, Circle } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function SvgWaveGenerator() {
  const [type, setType] = useState<'wave' | 'blob'>('wave');
  const [complexity, setComplexity] = useState(5);
  const [randomness, setRandomness] = useState(50);
  const [color, setColor] = useState('#6366f1');
  const [opacity, setOpacity] = useState(1);
  const [seed, setSeed] = useState(Math.random());
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('svg-wave-generator');
      if (savedState) {
        setType(savedState.type ?? 'wave');
        setComplexity(savedState.complexity ?? 5);
        setRandomness(savedState.randomness ?? 50);
        setColor(savedState.color ?? '#6366f1');
        setOpacity(savedState.opacity ?? 1);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('svg-wave-generator', { type, complexity, randomness, color, opacity });
    }
  }, [type, complexity, randomness, color, opacity, isLoaded]);

  const generatePath = () => {
    const width = 1000;
    const height = 500;
    
    if (type === 'wave') {
      const step = width / complexity;
      const points = [];
      for (let i = 0; i <= complexity; i++) {
        const x = i * step;
        const y = height / 2 + (Math.sin(i + seed * 10) * randomness * 2);
        points.push({ x, y });
      }
      
      let path = `M 0 ${height} L 0 ${points[0].y}`;
      for (let i = 0; i < points.length - 1; i++) {
        const x_mid = (points[i].x + points[i + 1].x) / 2;
        const y_mid = (points[i].y + points[i + 1].y) / 2;
        path += ` Q ${points[i].x} ${points[i].y} ${x_mid} ${y_mid}`;
      }
      path += ` L ${width} ${points[points.length - 1].y} L ${width} ${height} Z`;
      return path;
    } else {
      // Blob
      const centerX = width / 2;
      const centerY = height / 2;
      const radius = 150;
      const points = [];
      const angleStep = (Math.PI * 2) / complexity;
      
      for (let i = 0; i < complexity; i++) {
        const angle = i * angleStep;
        const r = radius + (Math.sin(i * 3 + seed * 5) * randomness);
        const x = centerX + Math.cos(angle) * r;
        const y = centerY + Math.sin(angle) * r;
        points.push({ x, y });
      }
      
      let path = `M ${points[0].x} ${points[0].y}`;
      for (let i = 0; i < points.length; i++) {
        const next = points[(i + 1) % points.length];
        const nextNext = points[(i + 2) % points.length];
        const x_mid = (next.x + nextNext.x) / 2;
        const y_mid = (next.y + nextNext.y) / 2;
        path += ` Q ${next.x} ${next.y} ${x_mid} ${y_mid}`;
      }
      path += ' Z';
      return path;
    }
  };

  const path = generatePath();
  const svgCode = `<svg viewBox="0 0 1000 500" xmlns="http://www.w3.org/2000/svg">
  <path d="${path}" fill="${color}" fill-opacity="${opacity}" />
</svg>`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(svgCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Waves className="w-5 h-5 text-indigo-500" />
          <h2>SVG Wave/Blob Generator</h2>
        </div>
        <button
          onClick={() => setSeed(Math.random())}
          className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
          title="Regenerate"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Type</label>
              <div className="flex gap-2">
                <button 
                  onClick={() => setType('wave')}
                  className={`p-2 rounded-lg border transition-all ${type === 'wave' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                >
                  <Waves className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setType('blob')}
                  className={`p-2 rounded-lg border transition-all ${type === 'blob' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                >
                  <Circle className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Complexity ({complexity})</label>
              <input 
                type="range" min="3" max="20" step="1" 
                value={complexity} onChange={(e) => setComplexity(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Randomness ({randomness})</label>
              <input 
                type="range" min="0" max="100" step="1" 
                value={randomness} onChange={(e) => setRandomness(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Opacity ({opacity})</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={opacity} onChange={(e) => setOpacity(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Fill Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">SVG Code</label>
              <button 
                onClick={copyToClipboard}
                className="text-xs flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied!' : 'Copy SVG'}
              </button>
            </div>
            <pre className="p-4 bg-slate-950 text-indigo-300 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800 max-h-[200px]">
              {svgCode}
            </pre>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[300px] overflow-hidden">
          <svg viewBox="0 0 1000 500" className="w-full h-full drop-shadow-xl">
            <path d={path} fill={color} fillOpacity={opacity} className="transition-all duration-500" />
          </svg>
        </div>
      </div>
    </motion.div>
  );
}
