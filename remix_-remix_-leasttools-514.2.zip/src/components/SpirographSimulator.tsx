import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, RefreshCw, Hexagon, Download, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function SpirographSimulator() {
  const [R, setR] = useState(100); // Outer circle radius
  const [r, setr] = useState(52);  // Inner circle radius
  const [d, setd] = useState(40);  // Pen distance from inner circle center
  const [color, setColor] = useState('#6366f1');
  const [speed, setSpeed] = useState(5);
  const [isDrawing, setIsDrawing] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  const angleRef = useRef<number>(0);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('spirograph-simulator');
      if (savedState) {
        setR(savedState.R ?? 100);
        setr(savedState.r ?? 52);
        setd(savedState.d ?? 40);
        setColor(savedState.color ?? '#6366f1');
        setSpeed(savedState.speed ?? 5);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('spirograph-simulator', { R, r, d, color, speed });
    }
  }, [R, r, d, color, speed, isLoaded]);

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    if (angleRef.current === 0) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
    }

    for (let i = 0; i < speed; i++) {
      angleRef.current += 0.05;
      const t = angleRef.current;
      
      // Hypotrochoid equations
      const x = (R - r) * Math.cos(t) + d * Math.cos(((R - r) / r) * t);
      const y = (R - r) * Math.sin(t) - d * Math.sin(((R - r) / r) * t);

      if (angleRef.current === 0.05) {
        ctx.moveTo(centerX + x, centerY + y);
      } else {
        ctx.lineTo(centerX + x, centerY + y);
      }
    }
    ctx.stroke();

    if (isDrawing) {
      animationRef.current = requestAnimationFrame(draw);
    }
  };

  useEffect(() => {
    angleRef.current = 0;
    if (isDrawing) {
      animationRef.current = requestAnimationFrame(draw);
    }
    return () => cancelAnimationFrame(animationRef.current);
  }, [R, r, d, color, speed, isDrawing]);

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `spirograph-${R}-${r}-${d}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    angleRef.current = 0;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Hexagon className="w-5 h-5 text-indigo-500" />
          <h2>Spirograph Simulator</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={clearCanvas}
            className="p-2 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
            title="Clear"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={downloadCanvas}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsDrawing(!isDrawing)}
            className={`p-2 rounded-lg transition-colors ${isDrawing ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20' : 'text-slate-400 hover:text-indigo-500'}`}
            title={isDrawing ? 'Pause' : 'Play'}
          >
            <RefreshCw className={`w-4 h-4 ${isDrawing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Outer Radius (R: {R})</label>
              <input 
                type="range" min="10" max="200" step="1" 
                value={R} onChange={(e) => setR(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Inner Radius (r: {r})</label>
              <input 
                type="range" min="1" max="150" step="1" 
                value={r} onChange={(e) => setr(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pen Distance (d: {d})</label>
              <input 
                type="range" min="0" max="150" step="1" 
                value={d} onChange={(e) => setd(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Drawing Speed</label>
              <input 
                type="range" min="1" max="20" step="1" 
                value={speed} onChange={(e) => setSpeed(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Pen Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">How it works</h3>
            <p className="text-[10px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
              A spirograph is formed by rolling a circle inside or outside another circle. 
              The pen is placed at a distance <b>d</b> from the center of the inner circle. 
              Adjust <b>R</b>, <b>r</b>, and <b>d</b> to create unique geometric patterns.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden">
          <canvas 
            ref={canvasRef} 
            width={500} 
            height={500} 
            className="w-full h-full max-w-[500px] max-h-[500px] object-contain drop-shadow-lg"
          />
        </div>
      </div>
    </motion.div>
  );
}
