import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, RefreshCw, Grid, Upload, Trash2, Image as ImageIcon, Download } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function ImageLegoizer() {
  const [image, setImage] = useState<string | null>(null);
  const [pixelSize, setPixelSize] = useState(20);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const originalImageRef = useRef<HTMLImageElement | null>(null);

  // Standard LEGO colors (approximate)
  const legoColors = [
    { name: 'White', r: 255, g: 255, b: 255 },
    { name: 'Black', r: 0, g: 0, b: 0 },
    { name: 'Red', r: 180, g: 0, b: 0 },
    { name: 'Blue', r: 0, g: 85, b: 191 },
    { name: 'Yellow', r: 255, g: 205, b: 3 },
    { name: 'Green', r: 0, g: 154, b: 68 },
    { name: 'Orange', r: 255, g: 130, b: 0 },
    { name: 'Brown', r: 91, g: 28, b: 12 },
    { name: 'Grey', r: 160, g: 160, b: 160 },
    { name: 'Dark Grey', r: 100, g: 100, b: 100 }
  ];

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('image-legoizer');
      if (savedState) {
        setImage(savedState.image ?? null);
        setPixelSize(savedState.pixelSize ?? 20);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('image-legoizer', { image, pixelSize });
    }
  }, [image, pixelSize, isLoaded]);

  const findClosestLegoColor = (r: number, g: number, b: number) => {
    let minDistance = Infinity;
    let closestColor = legoColors[0];

    legoColors.forEach(color => {
      const distance = Math.sqrt(
        Math.pow(r - color.r, 2) +
        Math.pow(g - color.g, 2) +
        Math.pow(b - color.b, 2)
      );
      if (distance < minDistance) {
        minDistance = distance;
        closestColor = color;
      }
    });

    return closestColor;
  };

  const legoize = () => {
    const canvas = canvasRef.current;
    const img = originalImageRef.current;
    if (!canvas || !img) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsProcessing(true);

    // Set canvas dimensions to match image aspect ratio
    const maxWidth = 800;
    const scale = Math.min(1, maxWidth / img.width);
    canvas.width = img.width * scale;
    canvas.height = img.height * scale;

    // Draw original image scaled down
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;

    // Clear canvas for lego effect
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let y = 0; y < canvas.height; y += pixelSize) {
      for (let x = 0; x < canvas.width; x += pixelSize) {
        // Sample color from center of pixel block
        const pixelX = Math.min(canvas.width - 1, Math.floor(x + pixelSize / 2));
        const pixelY = Math.min(canvas.height - 1, Math.floor(y + pixelSize / 2));
        const i = (pixelY * canvas.width + pixelX) * 4;

        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];

        const closest = findClosestLegoColor(r, g, b);

        // Draw LEGO brick
        ctx.fillStyle = `rgb(${closest.r}, ${closest.g}, ${closest.b})`;
        ctx.fillRect(x, y, pixelSize, pixelSize);
        
        // Draw stud (circle on top)
        ctx.beginPath();
        ctx.arc(x + pixelSize / 2, y + pixelSize / 2, pixelSize / 4, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, 0.2)`;
        ctx.fill();
        
        // Draw border for brick definition
        ctx.strokeStyle = `rgba(0, 0, 0, 0.1)`;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, pixelSize, pixelSize);
      }
    }

    setIsProcessing(false);
  };

  useEffect(() => {
    if (image) {
      const img = new Image();
      img.onload = () => {
        originalImageRef.current = img;
        legoize();
      };
      img.src = image;
    }
  }, [image, pixelSize]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `lego-art.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Grid className="w-5 h-5 text-indigo-500" />
          <h2>Image "Lego-izer"</h2>
        </div>
        <div className="flex items-center gap-2">
          {image && (
            <>
              <button
                onClick={downloadCanvas}
                className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={() => setImage(null)}
                className="p-2 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
                title="Clear Image"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-3 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Brick Size ({pixelSize}px)</label>
              <input 
                type="range" min="10" max="50" step="2" 
                value={pixelSize} onChange={(e) => setPixelSize(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">How it works</h3>
            <p className="text-[10px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
              This tool pixelates your image and maps each block to the closest standard LEGO color. 
              It creates a "build map" style visualization of your photo.
            </p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">LEGO Palette Used</label>
            <div className="grid grid-cols-5 gap-1">
              {legoColors.map(c => (
                <div 
                  key={c.name} 
                  className="w-full aspect-square rounded shadow-sm border border-black/5" 
                  style={{ backgroundColor: `rgb(${c.r}, ${c.g}, ${c.b})` }}
                  title={c.name}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden">
          {image ? (
            <canvas 
              ref={canvasRef} 
              className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
            />
          ) : (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto">
                <ImageIcon className="w-8 h-8 text-slate-400" />
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-500">Upload an image to start</p>
                <button 
                  onClick={() => document.getElementById('legoizer-upload')?.click()}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
                >
                  Select Image
                </button>
                <input 
                  id="legoizer-upload" 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="hidden" 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
