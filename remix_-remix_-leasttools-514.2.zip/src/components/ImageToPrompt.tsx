import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, Copy, Check, Loader2, Image as ImageIcon, FileText, Trash2, AlertCircle, ScanLine, Save, Download } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError, withRetry } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

interface SavedPrompt {
  id: string;
  image: string;
  prompt: string;
  timestamp: number;
}

export default function ImageToPrompt() {
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [prompt, setPrompt] = useState<string>('');
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedItems, setSavedItems] = useState<SavedPrompt[]>([]);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('image-to-prompt');
      if (savedState) {
        setImage(savedState.image || null);
        setPrompt(savedState.prompt || '');
        setSavedItems(savedState.savedItems || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('image-to-prompt', { image, prompt, savedItems, filename });
    }
  }, [image, prompt, savedItems, filename, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setPrompt('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onloadend = () => {
              setImage(reader.result as string);
              setPrompt('');
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const downloadPrompt = () => {
    if (prompt) {
      const element = document.createElement('a');
      const file = new Blob([prompt], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'prompt', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };
  const generatePrompt = async () => {
    if (!image) return;
    setIsProcessing(true);
    setErrorDetails(null);
    setPrompt('');

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];
      
      const systemPrompt = `Analyze this image and write an extremely detailed, high-fidelity text-to-image prompt that would allow an AI model (like Midjourney, Stable Diffusion, or DALL-E) to recreate this image with near-perfect precision. 
      
      Break down the description into these specific categories:
      1. CORE SUBJECT: Describe the main subject in exhaustive detail. Include physical features, micro-expressions, specific textures (skin, fabric, fur), exact pose, and any intricate clothing or accessories.
      2. ENVIRONMENT & SETTING: Detail the background elements, architectural styles, natural features, and the overall atmosphere. Mention specific objects and their placement.
      3. ARTISTIC STYLE & MEDIUM: Identify the exact artistic style (e.g., hyper-realistic photography, classical oil painting, digital concept art, 3D Octane render, vintage film). Mention specific artists if their style is prominent.
      4. LIGHTING & SHADOWS: Describe the light source, direction, intensity, and color temperature. Mention effects like rim lighting, volumetric fog, dappled sunlight, or high-contrast chiaroscuro.
      5. COLOR PALETTE: List the dominant and accent colors, including specific shades and the overall color harmony (e.g., monochromatic, complementary, earthy tones).
      6. COMPOSITION & CAMERA: Specify the camera angle (low, high, eye-level), shot type (close-up, wide, macro), focal length (e.g., 35mm, 85mm), depth of field (bokeh), and any specific lens effects (grain, flare).
      7. QUALITY ENHANCERS: Include high-end technical keywords like 'unreal engine 5', 'ray tracing', 'subsurface scattering', 'intricate detail', '8k resolution', and 'masterpiece'.
      
      Output ONLY the raw prompt text. Do not include introductory phrases like "Here is a prompt:".`;

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Request timed out. Please check your internet connection.")), 60000)
      );

      const response = await withRetry(async () => {
        return await Promise.race([
          ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                  }
                },
                { text: systemPrompt }
              ]
            }
          }),
          timeoutPromise
        ]);
      }) as any;

      if (response.text) {
        setPrompt(response.text.trim());
      }
    } catch (error: any) {
      setErrorDetails(handleGeminiError(error));
    } finally {
      setIsProcessing(false);
    }
  };

  const saveToHistory = () => {
    if (!image || !prompt) return;
    const newItem: SavedPrompt = {
      id: Math.random().toString(36).substring(7),
      image,
      prompt,
      timestamp: Date.now()
    };
    setSavedItems(prev => [newItem, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedItems(prev => prev.filter(item => item.id !== id));
  };

  const copyToClipboard = () => {
    if (!prompt) return;
    navigator.clipboard.writeText(prompt);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ScanLine className="w-5 h-5 text-indigo-500" />
          <h2>Image to Prompt</h2>
        </div>
        <div className="flex items-center gap-2">
          {prompt && (
            <button
              onClick={saveToHistory}
              className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
              title="Save to History"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          {(image || prompt) && (
            <button
              onClick={() => {
                setImage(null);
                setPrompt('');
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {errorDetails && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{errorDetails}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Upload Image</label>
            <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${image ? 'border-indigo-200 dark:border-indigo-900/50 bg-indigo-50/30 dark:bg-indigo-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 bg-slate-50 dark:bg-slate-950'}`}>
              {image ? (
                <>
                  <img src={image} alt="Source" className="max-h-64 object-contain rounded-lg shadow-sm" />
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                    <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                      <button onClick={() => document.getElementById('file-upload-prompt')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                      {" or "}
                      <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                      {" an image"}
                    </p>
                  </div>
                  <input id="file-upload-prompt" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </div>
              )}
            </div>

            <button
              onClick={generatePrompt}
              disabled={!image || isProcessing}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50"
            >
              {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
              Generate Detailed Prompt
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Generated Prompt</label>
              {prompt && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadPrompt}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              )}
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 min-h-[300px] p-4 relative group transition-colors shadow-inner">
              {prompt ? (
                <>
                  <p className="text-slate-700 dark:text-slate-200 text-sm leading-relaxed whitespace-pre-wrap">{prompt}</p>
                  <button
                    onClick={copyToClipboard}
                    className="absolute top-4 right-4 p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-all opacity-0 group-hover:opacity-100"
                    title="Copy to clipboard"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50">
                  <FileText className="w-12 h-12 mb-2" />
                  <p className="text-sm text-center">Detailed prompt will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* History Section */}
        {savedItems.length > 0 && (
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider ml-1">History</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) setSavedItems([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {savedItems.map((item) => (
                <div key={item.id} className="group relative bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden aspect-square transition-colors">
                  <img src={item.image} alt="Saved source" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                    <p className="text-[10px] text-white font-bold uppercase tracking-wider line-clamp-2 text-center">{item.prompt}</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setImage(item.image);
                          setPrompt(item.prompt);
                        }}
                        className="p-1.5 bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-50 dark:hover:bg-slate-700 transition-colors"
                        title="Load"
                      >
                        <Upload className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => deleteSaved(item.id)}
                        className="p-1.5 bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-slate-700 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
