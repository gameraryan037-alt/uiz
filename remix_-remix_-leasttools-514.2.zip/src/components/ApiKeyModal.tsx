import React, { useState, useEffect } from 'react';
import { Key, ShieldCheck, ExternalLink, AlertCircle, CheckCircle2, X, Loader2, Plus, Trash2, Check, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

interface SavedKey {
  id: string;
  name: string;
  key: string;
  isActive: boolean;
}

export default function ApiKeyModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [keyName, setKeyName] = useState('');
  const [savedKeys, setSavedKeys] = useState<SavedKey[]>([]);
  const [status, setStatus] = useState<'idle' | 'testing' | 'saved' | 'error'>('idle');
  const [testError, setTestError] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    const keys = localStorage.getItem('USER_GEMINI_KEYS');
    if (keys) {
      const parsed = JSON.parse(keys);
      setSavedKeys(parsed);
      
      // If no key is active, make the first one active
      if (parsed.length > 0 && !parsed.find((k: SavedKey) => k.isActive)) {
        const updated = [...parsed];
        updated[0].isActive = true;
        saveKeys(updated);
      }
    } else {
      // Migrate old single key if exists
      const oldKey = localStorage.getItem('USER_GEMINI_API_KEY');
      if (oldKey) {
        const initialKeys = [{ id: '1', name: 'Primary Key', key: oldKey, isActive: true }];
        saveKeys(initialKeys);
        localStorage.removeItem('USER_GEMINI_API_KEY');
      } else {
        setIsOpen(true);
        setShowAddForm(true);
      }
    }
  }, []);

  const saveKeys = (keys: SavedKey[]) => {
    setSavedKeys(keys);
    localStorage.setItem('USER_GEMINI_KEYS', JSON.stringify(keys));
    
    // Also update the legacy key for backward compatibility with existing tools
    const active = keys.find(k => k.isActive);
    if (active) {
      localStorage.setItem('USER_GEMINI_API_KEY', active.key);
    } else {
      localStorage.removeItem('USER_GEMINI_API_KEY');
    }
  };

  const testConnection = async () => {
    if (!apiKey.trim()) return;
    setStatus('testing');
    setTestError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: apiKey.trim() });
      
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Connection timed out. Please check your internet or try a different key.")), 15000)
      );

      const response = await Promise.race([
        ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: "Hi",
        }),
        timeoutPromise
      ]) as any;
      
      if (response && response.text) {
        const newKey: SavedKey = {
          id: Date.now().toString(),
          name: keyName.trim() || `Key ${savedKeys.length + 1}`,
          key: apiKey.trim(),
          isActive: savedKeys.length === 0
        };
        
        const updatedKeys = [...savedKeys, newKey];
        saveKeys(updatedKeys);
        
        setStatus('saved');
        setTimeout(() => {
          setStatus('idle');
          setApiKey('');
          setKeyName('');
          setShowAddForm(false);
          if (updatedKeys.length === 1) {
            setIsOpen(false);
            window.location.reload();
          }
        }, 1500);
      } else {
        throw new Error("Invalid response from AI service.");
      }
    } catch (error: any) {
      console.error("Test connection failed:", error);
      setStatus('error');
      
      let errorMessage = error.message || "Invalid API Key or connection error";
      if (errorMessage.includes("API_KEY_INVALID")) {
        errorMessage = "Invalid API Key. Please double check the key you pasted.";
      } else if (errorMessage.includes("quota")) {
        errorMessage = "This API key has exceeded its quota. Please try another key.";
      }
      
      setTestError(errorMessage);
    }
  };

  const toggleKey = (id: string) => {
    const updated = savedKeys.map(k => ({
      ...k,
      isActive: k.id === id
    }));
    saveKeys(updated);
    window.location.reload(); // Reload to apply new active key
  };

  const deleteKey = (id: string) => {
    const updated = savedKeys.filter(k => k.id !== id);
    if (updated.length > 0 && !updated.find(k => k.isActive)) {
      updated[0].isActive = true;
    }
    saveKeys(updated);
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full shadow-lg hover:bg-slate-50 dark:hover:bg-slate-800 transition-all z-40 group flex items-center gap-2"
        title="API Settings"
      >
        <Key className={`w-5 h-5 ${savedKeys.length > 0 ? 'text-emerald-500' : 'text-slate-600 dark:text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400'}`} />
        {savedKeys.length > 0 && (
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 pr-1">
            {savedKeys.find(k => k.isActive)?.name || 'Active'}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
              onClick={() => {
                if (savedKeys.length > 0) setIsOpen(false);
              }}
            />
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh] border border-slate-200 dark:border-slate-800"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                    <ShieldCheck className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">Key Manager</h2>
                </div>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {/* Key List */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Your API Keys</h3>
                    <button 
                      onClick={() => setShowAddForm(!showAddForm)}
                      className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center gap-1"
                    >
                      {showAddForm ? 'Cancel' : <><Plus className="w-3 h-3" /> Add New Key</>}
                    </button>
                  </div>

                  {savedKeys.length === 0 && !showAddForm && (
                    <div className="text-center py-8 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700">
                      <p className="text-sm text-slate-500 dark:text-slate-400">No keys added yet.</p>
                    </div>
                  )}

                  <div className="space-y-2">
                    {savedKeys.map((k) => (
                      <div 
                        key={k.id}
                        className={`p-4 rounded-2xl border transition-all flex items-center justify-between group ${
                          k.isActive 
                            ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800 shadow-sm' 
                            : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                            k.isActive ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'
                          }`}>
                            <Key className="w-4 h-4" />
                          </div>
                          <div className="overflow-hidden">
                            <p className={`font-bold text-sm truncate ${k.isActive ? 'text-emerald-900 dark:text-emerald-100' : 'text-slate-700 dark:text-slate-300'}`}>
                              {k.name}
                            </p>
                            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono truncate">
                              ••••••••{k.key.slice(-4)}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          {!k.isActive && (
                            <button 
                              onClick={() => toggleKey(k.id)}
                              className="p-2 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-all"
                              title="Activate this key"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                          )}
                          <button 
                            onClick={() => deleteKey(k.id)}
                            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                            title="Delete key"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Add Form */}
                {showAddForm && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4 p-5 bg-blue-50/50 dark:bg-blue-900/10 rounded-2xl border border-blue-100 dark:border-blue-900/30"
                  >
                    <h3 className="text-sm font-bold text-blue-900 dark:text-blue-100">Add New Gemini Key</h3>
                    
                    <div className="space-y-3">
                      <input
                        type="text"
                        value={keyName}
                        onChange={(e) => setKeyName(e.target.value)}
                        placeholder="Key Name (e.g. Work Account)"
                        className="block w-full px-4 py-3 bg-white dark:bg-slate-950 border border-blue-200 dark:border-blue-900/50 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm dark:text-white"
                      />
                      <div className="relative">
                        <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input
                          type="password"
                          value={apiKey}
                          onChange={(e) => {
                            setApiKey(e.target.value);
                            setStatus('idle');
                            setTestError(null);
                          }}
                          placeholder="Paste API Key here..."
                          className={`block w-full pl-11 pr-4 py-3 bg-white dark:bg-slate-950 border rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm dark:text-white ${status === 'error' ? 'border-red-300 dark:border-red-900/50' : 'border-blue-200 dark:border-blue-900/50'}`}
                        />
                      </div>
                    </div>

                    {testError && (
                      <div className="bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-xl p-3 flex gap-2 text-red-700 dark:text-red-400 text-[10px]">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <p>{testError}</p>
                      </div>
                    )}

                    <button
                      onClick={testConnection}
                      disabled={!apiKey.trim() || status === 'testing'}
                      className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-md ${
                        status === 'saved' 
                          ? 'bg-emerald-500 text-white' 
                          : status === 'testing'
                          ? 'bg-blue-400 text-white cursor-wait'
                          : 'bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50 shadow-blue-200/50 dark:shadow-none'
                      }`}
                    >
                      {status === 'testing' ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                      {status === 'testing' ? 'Verifying...' : 'Verify & Add Key'}
                    </button>

                    <div className="flex items-center justify-center gap-1">
                      <a 
                        href="https://aistudio.google.com/app/apikey" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-[10px] text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                      >
                        Get a free key from Google AI Studio
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    </div>
                  </motion.div>
                )}

                {!showAddForm && savedKeys.length > 0 && (
                  <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-2xl p-4 flex gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-amber-900 dark:text-amber-100">Pro Tip for Quota</p>
                      <p className="text-[10px] text-amber-800 dark:text-amber-300 leading-relaxed">
                        Free tier keys have limits (RPM). If one key hits the limit, you can quickly switch to another key here to continue using image tools.
                      </p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="p-6 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
                <p className="text-[10px] text-center text-slate-400 dark:text-slate-500">
                  Keys are stored only in your browser. We never see your keys.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
