import React, { useState, useRef, useEffect } from 'react';
import { 
  Zap, Search, Upload, Download, Loader2, Sparkles, 
  BookOpen, FileText, Trash2, AlertCircle, CheckCircle2,
  Copy, Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import Markdown from 'react-markdown';

export default function PyqSolver() {
  const [chapter, setChapter] = useState('');
  const [subject, setSubject] = useState('');
  const [examType, setExamType] = useState('JEE Mains');
  const [isProcessing, setIsProcessing] = useState(false);
  const [solution, setSolution] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [copied, setCopied] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('pyq-solver');
      if (savedState) {
        setChapter(savedState.chapter || '');
        setSubject(savedState.subject || '');
        setExamType(savedState.examType || 'JEE Mains');
        setSolution(savedState.solution || null);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('pyq-solver', { chapter, subject, examType, solution });
    }
  }, [chapter, subject, examType, solution, isLoaded]);

  const solvePyqs = async () => {
    if (!chapter.trim() || !subject.trim()) return;
    setIsProcessing(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `You are an expert academic tutor. Solve the most important Previous Year Questions (PYQs) for the chapter "${chapter}" in the subject "${subject}" for the "${examType}" exam. 
      
      Provide:
      1. A list of 5-7 high-yield PYQs from recent years.
      2. Detailed, step-by-step solutions for each.
      3. Key concepts and formulas used.
      4. Tips for solving similar problems in the exam.
      
      Format the output clearly using Markdown with headers, bold text, and bullet points. Use LaTeX-style formatting for math if possible (e.g., $x^2$).`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ text: prompt }]
      });

      setSolution(response.text || 'No solution generated.');
    } catch (err: any) {
      setError(handleGeminiError(err));
    } finally {
      setIsProcessing(false);
    }
  };

  const copyToClipboard = () => {
    if (solution) {
      navigator.clipboard.writeText(solution);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadSolution = () => {
    if (solution) {
      const blob = new Blob([solution], { type: 'text/markdown' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = getDownloadFilename(`${chapter}_PYQs`, 'solution', 'md');
      link.click();
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-2xl">
          <Zap className="w-6 h-6 text-amber-600 dark:text-amber-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">AI PYQ Solver</h2>
          <p className="text-slate-500 dark:text-slate-400">Get step-by-step solutions for Previous Year Questions of any chapter.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Section */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xl">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Exam Details</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Subject</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Physics, Chemistry, Math"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Chapter Name</label>
                <input
                  type="text"
                  value={chapter}
                  onChange={(e) => setChapter(e.target.value)}
                  placeholder="e.g., Thermodynamics, Calculus"
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Target Exam</label>
                <select
                  value={examType}
                  onChange={(e) => setExamType(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none transition-all text-sm dark:text-white appearance-none"
                >
                  <option>JEE Mains</option>
                  <option>JEE Advanced</option>
                  <option>NEET</option>
                  <option>CBSE Class 10</option>
                  <option>CBSE Class 11</option>
                  <option>CBSE Class 12</option>
                  <option>ICSE Class 10</option>
                  <option>ISC Class 11</option>
                  <option>ISC Class 12</option>
                  <option>UPSC</option>
                  <option>CAT</option>
                  <option>Other Competitive Exam</option>
                </select>
              </div>

              <button
                onClick={solvePyqs}
                disabled={!chapter.trim() || !subject.trim() || isProcessing}
                className="w-full py-4 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold rounded-2xl shadow-lg shadow-amber-200 dark:shadow-none transition-all flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Solving PYQs...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Generate Solutions
                  </>
                )}
              </button>

              {(chapter || subject || solution) && (
                <button
                  onClick={() => { setChapter(''); setSubject(''); setSolution(null); }}
                  className="w-full py-3 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl hover:bg-slate-200 transition-all text-sm font-bold"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          {error && (
            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30 rounded-2xl flex items-start gap-3 text-red-800 dark:text-red-300">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Result Section */}
        <div className="lg:col-span-2">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl min-h-[600px] flex flex-col overflow-hidden">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-slate-900 dark:text-white">Solutions & Analysis</h3>
              </div>
              {solution && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyToClipboard}
                    className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                    title="Copy to clipboard"
                  >
                    {copied ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                  </button>
                  <button
                    onClick={downloadSolution}
                    className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                    title="Download as Markdown"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>

            <div className="flex-1 p-8 overflow-y-auto custom-scrollbar">
              {isProcessing ? (
                <div className="h-full flex flex-col items-center justify-center space-y-4">
                  <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                  <p className="text-slate-500 font-bold animate-pulse">AI is solving PYQs...</p>
                </div>
              ) : solution ? (
                <div className="prose prose-slate dark:prose-invert max-w-none">
                  <Markdown>{solution}</Markdown>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                  <div className="p-6 bg-slate-50 dark:bg-slate-800 rounded-full">
                    <Search className="w-12 h-12 text-slate-300" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white">No Solutions Yet</h4>
                    <p className="text-slate-500 max-w-xs mx-auto mt-2">
                      Enter the subject and chapter name to get high-yield PYQs and step-by-step solutions.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
