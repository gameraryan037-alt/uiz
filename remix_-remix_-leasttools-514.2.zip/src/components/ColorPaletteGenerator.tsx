import React, { useState, useEffect } from 'react';
import { Palette, RefreshCw, Copy, Check, Hash, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type PaletteType = 'analogous' | 'monochromatic' | 'triadic' | 'complementary';

export default function ColorPaletteGenerator() {
  const [baseColor, setBaseColor] = useState('#6366f1');
  const [palette, setPalette] = useState<string[]>([]);
  const [type, setType] = useState<PaletteType>('triadic');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  useEffect(() => {
    generatePalette();
  }, [baseColor, type]);

  const hexToHsl = (hex: string) => {
    let r = parseInt(hex.slice(1, 3), 16) / 255;
    let g = parseInt(hex.slice(3, 5), 16) / 255;
    let b = parseInt(hex.slice(5, 7), 16) / 255;

    let max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s, l = (max + min) / 2;

    if (max === min) {
      h = s = 0;
    } else {
      let d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return { h: h * 360, s: s * 100, l: l * 100 };
  };

  const hslToHex = (h: number, s: number, l: number) => {
    l /= 100;
    const a = s * Math.min(l, 1 - l) / 100;
    const f = (n: number) => {
      const k = (n + h / 30) % 12;
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
      return Math.round(255 * color).toString(16).padStart(2, '0');
    };
    return `#${f(0)}${f(8)}${f(4)}`;
  };

  const generatePalette = () => {
    const { h, s, l } = hexToHsl(baseColor);
    let colors: string[] = [];

    switch (type) {
      case 'analogous':
        colors = [
          hslToHex((h - 30 + 360) % 360, s, l),
          hslToHex((h - 15 + 360) % 360, s, l),
          baseColor,
          hslToHex((h + 15) % 360, s, l),
          hslToHex((h + 30) % 360, s, l),
        ];
        break;
      case 'monochromatic':
        colors = [
          hslToHex(h, s, Math.max(0, l - 30)),
          hslToHex(h, s, Math.max(0, l - 15)),
          baseColor,
          hslToHex(h, s, Math.min(100, l + 15)),
          hslToHex(h, s, Math.min(100, l + 30)),
        ];
        break;
      case 'triadic':
        colors = [
          baseColor,
          hslToHex((h + 120) % 360, s, l),
          hslToHex((h + 240) % 360, s, l),
          hslToHex((h + 120) % 360, s, Math.max(0, l - 20)),
          hslToHex((h + 240) % 360, s, Math.max(0, l - 20)),
        ];
        break;
      case 'complementary':
        colors = [
          hslToHex(h, s, Math.max(0, l - 20)),
          baseColor,
          hslToHex((h + 180) % 360, s, l),
          hslToHex((h + 180) % 360, s, Math.max(0, l - 20)),
          hslToHex(h, s, Math.min(100, l + 20)),
        ];
        break;
    }
    setPalette(colors);
  };

  const randomColor = () => {
    const hex = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
    setBaseColor(hex);
  };

  const copyColor = (color: string, index: number) => {
    navigator.clipboard.writeText(color);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Palette className="w-5 h-5 text-indigo-500" />
          <h2>Color Palette Generator</h2>
        </div>
        <button
          onClick={randomColor}
          className="p-2 text-slate-400 hover:text-indigo-500 transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-8">
        {/* Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Base Color</label>
            <div className="flex gap-3">
              <div 
                className="w-12 h-12 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm"
                style={{ backgroundColor: baseColor }}
              />
              <div className="relative flex-1">
                <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={baseColor}
                  onChange={(e) => setBaseColor(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Palette Type</label>
            <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl gap-1">
              {(['triadic', 'analogous', 'monochromatic', 'complementary'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setType(t)}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold transition-all capitalize ${
                    type === t 
                      ? 'bg-white dark:bg-slate-700 text-indigo-500 shadow-sm' 
                      : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Palette Display */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 h-64">
          <AnimatePresence mode="popLayout">
            {palette.map((color, index) => (
              <motion.div
                key={`${color}-${index}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative group cursor-pointer"
                onClick={() => copyColor(color, index)}
              >
                <div 
                  className="w-full h-full rounded-2xl shadow-sm border border-black/5 dark:border-white/5 transition-transform group-hover:scale-[1.02]"
                  style={{ backgroundColor: color }}
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-2xl">
                  {copiedIndex === index ? (
                    <Check className="w-6 h-6 text-white" />
                  ) : (
                    <Copy className="w-6 h-6 text-white" />
                  )}
                  <span className="text-[10px] font-bold text-white mt-2 uppercase tracking-widest">{color}</span>
                </div>
                <div className="absolute bottom-4 left-4 right-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm p-2 rounded-lg text-center md:hidden">
                  <span className="text-[10px] font-bold text-slate-800 dark:text-slate-100 uppercase tracking-widest">{color}</span>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Contrast Info */}
        <div className="p-6 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-800 flex gap-4">
          <Zap className="w-6 h-6 text-indigo-500 shrink-0" />
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-indigo-900 dark:text-indigo-100">Math-Based Color Theory</h4>
            <p className="text-xs text-indigo-700 dark:text-indigo-300 leading-relaxed">
              This tool uses HSL (Hue, Saturation, Lightness) calculations to generate harmonious color schemes. 
              {type === 'triadic' && ' Triadic schemes use colors evenly spaced around the color wheel for high contrast and vibrancy.'}
              {type === 'analogous' && ' Analogous schemes use colors that are next to each other, creating a serene and comfortable design.'}
              {type === 'monochromatic' && ' Monochromatic schemes use different shades and tints of the same hue for a clean, cohesive look.'}
              {type === 'complementary' && ' Complementary schemes use opposite colors for maximum contrast and impact.'}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
