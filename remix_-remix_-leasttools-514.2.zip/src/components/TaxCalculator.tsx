import React, { useState, useEffect } from 'react';
import { Calculator, Globe, DollarSign, Percent, Trash2, Search, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import { ALL_COUNTRIES, CountryData } from '../constants/countries';

export default function TaxCalculator() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<CountryData | null>(null);
  const [price, setPrice] = useState<string>('');
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('tax-calculator');
      if (savedState) {
        setSearchQuery(savedState.searchQuery || '');
        if (savedState.selectedCountryCode) {
          const country = ALL_COUNTRIES.find(c => c.code === savedState.selectedCountryCode);
          if (country) setSelectedCountry(country);
        }
        setPrice(savedState.price || '');
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('tax-calculator', { 
        searchQuery, 
        selectedCountryCode: selectedCountry?.code, 
        price,
        filename
      });
    }
  }, [searchQuery, selectedCountry, price, filename, isLoaded]);

  const filteredCountries = ALL_COUNTRIES.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const calculateTax = () => {
    if (!selectedCountry || !price) return null;
    const numPrice = parseFloat(price);
    if (isNaN(numPrice)) return null;

    const taxAmount = (numPrice * selectedCountry.taxRate) / 100;
    const totalPrice = numPrice + taxAmount;

    return {
      taxAmount,
      totalPrice,
      rate: selectedCountry.taxRate,
      type: 'VAT/GST'
    };
  };

  const results = calculateTax();

  const downloadTaxReport = () => {
    if (results && selectedCountry) {
      let content = `Tax Calculation Report\n`;
      content += `======================\n\n`;
      content += `Country: ${selectedCountry.name}\n`;
      content += `Base Price: $${parseFloat(price).toLocaleString()}\n`;
      content += `Tax Rate: ${selectedCountry.taxRate}%\n`;
      content += `Tax Amount: $${results.taxAmount.toLocaleString()}\n`;
      content += `Total Price: $${results.totalPrice.toLocaleString()}\n`;

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'tax-report', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Calculator className="w-5 h-5 text-indigo-500" />
          <h2>Global Tax Calculator</h2>
        </div>
        <div className="flex items-center gap-2">
          {results && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                />
                <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
              </div>
              <button
                onClick={downloadTaxReport}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                title="Download Tax Report"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          )}
          {(selectedCountry || price || searchQuery) && (
            <button
              onClick={() => {
                setSelectedCountry(null);
                setPrice('');
                setSearchQuery('');
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Country Selection */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Search Country</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Type country name..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                />
              </div>
            </div>

            <div className="max-h-[300px] overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl bg-white dark:bg-slate-950 custom-scrollbar">
              {filteredCountries.length > 0 ? (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCountries.map((country) => (
                    <button
                      key={country.code}
                      onClick={() => setSelectedCountry(country)}
                      className={`w-full px-4 py-3 text-left flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors ${selectedCountry?.code === country.code ? 'bg-indigo-50 dark:bg-indigo-900/20' : ''}`}
                    >
                      <div>
                        <p className={`text-sm font-bold ${selectedCountry?.code === country.code ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-700 dark:text-slate-200'}`}>
                          {country.name}
                        </p>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-wider">VAT/GST</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-black text-slate-900 dark:text-white">{country.taxRate}%</p>
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-400 dark:text-slate-600">
                  <Globe className="w-8 h-8 mx-auto mb-2 opacity-20" />
                  <p className="text-xs">No countries found</p>
                </div>
              )}
            </div>
          </div>

          {/* Calculation Section */}
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Enter Price</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="0.00"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none text-lg font-bold text-slate-900 dark:text-white transition-all"
                  />
                </div>
              </div>

              {selectedCountry ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30 rounded-2xl p-6 space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-indigo-100 dark:border-indigo-900/30 pb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-white dark:bg-slate-900 rounded-lg flex items-center justify-center text-indigo-500 shadow-sm">
                        <Percent className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Tax Rate</p>
                        <p className="text-sm font-bold text-indigo-900 dark:text-indigo-100">{selectedCountry.name} ({selectedCountry.taxRate}%)</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Type</p>
                      <p className="text-sm font-bold text-indigo-900 dark:text-indigo-100">VAT/GST</p>
                    </div>
                  </div>

                  {results && (
                    <div className="space-y-3 pt-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500 dark:text-slate-400">Base Price:</span>
                        <span className="font-bold text-slate-700 dark:text-slate-200">${parseFloat(price).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500 dark:text-slate-400">Tax Amount:</span>
                        <span className="font-bold text-red-600 dark:text-red-400">+ ${results.taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between items-center pt-3 border-t border-indigo-100 dark:border-indigo-900/30">
                        <span className="text-base font-bold text-slate-900 dark:text-white">Total Price:</span>
                        <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400">${results.totalPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  )}
                </motion.div>
              ) : (
                <div className="h-48 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl transition-colors">
                  <Globe className="w-10 h-10 mb-3 opacity-20" />
                  <p className="text-sm">Select a country to see tax calculation</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-100 dark:border-slate-800">
          <div className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/30 rounded-xl p-4 flex gap-3">
            <Globe className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <p className="text-xs text-amber-800 dark:text-amber-300 leading-relaxed">
              Note: Tax rates shown are standard national rates (VAT/GST) or average sales tax. Actual rates may vary by state, province, or product category.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
