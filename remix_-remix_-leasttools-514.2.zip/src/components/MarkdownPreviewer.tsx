import React, { useState } from 'react';
import { FileEdit, Eye, Layout, Trash2, Clipboard, Check, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import ReactMarkdown from 'react-markdown';

export default function MarkdownPreviewer() {
  const [markdown, setMarkdown] = useState('# Hello Markdown\n\nType some **markdown** on the left to see the *preview* on the right.\n\n- List item 1\n- List item 2\n\n```javascript\nconsole.log("Hello World");\n```');
  const [view, setView] = useState<'split' | 'edit' | 'preview'>('split');
  const [copied, setCopied] = useState(false);

  const copyHtml = () => {
    // Basic HTML copy - in a real app we might use a library to convert MD to HTML string
    navigator.clipboard.writeText(markdown);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileEdit className="w-5 h-5 text-emerald-500" />
          <h2>Markdown Previewer</h2>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-lg mr-2">
            <button
              onClick={() => setView('edit')}
              className={`p-1.5 rounded-md transition-all ${view === 'edit' ? 'bg-white dark:bg-slate-700 text-emerald-500 shadow-sm' : 'text-slate-500'}`}
            >
              <FileEdit className="w-4 h-4" />
            </button>
            <button
              onClick={() => setView('split')}
              className={`p-1.5 rounded-md transition-all ${view === 'split' ? 'bg-white dark:bg-slate-700 text-emerald-500 shadow-sm' : 'text-slate-500'}`}
            >
              <Layout className="w-4 h-4" />
            </button>
            <button
              onClick={() => setView('preview')}
              className={`p-1.5 rounded-md transition-all ${view === 'preview' ? 'bg-white dark:bg-slate-700 text-emerald-500 shadow-sm' : 'text-slate-500'}`}
            >
              <Eye className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={() => setMarkdown('')}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={copyHtml}
            className="p-2 text-slate-400 hover:text-emerald-500 transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Clipboard className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
        <div className={`grid gap-6 h-full min-h-[500px] ${view === 'split' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
          {/* Editor */}
          {(view === 'edit' || view === 'split') && (
            <div className="flex flex-col gap-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Markdown Editor</label>
              <textarea
                value={markdown}
                onChange={(e) => setMarkdown(e.target.value)}
                className="flex-1 p-6 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-sm focus:ring-2 focus:ring-emerald-500 outline-none resize-none shadow-inner"
              />
            </div>
          )}

          {/* Preview */}
          {(view === 'preview' || view === 'split') && (
            <div className="flex flex-col gap-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Live Preview</label>
              <div className="flex-1 p-6 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-y-auto prose dark:prose-invert max-w-none">
                <ReactMarkdown>{markdown}</ReactMarkdown>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
