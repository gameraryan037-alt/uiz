import React, { useState, useEffect } from 'react';
import { Wallet, Plus, Trash2, PieChart, ArrowDownCircle, ArrowUpCircle, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

interface Expense {
  id: string;
  name: string;
  amount: number;
  category: string;
}

export default function BudgetCalculator() {
  const [income, setIncome] = useState<number>(0);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [newName, setNewName] = useState('');
  const [newAmount, setNewAmount] = useState<string>('');
  const [newCategory, setNewCategory] = useState('General');

  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('budget-calculator');
      if (saved) {
        setIncome(saved.income || 0);
        setExpenses(saved.expenses || []);
      }
    };
    init();
  }, []);

  useEffect(() => {
    saveToolState('budget-calculator', { income, expenses });
  }, [income, expenses]);

  const addExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newAmount) return;

    const expense: Expense = {
      id: Math.random().toString(36).substr(2, 9),
      name: newName,
      amount: parseFloat(newAmount),
      category: newCategory
    };

    setExpenses([...expenses, expense]);
    setNewName('');
    setNewAmount('');
  };

  const removeExpense = (id: string) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remaining = income - totalExpenses;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Wallet className="w-5 h-5 text-emerald-500" />
          <h2>Zero-Based Budget</h2>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Income Card */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-emerald-100 dark:bg-emerald-900/30 rounded-lg">
                <ArrowUpCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              </div>
              <span className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Income</span>
            </div>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
              <input
                type="number"
                value={income || ''}
                onChange={(e) => setIncome(parseFloat(e.target.value) || 0)}
                placeholder="0.00"
                className="w-full pl-8 pr-4 py-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-2xl text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
              />
            </div>
          </div>

          {/* Expenses Card */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-lg">
                <ArrowDownCircle className="w-5 h-5 text-red-600 dark:text-red-400" />
              </div>
              <span className="text-sm font-bold text-slate-500 uppercase tracking-wider">Total Expenses</span>
            </div>
            <div className="text-3xl font-bold text-slate-800 dark:text-slate-100">
              ${totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
          </div>

          {/* Remaining Card */}
          <div className={`p-6 rounded-2xl border shadow-sm transition-all ${
            remaining === 0 
              ? 'bg-emerald-500 text-white border-emerald-400' 
              : remaining > 0 
                ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' 
                : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              <div className={`p-2 rounded-lg ${remaining === 0 ? 'bg-white/20' : 'bg-white dark:bg-slate-800'}`}>
                <PieChart className={`w-5 h-5 ${remaining === 0 ? 'text-white' : 'text-blue-500'}`} />
              </div>
              <span className={`text-sm font-bold uppercase tracking-wider ${remaining === 0 ? 'text-white/80' : 'text-slate-500'}`}>
                Left to Assign
              </span>
            </div>
            <div className={`text-3xl font-bold ${remaining === 0 ? 'text-white' : remaining > 0 ? 'text-blue-600 dark:text-blue-400' : 'text-red-600 dark:text-red-400'}`}>
              ${remaining.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            {remaining === 0 && (
              <div className="mt-2 text-xs font-bold flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                Perfect! Every dollar has a job.
              </div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add Expense Form */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Add Expense</h3>
            <form onSubmit={addExpense} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Name</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="Rent, Groceries..."
                    className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Amount</label>
                  <input
                    type="number"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                >
                  <option>General</option>
                  <option>Housing</option>
                  <option>Food</option>
                  <option>Transport</option>
                  <option>Utilities</option>
                  <option>Entertainment</option>
                  <option>Savings</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add to Budget
              </button>
            </form>
          </div>

          {/* Expense List */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Budget Items</h3>
            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {expenses.length === 0 ? (
                  <div className="text-center py-12 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
                    <p className="text-slate-400 text-sm font-medium">No expenses added yet.</p>
                  </div>
                ) : (
                  expenses.map((expense) => (
                    <motion.div
                      key={expense.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 group"
                    >
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-800 dark:text-slate-100">{expense.name}</span>
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{expense.category}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-bold text-slate-700 dark:text-slate-300">${expense.amount.toFixed(2)}</span>
                        <button
                          onClick={() => removeExpense(expense.id)}
                          className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  ))
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
