import React, { useState, useEffect, useRef } from 'react';
import { Barcode as BarcodeIcon, Download, RotateCcw, Copy, Check, Info, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import JsBarcode from 'jsbarcode';
import { saveToolState, loadToolState } from '../utils/db';

type BarcodeFormat = 'CODE128' | 'CODE39' | 'EAN13' | 'EAN8' | 'UPC' | 'ITF14' | 'MSI' | 'Pharmacode';

export default function BarcodeGenerator() {
  const [text, setText] = useState('');
  const [format, setFormat] = useState<BarcodeFormat>('CODE128');
  const [displayValue, setDisplayValue] = useState(true);
  const [lineColor, setLineColor] = useState('#000000');
  const [background, setBackground] = useState('#ffffff');
  const [width, setWidth] = useState(2);
  const [height, setHeight] = useState(100);
  const [margin, setMargin] = useState(10);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('barcode-generator');
      if (savedState) {
        setText(savedState.text || '');
        setFormat(savedState.format || 'CODE128');
        setDisplayValue(savedState.displayValue ?? true);
        setLineColor(savedState.lineColor || '#000000');
        setBackground(savedState.background || '#ffffff');
        setWidth(savedState.width || 2);
        setHeight(savedState.height || 100);
        setMargin(savedState.margin || 10);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('barcode-generator', { text, format, displayValue, lineColor, background, width, height, margin });
    }
  }, [text, format, displayValue, lineColor, background, width, height, margin, isLoaded]);

  useEffect(() => {
    if (text && svgRef.current) {
      try {
        JsBarcode(svgRef.current, text, {
          format: format,
          lineColor: lineColor,
          width: width,
          height: height,
          displayValue: displayValue,
          background: background,
          margin: margin
        });
        setError(null);
      } catch (err: any) {
        setError(err.message || 'Invalid data for this barcode format');
      }
    }
  }, [text, format, displayValue, lineColor, background, width, height, margin]);

  const downloadBarcode = () => {
    if (!svgRef.current) return;
    
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    const canvas = document.createElement('canvas');
    const svgSize = svgRef.current.getBBox();
    const margin = 20;
    
    canvas.width = svgSize.width + margin * 2;
    canvas.height = svgSize.height + margin * 2;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const img = new Image();
    const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    img.onload = () => {
      ctx.fillStyle = background;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, margin, margin);
      
      const pngUrl = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `barcode-${text || 'generated'}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  const copyToClipboard = async () => {
    if (!svgRef.current) return;
    const svgData = new XMLSerializer().serializeToString(svgRef.current);
    try {
      await navigator.clipboard.writeText(svgData);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy SVG data', err);
    }
  };

  const resetSettings = () => {
    setFormat('CODE128');
    setDisplayValue(true);
    setLineColor('#000000');
    setBackground('#ffffff');
    setWidth(2);
    setHeight(100);
    setMargin(10);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <BarcodeIcon className="w-5 h-5 text-indigo-500" />
          <h2>Barcode Generator</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={resetSettings}
            className="p-2 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
            title="Reset Settings"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Controls */}
          <div className="lg:col-span-1 space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Data to Encode</label>
                <input
                  type="text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Enter text or numbers..."
                  className="w-full px-4 py-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-mono"
                />
                {error && (
                  <p className="text-[10px] text-red-500 font-medium flex items-center gap-1">
                    <Info className="w-3 h-3" />
                    {error}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Barcode Format</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as BarcodeFormat)}
                  className="w-full px-4 py-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                >
                  <option value="CODE128">CODE128 (Auto)</option>
                  <option value="CODE39">CODE39</option>
                  <option value="EAN13">EAN13 (13 digits)</option>
                  <option value="EAN8">EAN8 (8 digits)</option>
                  <option value="UPC">UPC (12 digits)</option>
                  <option value="ITF14">ITF14</option>
                  <option value="MSI">MSI</option>
                  <option value="Pharmacode">Pharmacode</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 mb-2">
                <Settings className="w-4 h-4 text-slate-400" />
                <span className="text-xs font-bold uppercase tracking-wider">Appearance</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Width</label>
                  <input 
                    type="range" min="1" max="4" step="1" 
                    value={width} 
                    onChange={(e) => setWidth(parseInt(e.target.value))}
                    className="w-full accent-indigo-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Height</label>
                  <input 
                    type="range" min="20" max="200" step="10" 
                    value={height} 
                    onChange={(e) => setHeight(parseInt(e.target.value))}
                    className="w-full accent-indigo-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-600 dark:text-slate-400">Display Text</label>
                <button
                  onClick={() => setDisplayValue(!displayValue)}
                  className={`w-10 h-5 rounded-full transition-colors relative ${displayValue ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                >
                  <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${displayValue ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Line Color</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={lineColor} onChange={(e) => setLineColor(e.target.value)} className="w-6 h-6 rounded cursor-pointer" />
                    <span className="text-[10px] font-mono">{lineColor}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Background</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={background} onChange={(e) => setBackground(e.target.value)} className="w-6 h-6 rounded cursor-pointer" />
                    <span className="text-[10px] font-mono">{background}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Preview */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 min-h-[300px] flex flex-col items-center justify-center relative overflow-hidden group">
              <div className="absolute inset-0 bg-grid-slate-100/50 dark:bg-grid-slate-900/20 [mask-image:radial-gradient(white,transparent)]" />
              
              <AnimatePresence mode="wait">
                {text ? (
                  <motion.div
                    key="barcode"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="relative z-10 p-8 bg-white rounded-xl shadow-sm border border-slate-100"
                  >
                    <svg ref={svgRef} className="max-w-full h-auto" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center space-y-4 relative z-10"
                  >
                    <div className="w-20 h-20 bg-slate-50 dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto border border-slate-100 dark:border-slate-800">
                      <BarcodeIcon className="w-10 h-10 text-slate-300 dark:text-slate-700" />
                    </div>
                    <p className="text-slate-400 dark:text-slate-500 text-sm font-medium">Enter data to generate barcode</p>
                  </motion.div>
                )}
              </AnimatePresence>

              {text && !error && (
                <div className="absolute bottom-6 right-6 flex gap-2">
                  <button
                    onClick={copyToClipboard}
                    className="p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm hover:border-indigo-500 transition-all group/btn"
                    title="Copy SVG to Clipboard"
                  >
                    {copied ? <ClipboardCheck className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5 text-slate-400 group-hover/btn:text-indigo-500" />}
                  </button>
                  <button
                    onClick={downloadBarcode}
                    className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-lg shadow-indigo-500/20 transition-all font-bold text-sm"
                  >
                    <Download className="w-4 h-4" />
                    Download PNG
                  </button>
                </div>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/20 rounded-2xl flex items-start gap-3">
                <Info className="w-5 h-5 text-indigo-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-indigo-900 dark:text-indigo-100 uppercase tracking-wider">Format Guide</p>
                  <p className="text-[10px] text-indigo-700/70 dark:text-indigo-300/50 leading-relaxed">
                    <strong>CODE128:</strong> Supports all ASCII characters. Best for general use.<br/>
                    <strong>EAN13:</strong> International standard for retail. Requires 12 or 13 digits.<br/>
                    <strong>UPC:</strong> Standard for retail in US/Canada. Requires 11 or 12 digits.
                  </p>
                </div>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-start gap-3">
                <Settings className="w-5 h-5 text-slate-400 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">Customization</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Adjust line width, height, and colors to match your brand. You can also toggle the human-readable text below the barcode.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function ClipboardCheck(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
      <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
      <path d="m9 14 2 2 4-4" />
    </svg>
  );
}
