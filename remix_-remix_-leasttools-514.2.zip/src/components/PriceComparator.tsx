import React, { useState, useEffect } from 'react';
import { Scale, Globe, ArrowRight, RefreshCw, Trash2, Search, DollarSign, TrendingUp, TrendingDown, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import { ALL_COUNTRIES, CountryData } from '../constants/countries';

export default function PriceComparator() {
  const [countryA, setCountryA] = useState<CountryData>(ALL_COUNTRIES.find(c => c.code === 'US') || ALL_COUNTRIES[0]);
  const [countryB, setCountryB] = useState<CountryData>(ALL_COUNTRIES.find(c => c.code === 'GB') || ALL_COUNTRIES[1]);
  const [priceA, setPriceA] = useState<string>('100');
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('price-comparator');
      if (savedState) {
        const cA = ALL_COUNTRIES.find(c => c.code === savedState.countryACode);
        const cB = ALL_COUNTRIES.find(c => c.code === savedState.countryBCode);
        if (cA) setCountryA(cA);
        if (cB) setCountryB(cB);
        setPriceA(savedState.priceA || '100');
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('price-comparator', { 
        countryACode: countryA.code, 
        countryBCode: countryB.code, 
        priceA,
        filename
      });
    }
  }, [countryA, countryB, priceA, filename, isLoaded]);

  const calculateComparison = () => {
    const numPriceA = parseFloat(priceA);
    if (isNaN(numPriceA)) return null;

    // Price A with tax in Currency A
    const taxA = (numPriceA * countryA.taxRate) / 100;
    const totalA = numPriceA + taxA;

    // Convert Price A to USD then to Currency B
    const priceInUSD = numPriceA / countryA.rateToUSD;
    const priceBBase = priceInUSD * countryB.rateToUSD;

    // Price B with tax in Currency B
    const taxB = (priceBBase * countryB.taxRate) / 100;
    const totalB = priceBBase + taxB;

    // Difference in USD for fair comparison
    const totalA_USD = totalA / countryA.rateToUSD;
    const totalB_USD = totalB / countryB.rateToUSD;
    const diffUSD = totalB_USD - totalA_USD;
    const diffPercent = (diffUSD / totalA_USD) * 100;

    return {
      totalA,
      priceBBase,
      totalB,
      diffUSD,
      diffPercent,
      isCheaper: diffUSD < 0
    };
  };

  const results = calculateComparison();

  const downloadComparison = () => {
    if (results) {
      let content = `Price Comparison Report\n`;
      content += `=======================\n\n`;
      content += `From: ${countryA.name} (${countryA.currency})\n`;
      content += `To: ${countryB.name} (${countryB.currency})\n\n`;
      content += `Price in ${countryA.name}: ${countryA.symbol}${parseFloat(priceA).toLocaleString()}\n`;
      content += `Tax in ${countryA.name}: ${countryA.taxRate}%\n`;
      content += `Total in ${countryA.name}: ${countryA.symbol}${results.totalA.toLocaleString()}\n\n`;
      content += `Equivalent Price in ${countryB.name}: ${countryB.symbol}${results.priceBBase.toLocaleString()}\n`;
      content += `Tax in ${countryB.name}: ${countryB.taxRate}%\n`;
      content += `Total in ${countryB.name}: ${countryB.symbol}${results.totalB.toLocaleString()}\n\n`;
      content += `Result: ${results.isCheaper ? 'Cheaper' : 'More Expensive'} in ${countryB.name}\n`;
      content += `Difference: ${Math.abs(results.diffPercent).toFixed(2)}% (${results.isCheaper ? '-' : '+'} $${Math.abs(results.diffUSD).toFixed(2)} USD)\n`;

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'price-comparison', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const swapCountries = () => {
    const temp = countryA;
    setCountryA(countryB);
    setCountryB(temp);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Scale className="w-5 h-5 text-emerald-500" />
          <h2>Price Comparator</h2>
        </div>
        <div className="flex items-center gap-2">
          {results && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-emerald-500 outline-none text-slate-700 dark:text-slate-200"
                />
                <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
              </div>
              <button
                onClick={downloadComparison}
                className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                title="Download Comparison"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          )}
          <button
            onClick={() => {
              setCountryA(ALL_COUNTRIES.find(c => c.code === 'US') || ALL_COUNTRIES[0]);
              setCountryB(ALL_COUNTRIES.find(c => c.code === 'GB') || ALL_COUNTRIES[1]);
              setPriceA('100');
            }}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            title="Reset"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Inputs Section */}
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-[1fr,auto,1fr] items-end gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">From Country</label>
                <select
                  value={countryA.code}
                  onChange={(e) => setCountryA(ALL_COUNTRIES.find(c => c.code === e.target.value)!)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                >
                  {ALL_COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name} ({c.currency})</option>)}
                </select>
              </div>

              <div className="flex justify-center pb-2">
                <button 
                  onClick={swapCountries}
                  className="p-2 bg-slate-200 dark:bg-slate-800 rounded-full hover:bg-emerald-500 hover:text-white transition-all shadow-sm"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest ml-1">To Country</label>
                <select
                  value={countryB.code}
                  onChange={(e) => setCountryB(ALL_COUNTRIES.find(c => c.code === e.target.value)!)}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                >
                  {ALL_COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name} ({c.currency})</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Price in {countryA.name} ({countryA.symbol})</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{countryA.symbol}</span>
                <input
                  type="number"
                  value={priceA}
                  onChange={(e) => setPriceA(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-10 pr-4 py-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 outline-none text-2xl font-black text-slate-900 dark:text-white transition-all"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Tax in {countryA.name}:</span>
                <span className="font-bold text-slate-600 dark:text-slate-300">{countryA.taxRate}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Tax in {countryB.name}:</span>
                <span className="font-bold text-slate-600 dark:text-slate-300">{countryB.taxRate}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Exchange Rate:</span>
                <span className="font-bold text-slate-600 dark:text-slate-300">1 {countryA.currency} = {(countryB.rateToUSD / countryA.rateToUSD).toFixed(4)} {countryB.currency}</span>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="flex flex-col">
            <AnimatePresence mode="wait">
              {results ? (
                <motion.div 
                  key={`${countryA.code}-${countryB.code}-${priceA}`}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex-1 space-y-6"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-5 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">Total in {countryA.name}</p>
                      <p className="text-xl font-black text-slate-900 dark:text-white">
                        {countryA.symbol}{results.totalA.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-[10px] text-slate-400 mt-1">Incl. {countryA.taxRate}% tax</p>
                    </div>
                    <div className="p-5 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                      <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-1">Total in {countryB.name}</p>
                      <p className="text-xl font-black text-slate-900 dark:text-white">
                        {countryB.symbol}{results.totalB.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </p>
                      <p className="text-[10px] text-slate-400 mt-1">Incl. {countryB.taxRate}% tax</p>
                    </div>
                  </div>

                  <div className={`p-8 rounded-3xl border-2 flex flex-col items-center justify-center text-center space-y-4 transition-colors ${results.isCheaper ? 'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/30' : 'bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-900/30'}`}>
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg ${results.isCheaper ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
                      {results.isCheaper ? <TrendingDown className="w-8 h-8" /> : <TrendingUp className="w-8 h-8" />}
                    </div>
                    <div>
                      <h3 className={`text-lg font-black ${results.isCheaper ? 'text-emerald-900 dark:text-emerald-100' : 'text-red-900 dark:text-red-100'}`}>
                        {results.isCheaper ? 'Cheaper in ' : 'More Expensive in '} {countryB.name}
                      </h3>
                      <p className={`text-sm font-medium ${results.isCheaper ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'}`}>
                        Difference: <span className="font-black">{Math.abs(results.diffPercent).toFixed(1)}%</span> 
                        ({results.isCheaper ? '-' : '+'} ${Math.abs(results.diffUSD).toFixed(2)} USD)
                      </p>
                    </div>
                  </div>

                  <div className="bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-2xl p-4 flex gap-3">
                    <TrendingUp className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
                    <p className="text-[11px] text-blue-800 dark:text-blue-300 leading-relaxed">
                      This comparison accounts for both currency exchange rates and national tax rates. It shows how much more or less you would effectively pay in {countryB.name} compared to {countryA.name} for the same base value.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl">
                  <Scale className="w-12 h-12 mb-3 opacity-20" />
                  <p className="text-sm">Enter a price to see comparison</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
