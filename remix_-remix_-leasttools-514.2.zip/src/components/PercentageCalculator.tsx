import React, { useState, useEffect } from 'react';
import { Percent, Calculator, ArrowRight, RotateCcw, Hash } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function PercentageCalculator() {
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Calculation 1: What is X% of Y?
  const [calc1, setCalc1] = useState({ x: '', y: '', result: '' });
  // Calculation 2: X is what % of Y?
  const [calc2, setCalc2] = useState({ x: '', y: '', result: '' });
  // Calculation 3: % increase/decrease from X to Y
  const [calc3, setCalc3] = useState({ x: '', y: '', result: '' });
  // Calculation 4: Add/Sub X% to Y
  const [calc4, setCalc4] = useState({ x: '', y: '', op: 'add', result: '' });

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('percentage-calculator');
      if (savedState) {
        setCalc1(savedState.calc1 || { x: '', y: '', result: '' });
        setCalc2(savedState.calc2 || { x: '', y: '', result: '' });
        setCalc3(savedState.calc3 || { x: '', y: '', result: '' });
        setCalc4(savedState.calc4 || { x: '', y: '', op: 'add', result: '' });
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('percentage-calculator', { calc1, calc2, calc3, calc4 });
    }
  }, [calc1, calc2, calc3, calc4, isLoaded]);

  const handleCalc1 = (x: string, y: string) => {
    const valX = parseFloat(x);
    const valY = parseFloat(y);
    let res = '';
    if (!isNaN(valX) && !isNaN(valY)) {
      res = ((valX / 100) * valY).toFixed(2);
    }
    setCalc1({ x, y, result: res });
  };

  const handleCalc2 = (x: string, y: string) => {
    const valX = parseFloat(x);
    const valY = parseFloat(y);
    let res = '';
    if (!isNaN(valX) && !isNaN(valY) && valY !== 0) {
      res = ((valX / valY) * 100).toFixed(2);
    }
    setCalc2({ x, y, result: res });
  };

  const handleCalc3 = (x: string, y: string) => {
    const valX = parseFloat(x);
    const valY = parseFloat(y);
    let res = '';
    if (!isNaN(valX) && !isNaN(valY) && valX !== 0) {
      res = (((valY - valX) / valX) * 100).toFixed(2);
    }
    setCalc3({ x, y, result: res });
  };

  const handleCalc4 = (x: string, y: string, op: string) => {
    const valX = parseFloat(x);
    const valY = parseFloat(y);
    let res = '';
    if (!isNaN(valX) && !isNaN(valY)) {
      const percentageAmount = (valX / 100) * valY;
      res = (op === 'add' ? valY + percentageAmount : valY - percentageAmount).toFixed(2);
    }
    setCalc4({ x, y, op, result: res });
  };

  const resetAll = () => {
    setCalc1({ x: '', y: '', result: '' });
    setCalc2({ x: '', y: '', result: '' });
    setCalc3({ x: '', y: '', result: '' });
    setCalc4({ x: '', y: '', op: 'add', result: '' });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Percent className="w-5 h-5 text-emerald-500" />
          <h2>Percentage Calculator</h2>
        </div>
        <button
          onClick={resetAll}
          className="p-2 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
          title="Reset All"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        <div className="grid md:grid-cols-2 gap-6">
          
          {/* Calc 1: What is X% of Y? */}
          <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Basic Percentage</h3>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <span>What is</span>
              <input 
                type="number" 
                value={calc1.x} 
                onChange={(e) => handleCalc1(e.target.value, calc1.y)}
                className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500"
                placeholder="X"
              />
              <span>% of</span>
              <input 
                type="number" 
                value={calc1.y} 
                onChange={(e) => handleCalc1(calc1.x, e.target.value)}
                className="w-24 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500"
                placeholder="Y"
              />
              <span>?</span>
            </div>
            <div className={`p-4 rounded-xl flex items-center justify-between ${calc1.result ? 'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-900/30' : 'bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800'}`}>
              <span className="text-xs font-bold text-slate-400 uppercase">Result</span>
              <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">{calc1.result || '0.00'}</span>
            </div>
          </div>

          {/* Calc 2: X is what % of Y? */}
          <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Percentage Of</h3>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <input 
                type="number" 
                value={calc2.x} 
                onChange={(e) => handleCalc2(e.target.value, calc2.y)}
                className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="X"
              />
              <span>is what % of</span>
              <input 
                type="number" 
                value={calc2.y} 
                onChange={(e) => handleCalc2(calc2.x, e.target.value)}
                className="w-24 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="Y"
              />
              <span>?</span>
            </div>
            <div className={`p-4 rounded-xl flex items-center justify-between ${calc2.result ? 'bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/30' : 'bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800'}`}>
              <span className="text-xs font-bold text-slate-400 uppercase">Result</span>
              <span className="text-lg font-black text-blue-600 dark:text-blue-400">{calc2.result ? `${calc2.result}%` : '0.00%'}</span>
            </div>
          </div>

          {/* Calc 3: % increase/decrease from X to Y */}
          <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Percentage Change</h3>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <span>From</span>
              <input 
                type="number" 
                value={calc3.x} 
                onChange={(e) => handleCalc3(e.target.value, calc3.y)}
                className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-purple-500"
                placeholder="X"
              />
              <span>to</span>
              <input 
                type="number" 
                value={calc3.y} 
                onChange={(e) => handleCalc3(calc3.x, e.target.value)}
                className="w-24 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-purple-500"
                placeholder="Y"
              />
              <span>is what % change?</span>
            </div>
            <div className={`p-4 rounded-xl flex items-center justify-between ${calc3.result ? (parseFloat(calc3.result) >= 0 ? 'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-900/30' : 'bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30') : 'bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800'}`}>
              <span className="text-xs font-bold text-slate-400 uppercase">Result</span>
              <span className={`text-lg font-black ${calc3.result ? (parseFloat(calc3.result) >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400') : 'text-slate-400'}`}>
                {calc3.result ? `${parseFloat(calc3.result) > 0 ? '+' : ''}${calc3.result}%` : '0.00%'}
              </span>
            </div>
          </div>

          {/* Calc 4: Add/Sub X% to Y */}
          <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Add/Subtract Percentage</h3>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <select 
                value={calc4.op}
                onChange={(e) => handleCalc4(calc4.x, calc4.y, e.target.value)}
                className="px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="add">Add</option>
                <option value="sub">Subtract</option>
              </select>
              <input 
                type="number" 
                value={calc4.x} 
                onChange={(e) => handleCalc4(e.target.value, calc4.y, calc4.op)}
                className="w-20 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                placeholder="X"
              />
              <span>% to/from</span>
              <input 
                type="number" 
                value={calc4.y} 
                onChange={(e) => handleCalc4(calc4.x, e.target.value, calc4.op)}
                className="w-24 px-2 py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                placeholder="Y"
              />
            </div>
            <div className={`p-4 rounded-xl flex items-center justify-between ${calc4.result ? 'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30' : 'bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800'}`}>
              <span className="text-xs font-bold text-slate-400 uppercase">Result</span>
              <span className="text-lg font-black text-indigo-600 dark:text-indigo-400">{calc4.result || '0.00'}</span>
            </div>
          </div>

        </div>

        <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-start gap-3">
          <Calculator className="w-5 h-5 text-slate-400 mt-0.5" />
          <div className="space-y-1">
            <p className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">Quick Tip</p>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
              Use these calculators for quick everyday math like calculating discounts, tax additions, growth rates, or simple proportions. Results update instantly as you type.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
