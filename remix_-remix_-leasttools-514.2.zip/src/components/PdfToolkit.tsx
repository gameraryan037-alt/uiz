import React, { useState } from 'react';
import { FileUp, Files, Scissors, RotateCw, Download, Trash2, FileText, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PDFDocument, degrees } from 'pdf-lib';

export default function PdfToolkit() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const mergePdfs = async () => {
    if (files.length < 2) return;
    setIsProcessing(true);
    try {
      const mergedPdf = await PDFDocument.create();
      for (const file of files) {
        const pdfBytes = await file.arrayBuffer();
        const pdf = await PDFDocument.load(pdfBytes);
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }
      const pdfBytes = await mergedPdf.save();
      downloadBlob(pdfBytes, 'merged.pdf');
    } catch (error) {
      console.error(error);
      alert('Error merging PDFs');
    } finally {
      setIsProcessing(false);
    }
  };

  const rotatePdf = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      const file = files[0];
      const pdfBytes = await file.arrayBuffer();
      const pdf = await PDFDocument.load(pdfBytes);
      const pages = pdf.getPages();
      pages.forEach(page => {
        const currentRotation = page.getRotation().angle;
        page.setRotation(degrees((currentRotation + 90) % 360));
      });
      const rotatedBytes = await pdf.save();
      downloadBlob(rotatedBytes, `rotated_${file.name}`);
    } catch (error) {
      console.error(error);
      alert('Error rotating PDF');
    } finally {
      setIsProcessing(false);
    }
  };

  const splitPdf = async () => {
    if (files.length === 0) return;
    setIsProcessing(true);
    try {
      const file = files[0];
      const pdfBytes = await file.arrayBuffer();
      const pdf = await PDFDocument.load(pdfBytes);
      const pageCount = pdf.getPageCount();
      
      for (let i = 0; i < pageCount; i++) {
        const newPdf = await PDFDocument.create();
        const [page] = await newPdf.copyPages(pdf, [i]);
        newPdf.addPage(page);
        const singlePageBytes = await newPdf.save();
        downloadBlob(singlePageBytes, `${file.name.replace('.pdf', '')}_page_${i + 1}.pdf`);
      }
    } catch (error) {
      console.error(error);
      alert('Error splitting PDF');
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadBlob = (bytes: Uint8Array, fileName: string) => {
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileText className="w-5 h-5 text-red-500" />
          <h2>PDF Toolkit</h2>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-8">
        {/* Upload Area */}
        <div className="relative group">
          <input
            type="file"
            multiple
            accept=".pdf"
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-12 text-center group-hover:border-red-400 transition-colors bg-white dark:bg-slate-800/50">
            <div className="w-16 h-16 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileUp className="w-8 h-8 text-red-500" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Upload PDF Files</h3>
            <p className="text-sm text-slate-500 mt-1">Drag and drop or click to browse</p>
          </div>
        </div>

        {/* File List */}
        <div className="space-y-3">
          <AnimatePresence mode="popLayout">
            {files.map((file, index) => (
              <motion.div
                key={`${file.name}-${index}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <FileText className="w-4 h-4 text-red-500" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate max-w-[200px]">{file.name}</span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                  </div>
                </div>
                <button
                  onClick={() => removeFile(index)}
                  className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Actions */}
        {files.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              onClick={mergePdfs}
              disabled={files.length < 2 || isProcessing}
              className="flex flex-col items-center gap-3 p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-red-200 dark:hover:border-red-900 transition-all group disabled:opacity-50"
            >
              <Files className="w-6 h-6 text-red-500 group-hover:scale-110 transition-transform" />
              <div className="text-center">
                <span className="block text-sm font-bold text-slate-800 dark:text-slate-100">Merge PDFs</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Combine multiple files</span>
              </div>
            </button>

            <button
              onClick={splitPdf}
              disabled={isProcessing}
              className="flex flex-col items-center gap-3 p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-red-200 dark:hover:border-red-900 transition-all group disabled:opacity-50"
            >
              <Scissors className="w-6 h-6 text-red-500 group-hover:scale-110 transition-transform" />
              <div className="text-center">
                <span className="block text-sm font-bold text-slate-800 dark:text-slate-100">Split PDF</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Save each page separately</span>
              </div>
            </button>

            <button
              onClick={rotatePdf}
              disabled={isProcessing}
              className="flex flex-col items-center gap-3 p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 hover:border-red-200 dark:hover:border-red-900 transition-all group disabled:opacity-50"
            >
              <RotateCw className="w-6 h-6 text-red-500 group-hover:scale-110 transition-transform" />
              <div className="text-center">
                <span className="block text-sm font-bold text-slate-800 dark:text-slate-100">Rotate PDF</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase">Rotate all pages 90°</span>
              </div>
            </button>
          </div>
        )}

        {isProcessing && (
          <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-2xl flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-red-500 animate-spin" />
              <p className="font-bold text-slate-800 dark:text-slate-100">Processing PDF...</p>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
