import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, Download, Copy, Check, Loader2, Image as ImageIcon, Eraser, Trash2, Key, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

export default function WatermarkRemover() {
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('watermark-remover');
      if (savedState) {
        setImage(savedState.image || null);
        setProcessedImage(savedState.processedImage || null);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('watermark-remover', { image, processedImage, filename });
    }
  }, [image, processedImage, filename, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setProcessedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onloadend = () => {
              setImage(reader.result as string);
              setProcessedImage(null);
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const removeWatermark = async () => {
    if (!image) return;
    setIsProcessing(true);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];
      setErrorDetails(null);
      
      const prompt = `Remove all watermarks, logos, text overlays, and date stamps from this image. Reconstruct the background behind these elements with high fidelity to the surrounding textures and colors. The final image should look clean and original, as if the watermarks were never there. Maintain the original resolution and quality of the image. Do not change any other part of the image.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-image",
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: base64Data
              }
            },
            { text: prompt }
          ]
        }
      });

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64EncodeString: string = part.inlineData.data;
            setProcessedImage(`data:image/png;base64,${base64EncodeString}`);
            break;
          }
        }
      } else {
        throw new Error("The AI did not return an image. It might have been blocked by safety filters.");
      }
    } catch (error: any) {
      const userMessage = handleGeminiError(error);
      setErrorDetails(userMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = () => {
    if (processedImage) {
      const link = document.createElement('a');
      link.href = processedImage;
      link.download = getDownloadFilename(filename, 'no-watermark', 'png');
      link.click();
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Eraser className="w-5 h-5 text-indigo-500" />
          <h2>AI Watermark Remover</h2>
        </div>
        <div className="flex items-center gap-2">
          {(image || processedImage) && (
            <button
              onClick={() => {
                setImage(null);
                setProcessedImage(null);
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {errorDetails && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{errorDetails}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Upload Section */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Original Image</label>
            <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${image ? 'border-indigo-200 dark:border-indigo-900/50 bg-indigo-50/30 dark:bg-indigo-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 bg-slate-50 dark:bg-slate-950'}`}>
              {image ? (
                <>
                  <div className="relative w-full aspect-square rounded-lg overflow-hidden shadow-sm">
                    <img src={image} alt="Upload preview" className="w-full h-full object-contain" />
                    <button 
                      onClick={() => setImage(null)}
                      className="absolute top-2 right-2 p-1.5 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-full shadow-sm hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                    >
                      <Check className="w-4 h-4 rotate-45" />
                    </button>
                  </div>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                    <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                      <button onClick={() => document.getElementById('file-upload-remover')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                      {" or "}
                      <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                      {" an image"}
                    </p>
                  </div>
                  <input id="file-upload-remover" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </div>
              )}
            </div>

            <button
              onClick={removeWatermark}
              disabled={!image || isProcessing}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all shadow-sm dark:shadow-none disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Removing Watermark...
                </>
              ) : (
                <>
                  <Eraser className="w-5 h-5" />
                  Remove Watermark
                </>
              )}
            </button>
          </div>

          {/* Result Section */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Clean Result</label>
              {processedImage && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.png</span>
                  </div>
                  <button
                    onClick={downloadImage}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              )}
            </div>
            <div className="flex-1 min-h-[300px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col items-center justify-center overflow-hidden transition-colors shadow-inner">
              {processedImage ? (
                <img src={processedImage} alt="Clean result" className="max-w-full max-h-full object-contain rounded-lg shadow-sm" />
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50">
                  <ImageIcon className="w-12 h-12 mb-2" />
                  <p>Clean image will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
