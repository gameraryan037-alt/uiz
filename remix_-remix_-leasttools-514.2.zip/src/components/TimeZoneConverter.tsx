import React, { useState, useEffect } from 'react';
import { Globe, Clock, Plus, Trash2, MapPin, Briefcase, Moon, Sun } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

interface City {
  id: string;
  name: string;
  timezone: string;
}

const COMMON_TIMEZONES = [
  { name: 'New York', zone: 'America/New_York' },
  { name: 'London', zone: 'Europe/London' },
  { name: 'Tokyo', zone: 'Asia/Tokyo' },
  { name: 'San Francisco', zone: 'America/Los_Angeles' },
  { name: 'Dubai', zone: 'Asia/Dubai' },
  { name: 'Singapore', zone: 'Asia/Singapore' },
  { name: 'Sydney', zone: 'Australia/Sydney' },
  { name: 'Berlin', zone: 'Europe/Berlin' },
  { name: 'Mumbai', zone: 'Asia/Kolkata' },
];

export default function TimeZoneConverter() {
  const [cities, setCities] = useState<City[]>([
    { id: '1', name: 'New York', timezone: 'America/New_York' },
    { id: '2', name: 'London', timezone: 'Europe/London' }
  ]);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('timezone-converter');
      if (saved && saved.cities) {
        setCities(saved.cities);
      }
    };
    init();

    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    saveToolState('timezone-converter', { cities });
  }, [cities]);

  const addCity = (city: { name: string, zone: string }) => {
    if (cities.length >= 4) return;
    const newCity: City = {
      id: Math.random().toString(36).substr(2, 9),
      name: city.name,
      timezone: city.zone
    };
    setCities([...cities, newCity]);
  };

  const removeCity = (id: string) => {
    if (cities.length <= 1) return;
    setCities(cities.filter(c => c.id !== id));
  };

  const getHours = (timezone: string) => {
    const hours = [];
    const now = new Date();
    // Start from the beginning of today in the local timezone
    const baseDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    for (let i = 0; i < 24; i++) {
      const date = new Date(baseDate.getTime() + i * 3600000);
      const timeString = date.toLocaleTimeString('en-US', { 
        timeZone: timezone, 
        hour: 'numeric', 
        hour12: true 
      });
      const hour24 = parseInt(new Date(date.toLocaleString('en-US', { timeZone: timezone })).getHours().toString());
      hours.push({ label: timeString, hour24 });
    }
    return hours;
  };

  const isWorkHour = (hour: number) => hour >= 9 && hour < 18;
  const isSleepHour = (hour: number) => hour >= 22 || hour < 6;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Globe className="w-5 h-5 text-indigo-500" />
          <h2>Meeting Planner</h2>
        </div>
        <div className="flex gap-2">
          {COMMON_TIMEZONES.filter(tz => !cities.find(c => c.timezone === tz.zone)).slice(0, 3).map(tz => (
            <button
              key={tz.zone}
              onClick={() => addCity(tz)}
              className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-[10px] font-bold text-slate-500 hover:text-indigo-500 hover:border-indigo-200 transition-all"
            >
              + {tz.name}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 overflow-x-auto custom-scrollbar flex-1">
        <div className="min-w-[800px] space-y-8">
          {cities.map((city) => {
            const hours = getHours(city.timezone);
            const currentHour = parseInt(new Date(currentTime.toLocaleString('en-US', { timeZone: city.timezone })).getHours().toString());

            return (
              <div key={city.id} className="space-y-4">
                <div className="flex items-center justify-between px-2">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    <div>
                      <h3 className="font-bold text-slate-800 dark:text-slate-100">{city.name}</h3>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{city.timezone}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-lg font-mono font-bold text-indigo-600 dark:text-indigo-400">
                        {currentTime.toLocaleTimeString('en-US', { timeZone: city.timezone, hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                    <button
                      onClick={() => removeCity(city.id)}
                      className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="flex gap-1">
                  {hours.map((h, i) => (
                    <div
                      key={i}
                      className={`flex-1 flex flex-col items-center gap-2 p-2 rounded-lg border transition-all ${
                        h.hour24 === currentHour
                          ? 'bg-indigo-500 border-indigo-400 text-white shadow-lg shadow-indigo-500/20 z-10 scale-105'
                          : isWorkHour(h.hour24)
                            ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800 text-emerald-600 dark:text-emerald-400'
                            : isSleepHour(h.hour24)
                              ? 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 text-slate-500'
                      }`}
                    >
                      <span className={`text-[9px] font-bold whitespace-nowrap ${h.hour24 === currentHour ? 'text-white' : ''}`}>
                        {h.label}
                      </span>
                      <div className="flex items-center justify-center">
                        {isWorkHour(h.hour24) ? (
                          <Briefcase className="w-3 h-3" />
                        ) : isSleepHour(h.hour24) ? (
                          <Moon className="w-3 h-3 opacity-50" />
                        ) : (
                          <Sun className="w-3 h-3 opacity-50" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Legend */}
          <div className="flex items-center gap-6 pt-8 border-t border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded-sm" />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Work Hours (9-6)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-indigo-500 rounded-sm" />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Time</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-slate-200 dark:bg-slate-700 rounded-sm" />
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Sleep Hours</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
