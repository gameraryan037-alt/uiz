import React, { useState, useEffect, useRef } from 'react';
import { FileText, Loader2, Copy, Check, Trash2, AlertCircle, Save, Sparkles, AlignLeft, Upload, File, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import * as pdfjsLib from 'pdfjs-dist';
import Markdown from 'react-markdown';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

interface SavedSummary {
  id: string;
  originalText: string;
  summary: string;
  timestamp: number;
}

export default function Summarizer() {
  const [inputText, setInputText] = useState('');
  const [summary, setSummary] = useState('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isExtracting, setIsExtracting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [copied, setCopied] = useState(false);
  const [savedSummaries, setSavedSummaries] = useState<SavedSummary[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ data: string; mimeType: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Persistence and Global Paste Listener
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('summarizer');
      if (savedState) {
        setInputText(savedState.inputText || '');
        setSummary(savedState.summary || '');
        setSavedSummaries(savedState.savedSummaries || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();

    const handleGlobalPaste = (e: ClipboardEvent) => {
      // Don't intercept if user is typing in an input or textarea (unless it's an image)
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA';
      
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onloadend = () => {
              const base64Data = (reader.result as string).split(',')[1];
              setAttachedFile({
                data: base64Data,
                mimeType: blob.type,
                name: 'Pasted Image'
              });
            };
            reader.readAsDataURL(blob);
            e.preventDefault();
            return;
          }
        }
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('summarizer', { inputText, summary, savedSummaries, filename });
    }
  }, [inputText, summary, savedSummaries, filename, isLoaded]);

  const extractTextFromPDF = async (file: File) => {
    setIsExtracting(true);
    setError(null);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map((item: any) => item.str).join(' ');
        fullText += pageText + '\n';
      }
      
      setInputText(fullText.trim());
    } catch (err) {
      setError("Failed to extract text from PDF. Please try another file.");
      console.error(err);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setAttachedFile(null);

    if (file.type === 'application/pdf') {
      extractTextFromPDF(file);
    } else if (file.type === 'text/plain') {
      setIsExtracting(true);
      try {
        const text = await file.text();
        setInputText(text);
      } catch (err) {
        setError("Failed to read text file.");
      } finally {
        setIsExtracting(false);
      }
    } else if (file.type.startsWith('image/')) {
      setIsExtracting(true);
      try {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Data = (reader.result as string).split(',')[1];
          setAttachedFile({
            data: base64Data,
            mimeType: file.type,
            name: file.name
          });
          setIsExtracting(false);
        };
        reader.readAsDataURL(file);
      } catch (err) {
        setError("Failed to process image.");
        setIsExtracting(false);
      }
    } else {
      setError("Please upload a valid PDF, Image, or Text file.");
    }
  };

  const downloadSummary = () => {
    if (summary) {
      const element = document.createElement('a');
      const file = new Blob([summary], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'summary', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const handleSummarize = async () => {
    if (!inputText.trim() && !attachedFile) return;
    setIsSummarizing(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      let contents: any;
      const systemInstruction = `Summarize the provided content in a very short, concise form. 
      Use bullet points if necessary. Focus on the most important points only.
      Keep it brief and easy to read.
      
      IMPORTANT: Use Markdown bolding (**text**) for key terms, headers, or important names. 
      These will be rendered as bold and underlined in the UI.`;

      if (attachedFile) {
        contents = {
          parts: [
            { inlineData: { data: attachedFile.data, mimeType: attachedFile.mimeType } },
            { text: inputText || "Summarize this content." }
          ]
        };
      } else {
        contents = {
          parts: [{ text: inputText }]
        };
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents,
        config: { systemInstruction }
      });

      setSummary(response.text?.trim() || '');
    } catch (err: any) {
      setError(handleGeminiError(err));
    } finally {
      setIsSummarizing(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const saveSummary = () => {
    if (!inputText || !summary) return;
    const newSave: SavedSummary = {
      id: Math.random().toString(36).substring(7),
      originalText: inputText.substring(0, 500) + (inputText.length > 500 ? '...' : ''),
      summary: summary,
      timestamp: Date.now()
    };
    setSavedSummaries(prev => [newSave, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedSummaries(prev => prev.filter(s => s.id !== id));
  };

  const clearAllSaved = () => {
    if (confirm('Clear all saved summaries?')) {
      setSavedSummaries([]);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <AlignLeft className="w-5 h-5 text-indigo-500" />
          <h2>AI Note Summarizer</h2>
        </div>
        <div className="flex items-center gap-2">
          {(inputText || summary || attachedFile) && (
            <button
              onClick={() => {
                setInputText('');
                setSummary('');
                setAttachedFile(null);
                setFilename('');
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Input */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Your Notes</label>
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept=".pdf,.txt,image/*"
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isExtracting}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-lg text-xs font-bold hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors"
                >
                  {isExtracting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Upload className="w-3 h-3" />}
                  Upload File
                </button>
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Input</span>
              </div>
            </div>

            {attachedFile && (
              <div className="flex items-center justify-between p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-xl border border-indigo-100 dark:border-indigo-900/30">
                <div className="flex items-center gap-2 overflow-hidden">
                  {attachedFile.mimeType.startsWith('image/') ? (
                    <img 
                      src={`data:${attachedFile.mimeType};base64,${attachedFile.data}`} 
                      alt="Preview" 
                      className="w-10 h-10 object-cover rounded shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <File className="w-8 h-8 text-indigo-500" />
                  )}
                  <div className="flex flex-col overflow-hidden">
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-200 truncate">{attachedFile.name}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-tighter">{attachedFile.mimeType}</span>
                  </div>
                </div>
                <button 
                  onClick={() => setAttachedFile(null)}
                  className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}

            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                  e.preventDefault();
                  handleSummarize();
                }
              }}
              placeholder={attachedFile ? "Add instructions for the summary (optional)..." : "Paste your long notes or text here, or upload a PDF/Image/Text file..."}
              className="w-full h-64 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none resize-none text-sm leading-relaxed text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600 transition-all"
            />
            
            <button
              onClick={handleSummarize}
              disabled={(!inputText.trim() && !attachedFile) || isSummarizing || isExtracting}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50 disabled:shadow-none"
            >
              {isSummarizing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              Summarize Content
            </button>
          </div>

          {/* Output */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Short Summary</label>
              {summary && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadSummary}
                    className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                    title="Download summary"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
            <div className="relative flex-1 min-h-[256px]">
              <div className="w-full h-full p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm leading-relaxed overflow-y-auto text-slate-700 dark:text-slate-200 custom-scrollbar transition-colors">
                {isSummarizing ? (
                  <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 italic">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Summarizing...
                  </div>
                ) : (
                  summary ? (
                    <div className="markdown-content whitespace-pre-wrap">
                      <Markdown>{summary}</Markdown>
                    </div>
                  ) : (
                    <span className="text-slate-400 dark:text-slate-600 italic">Short summary will appear here...</span>
                  )
                )}
              </div>
              {summary && (
                <div className="absolute bottom-2 right-2 flex gap-2">
                  <button
                    onClick={copyToClipboard}
                    className="p-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-lg shadow-sm hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                    title="Copy summary"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={saveSummary}
                    className="p-2 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-lg shadow-sm hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                    title="Save summary"
                  >
                    <Save className="w-4 h-4 text-indigo-500 dark:text-indigo-400" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Saved Summaries */}
        {savedSummaries.length > 0 && (
          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Saved Summaries</h3>
              <button 
                onClick={clearAllSaved}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid gap-3">
              {savedSummaries.map((save) => (
                <div key={save.id} className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col gap-2 group relative transition-colors">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    <span>{new Date(save.timestamp).toLocaleDateString()}</span>
                    <button 
                      onClick={() => deleteSaved(save.id)}
                      className="text-slate-300 dark:text-slate-600 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 italic">"{save.originalText}"</p>
                    <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium line-clamp-2">{save.summary}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
