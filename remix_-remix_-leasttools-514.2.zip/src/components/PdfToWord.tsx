import React, { useState, useEffect } from 'react';
import { Upload, FileText, Loader2, Trash2, FileType } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { saveAs } from 'file-saver';
import * as pdfjsLib from 'pdfjs-dist';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';

// Set worker path for pdfjs
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export default function PdfToWord() {
  const [file, setFile] = useState<{ data: string; name: string; type: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('pdf-to-word');
      if (savedState) {
        setFile(savedState.file || null);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('pdf-to-word', { file, filename });
    }
  }, [file, filename, isLoaded]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile && uploadedFile.type === 'application/pdf') {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFile({
          data: reader.result as string,
          name: uploadedFile.name,
          type: uploadedFile.type
        });
      };
      reader.readAsDataURL(uploadedFile);
    } else if (uploadedFile) {
      alert('Please upload a PDF file.');
    }
  };

  const convertPdfToWord = async () => {
    if (!file) return;

    setIsProcessing(true);

    try {
      const arrayBuffer = await (await fetch(file.data)).arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        fullText += pageText + '\n\n';
      }

      if (!fullText.trim()) {
        throw new Error("No text could be extracted from this PDF. It might be an image-only PDF.");
      }
      
      // Create Word Document
      const doc = new Document({
        sections: [
          {
            properties: {},
            children: fullText.split('\n').map(line => 
              new Paragraph({
                children: [new TextRun(line)],
              })
            ),
          },
        ],
      });

      const blob = await Packer.toBlob(doc);
      saveAs(blob, getDownloadFilename(filename || file.name, 'converted', 'docx'));

    } catch (error: any) {
      console.error(error);
      alert(error.message || 'Error converting PDF to Word');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileType className="w-5 h-5 text-blue-500" />
          <h2>PDF to Word Converter (Local)</h2>
        </div>
        {file && (
          <button
            onClick={() => {
              setFile(null);
            }}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        <div className="max-w-xl mx-auto space-y-6">
          <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-12 text-center ${file ? 'border-blue-200 dark:border-blue-900/50 bg-blue-50/30 dark:bg-blue-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 bg-slate-50 dark:bg-slate-950'}`}>
            {file ? (
              <div className="space-y-4">
                <div className="p-6 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center gap-2">
                  <FileText className="w-12 h-12 text-red-500" />
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[250px]">{file.name}</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest">PDF Document</p>
                </div>
                <button 
                  onClick={() => setFile(null)}
                  className="text-xs text-red-500 hover:text-red-600 font-medium underline"
                >
                  Change File
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-col items-center gap-2">
                  <Upload className="w-12 h-12 text-slate-400 dark:text-slate-600" />
                  <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                    <button onClick={() => document.getElementById('pdf-to-word-upload')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload PDF</button>
                    {" to convert"}
                  </p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-600 uppercase tracking-widest">Local Processing</p>
                </div>
                <input id="pdf-to-word-upload" type="file" accept="application/pdf" onChange={handleFileUpload} className="hidden" />
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="relative">
              <input
                type="text"
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                placeholder="Custom Filename (Optional)"
                className="w-full px-4 py-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all dark:text-slate-200"
              />
              <span className="absolute right-4 top-3.5 text-xs text-slate-400 dark:text-slate-600 pointer-events-none">.docx</span>
            </div>

            <button
              onClick={convertPdfToWord}
              disabled={!file || isProcessing}
              className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-blue-200 dark:shadow-none disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Extracting Text...
                </>
              ) : (
                <>
                  <FileType className="w-5 h-5" />
                  Convert to Word (.docx)
                </>
              )}
            </button>
          </div>

          <div className="p-4 bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-blue-800 dark:text-blue-300 uppercase tracking-wider">How it works</h3>
            <ul className="text-[10px] text-blue-700 dark:text-blue-400 space-y-1 list-disc pl-4">
              <li>Upload your PDF file.</li>
              <li>Text is extracted directly in your browser (No AI used).</li>
              <li>A new Word (.docx) document is generated and downloaded automatically.</li>
              <li>Note: Scanned PDFs (images) will not work with this local converter.</li>
            </ul>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
