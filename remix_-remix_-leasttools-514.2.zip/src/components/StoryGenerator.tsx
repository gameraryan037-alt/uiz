import React, { useState, useEffect } from 'react';
import { BookOpen, Send, Loader2, Copy, Check, Trash2, AlertCircle, Save, Sparkles, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

type Language = 'English' | 'Hindi' | 'Hinglish';
type WordLimit = '100-200' | '200-300' | '300-400' | '400-500';

interface SavedStory {
  id: string;
  words: string;
  story: string;
  language: Language;
  limit: WordLimit;
  timestamp: number;
}

export default function StoryGenerator() {
  const [words, setWords] = useState('');
  const [story, setStory] = useState('');
  const [language, setLanguage] = useState<Language>('English');
  const [limit, setLimit] = useState<WordLimit>('100-200');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [copied, setCopied] = useState(false);
  const [savedStories, setSavedStories] = useState<SavedStory[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('story-generator');
      if (savedState) {
        setWords(savedState.words || '');
        setStory(savedState.story || '');
        setLanguage(savedState.language || 'English');
        setLimit(savedState.limit || '100-200');
        setSavedStories(savedState.savedStories || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('story-generator', { words, story, language, limit, savedStories, filename });
    }
  }, [words, story, language, limit, savedStories, filename, isLoaded]);

  const downloadStory = () => {
    if (story) {
      const element = document.createElement('a');
      const file = new Blob([story], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'story', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const handleGenerate = async () => {
    if (!words.trim()) return;
    setIsGenerating(true);
    setError(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `Generate a creative story in ${language} using the following words: ${words}. 
      
      STRICT RULES:
      1. BOLD every word from the provided list whenever it appears in the story using markdown (e.g., **word**). This is mandatory.
      2. If the story language (${language}) is different from the language of the provided words (e.g., words are in English but story is in Hindi), then for each provided word, use its translated version in the story and put the original word in brackets next to it, and BOLD both. Example: **[translated_word] (**[original_word]**)**.
      3. The story should be approximately ${limit} words long.
      4. If the language is Hinglish, it means Hindi written in English script.
      5. Provide a catchy title at the very beginning of the story, followed by a double newline.
      6. Only return the title and the story text, nothing else.
      7. Do not use any other markdown formatting except for bolding the provided words.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      setStory(response.text?.trim() || '');
    } catch (err: any) {
      setError(handleGeminiError(err));
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(story);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const saveStory = () => {
    if (!words || !story) return;
    const newSave: SavedStory = {
      id: Math.random().toString(36).substring(7),
      words,
      story,
      language,
      limit,
      timestamp: Date.now()
    };
    setSavedStories(prev => [newSave, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedStories(prev => prev.filter(s => s.id !== id));
  };

  const clearAllSaved = () => {
    if (confirm('Clear all saved stories?')) {
      setSavedStories([]);
    }
  };

  const languages: Language[] = ['English', 'Hindi', 'Hinglish'];
  const limits: WordLimit[] = ['100-200', '200-300', '300-400', '400-500'];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <BookOpen className="w-5 h-5 text-emerald-500" />
          <h2>AI Story Generator</h2>
        </div>
        <div className="flex items-center gap-2">
          {(words || story) && (
            <button
              onClick={() => {
                setWords('');
                setStory('');
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {error && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Input Section */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Enter Words / Keywords</label>
              <textarea
                value={words}
                onChange={(e) => setWords(e.target.value)}
                placeholder="Enter some words to include in the story (e.g., forest, robot, mystery, rain)..."
                className="w-full h-40 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 dark:focus:ring-emerald-900/30 outline-none resize-none text-sm leading-relaxed text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Language</label>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value as Language)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm font-medium focus:border-emerald-500 outline-none text-slate-700 dark:text-slate-200 transition-all"
                >
                  {languages.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Word Limit</label>
                <select
                  value={limit}
                  onChange={(e) => setLimit(e.target.value as WordLimit)}
                  className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm font-medium focus:border-emerald-500 outline-none text-slate-700 dark:text-slate-200 transition-all"
                >
                  {limits.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={!words.trim() || isGenerating}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-100 dark:shadow-none disabled:opacity-50 disabled:shadow-none"
            >
              {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              Generate Story
            </button>
          </div>

          {/* Result Section */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Generated Story</label>
              {story && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadStory}
                    className="p-2 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
                    title="Download story"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={copyToClipboard}
                    className="p-2 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
                    title="Copy story"
                  >
                    {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={saveStory}
                    className="p-2 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
                    title="Save story"
                  >
                    <Save className="w-4 h-4 text-emerald-500" />
                  </button>
                </div>
              )}
            </div>
            <div className="flex-1 min-h-[300px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 text-sm leading-relaxed text-slate-700 dark:text-slate-200 overflow-y-auto transition-all shadow-inner custom-scrollbar">
              {isGenerating ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 italic">
                  <Loader2 className="w-8 h-8 animate-spin mb-2" />
                  Generating your story...
                </div>
              ) : (
                story ? (
                  <div className="markdown-content whitespace-pre-wrap">
                    <Markdown>{story}</Markdown>
                  </div>
                ) : (
                  <span className="text-slate-400 dark:text-slate-600 italic">Your story will appear here...</span>
                )
              )}
            </div>
          </div>
        </div>

        {/* Saved Stories */}
        {savedStories.length > 0 && (
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Saved Stories</h3>
              <button 
                onClick={clearAllSaved}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid gap-4">
              {savedStories.map((save) => (
                <div key={save.id} className="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col gap-3 group relative transition-colors">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    <span>{save.language} • {save.limit} Words</span>
                    <button 
                      onClick={() => deleteSaved(save.id)}
                      className="text-slate-300 dark:text-slate-600 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium uppercase tracking-wider">Words used: {save.words}</p>
                    <div className="markdown-content text-xs text-slate-600 dark:text-slate-400 line-clamp-3 leading-relaxed">
                      <Markdown>{save.story}</Markdown>
                    </div>
                  </div>
                  <button 
                    onClick={() => setStory(save.story)}
                    className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 uppercase tracking-wider self-start"
                  >
                    Load Full Story
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
