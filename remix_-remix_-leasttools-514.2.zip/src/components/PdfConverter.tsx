import React, { useState, useRef, useEffect } from 'react';
import { FileText, Image as ImageIcon, Download, Upload, Loader2, X, FileUp, FileDown, AlertCircle, Plus, Trash2, MoveUp, MoveDown, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { jsPDF } from "jspdf";
import * as pdfjsLib from 'pdfjs-dist';
import { PDFDocument } from 'pdf-lib';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';

// Set worker path for pdfjs
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

type Mode = 'img-to-pdf' | 'pdf-to-img' | 'merge-pdf';

export default function PdfConverter() {
  const [mode, setMode] = useState<Mode>('img-to-pdf');
  const [images, setImages] = useState<{ id: string; file: File; url: string }[]>([]);
  const [isA4Mode, setIsA4Mode] = useState(false);
  const [customFileName, setCustomFileName] = useState('');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [mergeFiles, setMergeFiles] = useState<{ id: string; file: File; pageCount?: number }[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRearranging, setIsRearranging] = useState(false);
  const [isRearrangingImages, setIsRearrangingImages] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mergeInputRef = useRef<HTMLInputElement>(null);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('pdf-converter');
      if (savedState) {
        setIsA4Mode(savedState.isA4Mode ?? false);
        setCustomFileName(savedState.customFileName || '');
        setMode(savedState.mode || 'img-to-pdf');

        if (savedState.images) {
          const restoredImages = savedState.images.map((img: any) => ({
            ...img,
            url: URL.createObjectURL(img.file)
          }));
          setImages(restoredImages);
        }

        if (savedState.mergeFiles) {
          setMergeFiles(savedState.mergeFiles);
        }

        if (savedState.pdfFile) {
          setPdfFile(savedState.pdfFile);
        }
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      // Don't save the blob URLs, just the files and IDs
      const imagesToSave = images.map(({ id, file }) => ({ id, file }));
      saveToolState('pdf-converter', { 
        isA4Mode, 
        customFileName, 
        mode,
        images: imagesToSave,
        mergeFiles,
        pdfFile
      });
    }
  }, [isA4Mode, customFileName, mode, images, mergeFiles, pdfFile, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      const newImages = files.map(file => ({
        id: Math.random().toString(36).substring(7),
        file,
        url: URL.createObjectURL(file)
      }));
      setImages(prev => [...prev, ...newImages]);
      setError(null);
    }
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const filtered = prev.filter(img => img.id !== id);
      const removed = prev.find(img => img.id === id);
      if (removed) URL.revokeObjectURL(removed.url);
      return filtered;
    });
  };

  const convertToPdf = async () => {
    if (images.length === 0) return;
    setIsProcessing(true);
    setError(null);

    try {
      let pdf: jsPDF | null = null;
      
      for (let i = 0; i < images.length; i++) {
        const img = images[i];
        
        // Get image dimensions
        const imgObj = new Image();
        imgObj.src = img.url;
        await new Promise((resolve) => {
          imgObj.onload = resolve;
        });

        const imgWidthPx = imgObj.width;
        const imgHeightPx = imgObj.height;
        
        // Convert px to mm (approx 96 DPI)
        const pxToMm = 0.264583;
        const imgWidthMm = imgWidthPx * pxToMm;
        const imgHeightMm = imgHeightPx * pxToMm;

        if (isA4Mode) {
          const a4Width = 210;
          const a4Height = 297;

          if (!pdf) {
            pdf = new jsPDF({
              orientation: 'p',
              unit: 'mm',
              format: 'a4'
            });
          } else {
            pdf.addPage('a4', 'p');
          }
          
          // Calculate scaling to fill A4 while maintaining aspect ratio
          const ratio = Math.min(a4Width / imgWidthMm, a4Height / imgHeightMm);
          const drawWidth = imgWidthMm * ratio;
          const drawHeight = imgHeightMm * ratio;
          
          const x = (a4Width - drawWidth) / 2;
          const y = (a4Height - drawHeight) / 2;
          
          pdf.addImage(img.url, 'JPEG', x, y, drawWidth, drawHeight, undefined, 'FAST');
        } else {
          // Original size mode
          const orientation = imgWidthMm > imgHeightMm ? 'l' : 'p';
          if (!pdf) {
            pdf = new jsPDF({
              orientation,
              unit: 'mm',
              format: [imgWidthMm, imgHeightMm]
            });
          } else {
            pdf.addPage([imgWidthMm, imgHeightMm], orientation);
          }
          pdf.addImage(img.url, 'JPEG', 0, 0, imgWidthMm, imgHeightMm, undefined, 'FAST');
        }
      }

      if (pdf) pdf.save(getDownloadFilename(customFileName, 'pdf', 'pdf'));
    } catch (err) {
      console.error(err);
      setError('Failed to convert images to PDF.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
      setError(null);
    } else {
      setError('Please upload a valid PDF file.');
    }
  };

  const handleMergeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      const validFiles = files.filter(f => f.type === 'application/pdf');
      
      if (validFiles.length < files.length) {
        setError('Some files were skipped because they were not valid PDFs.');
      }

      const newFiles = await Promise.all(validFiles.map(async (file) => {
        try {
          const arrayBuffer = await file.arrayBuffer();
          const pdf = await PDFDocument.load(arrayBuffer);
          return {
            id: Math.random().toString(36).substring(7),
            file,
            pageCount: pdf.getPageCount()
          };
        } catch (err) {
          console.error('Error loading PDF:', err);
          return {
            id: Math.random().toString(36).substring(7),
            file,
            pageCount: 0
          };
        }
      }));
      setMergeFiles(prev => [...prev, ...newFiles]);
    }
  };

  const removeMergeFile = (id: string) => {
    setMergeFiles(prev => prev.filter(f => f.id !== id));
  };

  const mergePdfs = async () => {
    if (mergeFiles.length < 2) {
      setError('Please select at least two PDF files to merge.');
      return;
    }
    setIsProcessing(true);
    setError(null);

    try {
      const mergedPdf = await PDFDocument.create();
      
      for (const fileObj of mergeFiles) {
        const arrayBuffer = await fileObj.file.arrayBuffer();
        const pdf = await PDFDocument.load(arrayBuffer);
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }

      const pdfBytes = await mergedPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      saveAs(blob, getDownloadFilename(customFileName, 'pdf', 'pdf'));
    } catch (err) {
      console.error(err);
      setError('Failed to merge PDF files.');
    } finally {
      setIsProcessing(false);
    }
  };

  const convertToImages = async () => {
    if (!pdfFile) return;
    setIsProcessing(true);
    setError(null);

    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const zip = new JSZip();
      const numPages = pdf.numPages;

      for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (!context) continue;
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext: any = {
          canvasContext: context,
          viewport: viewport,
        };

        await page.render(renderContext).promise;
        
        const imgBlob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'));
        if (imgBlob) {
          zip.file(`page-${i}.png`, imgBlob);
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, getDownloadFilename(customFileName, 'zip', 'zip'));
    } catch (err) {
      console.error(err);
      setError('Failed to convert PDF to images.');
    } finally {
      setIsProcessing(false);
    }
  };

  const totalPages = mergeFiles.reduce((sum, f) => sum + (f.pageCount || 0), 0);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileText className="w-5 h-5 text-red-500" />
          <h2>PDF Converter</h2>
        </div>
        <div className="flex bg-slate-200 dark:bg-slate-800 p-1 rounded-lg transition-colors">
          <button
            onClick={() => setMode('img-to-pdf')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'img-to-pdf' ? 'bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            Image to PDF
          </button>
          <button
            onClick={() => setMode('pdf-to-img')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'pdf-to-img' ? 'bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            PDF to Image
          </button>
          <button
            onClick={() => setMode('merge-pdf')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'merge-pdf' ? 'bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            Merge PDF
          </button>
        </div>
      </div>

      <div className="p-6 flex-1 flex flex-col gap-6">
        {mode === 'img-to-pdf' ? (
          <div className="space-y-4 flex-1 flex flex-col">
            <div 
              className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center hover:border-red-400 dark:hover:border-red-600 hover:bg-red-50/30 dark:hover:bg-red-900/10 transition-all cursor-pointer group"
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <ImageIcon className="w-6 h-6" />
              </div>
              <h3 className="text-slate-900 dark:text-white font-medium mb-1">Upload Images</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Select one or more images to combine into a PDF</p>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageUpload}
                accept="image/*"
                multiple
                className="hidden"
              />
            </div>

            {images.length > 0 && (
              <div className="flex-1 space-y-4 flex flex-col">
                <div className="flex items-center justify-between px-1">
                  <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{images.length} Images Added</p>
                  <button
                    onClick={() => setIsRearrangingImages(!isRearrangingImages)}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${isRearrangingImages ? 'bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    {isRearrangingImages ? 'Done' : 'Rearrange'}
                  </button>
                </div>

                <div className="flex-1 min-h-0">
                  {isRearrangingImages ? (
                    <Reorder.Group 
                      axis="y" 
                      values={images} 
                      onReorder={setImages}
                      className="space-y-2 max-h-[400px] overflow-y-auto p-2 custom-scrollbar"
                    >
                      {images.map((img) => (
                        <Reorder.Item 
                          key={img.id} 
                          value={img}
                          className="flex items-center gap-3 p-2 bg-white dark:bg-slate-800 rounded-xl border-2 border-red-400 dark:border-red-600 shadow-sm cursor-grab active:cursor-grabbing"
                          whileDrag={{ scale: 1.01 }}
                        >
                          <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700">
                            <img src={img.url} alt="Preview" className="w-full h-full object-cover pointer-events-none" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{img.file.name}</p>
                            <p className="text-[10px] text-slate-400 dark:text-slate-500">{(img.file.size / 1024).toFixed(1)} KB</p>
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              removeImage(img.id);
                            }}
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                            title="Remove image"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </Reorder.Item>
                      ))}
                    </Reorder.Group>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 max-h-[300px] overflow-y-auto p-2 custom-scrollbar">
                      {images.map((img) => (
                        <div key={img.id} className="relative group aspect-square rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800">
                          <img src={img.url} alt="Preview" className="w-full h-full object-cover" />
                          <button
                            onClick={() => removeImage(img.id)}
                            className="absolute top-1.5 right-1.5 p-1.5 bg-red-500/90 hover:bg-red-600 text-white rounded-full shadow-sm transition-all"
                            title="Remove image"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                <div className="flex items-center justify-between p-3 bg-slate-200/50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isA4Mode ? 'bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400' : 'bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400'}`}>
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-200">A4 Page Mode</p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">{isA4Mode ? 'Standard 210x297mm centered' : 'Original image dimensions'}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsA4Mode(!isA4Mode)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${isA4Mode ? 'bg-red-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isA4Mode ? 'translate-x-6' : 'translate-x-1'}`}
                    />
                  </button>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider ml-1">Output Filename</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={customFileName}
                      onChange={(e) => setCustomFileName(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-full pl-3 pr-12 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:focus:ring-red-900/30 outline-none text-sm text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-3 top-2 text-slate-400 dark:text-slate-600 text-xs pointer-events-none">.pdf</span>
                  </div>
                </div>
                
                <button
                  onClick={convertToPdf}
                  disabled={isProcessing}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-red-100 dark:shadow-none"
                >
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileDown className="w-5 h-5" />}
                  Convert to PDF
                </button>
              </div>
            )}
          </div>
        ) : mode === 'pdf-to-img' ? (
          <div className="space-y-4 flex-1 flex flex-col justify-center">
            {!pdfFile ? (
              <div 
                className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center hover:border-red-400 dark:hover:border-red-600 hover:bg-red-50/30 dark:hover:bg-red-900/10 transition-all cursor-pointer group"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <FileUp className="w-8 h-8" />
                </div>
                <h3 className="text-slate-900 dark:text-white font-lg font-medium mb-1">Select PDF File</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Upload a PDF to extract all pages as images</p>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handlePdfUpload}
                  accept="application/pdf"
                  className="hidden"
                />
              </div>
            ) : (
              <div className="bg-slate-200/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-xl p-6 text-center">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-6 h-6" />
                </div>
                <h3 className="text-slate-900 dark:text-white font-medium mb-1 truncate px-4">{pdfFile.name}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs mb-4">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                
                <div className="mb-6 text-left space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider ml-1">Output ZIP Filename</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={customFileName}
                      onChange={(e) => setCustomFileName(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-full pl-3 pr-12 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:focus:ring-red-900/30 outline-none text-sm text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-3 top-2 text-slate-400 dark:text-slate-600 text-xs pointer-events-none">.zip</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setPdfFile(null)}
                    className="flex-1 py-2.5 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 rounded-lg font-medium hover:bg-white dark:hover:bg-slate-800 transition-all"
                  >
                    Change File
                  </button>
                  <button
                    onClick={convertToImages}
                    disabled={isProcessing}
                    className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-red-100 dark:shadow-none"
                  >
                    {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    Extract Images
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 flex-1 flex flex-col">
            <div 
              className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center hover:border-red-400 dark:hover:border-red-600 hover:bg-red-50/30 dark:hover:bg-red-900/10 transition-all cursor-pointer group"
              onClick={() => mergeInputRef.current?.click()}
            >
              <div className="w-12 h-12 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Plus className="w-6 h-6" />
              </div>
              <h3 className="text-slate-900 dark:text-white font-medium mb-1">Add PDF Files</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Select multiple PDFs to merge them into one</p>
              <input
                type="file"
                ref={mergeInputRef}
                onChange={handleMergeUpload}
                accept="application/pdf"
                multiple
                className="hidden"
              />
            </div>

            {mergeFiles.length > 0 && (
              <div className="flex-1 space-y-4 flex flex-col">
                <div className="flex items-center justify-between px-1">
                  <div className="flex flex-col">
                    <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{mergeFiles.length} Files Added</p>
                    {totalPages > 0 && (
                      <p className="text-[10px] text-red-500 dark:text-red-400 font-bold uppercase tracking-tight">Total: {totalPages} {totalPages === 1 ? 'page' : 'pages'}</p>
                    )}
                  </div>
                  <button
                    onClick={() => setIsRearranging(!isRearranging)}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all ${isRearranging ? 'bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    {isRearranging ? 'Done' : 'Rearrange'}
                  </button>
                </div>

                <div className="flex-1 min-h-0">
                  {isRearranging ? (
                    <Reorder.Group 
                      axis="y" 
                      values={mergeFiles} 
                      onReorder={setMergeFiles}
                      className="space-y-2 max-h-[300px] overflow-y-auto p-2 custom-scrollbar"
                    >
                      {mergeFiles.map((fileObj) => (
                        <Reorder.Item 
                          key={fileObj.id} 
                          value={fileObj}
                          className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-xl border border-indigo-200 dark:border-indigo-700 shadow-sm cursor-grab active:cursor-grabbing"
                          whileDrag={{ scale: 1.01 }}
                        >
                          <div className="w-8 h-8 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 rounded-lg flex items-center justify-center shrink-0">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{fileObj.file.name}</p>
                            {fileObj.pageCount !== undefined && (
                              <p className="text-[10px] text-indigo-500 dark:text-indigo-400 font-medium">{fileObj.pageCount} {fileObj.pageCount === 1 ? 'page' : 'pages'}</p>
                            )}
                          </div>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              removeMergeFile(fileObj.id);
                            }}
                            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                            title="Remove file"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </Reorder.Item>
                      ))}
                    </Reorder.Group>
                  ) : (
                    <div className="space-y-2 max-h-[300px] overflow-y-auto p-2 custom-scrollbar">
                      {mergeFiles.map((fileObj, index) => (
                        <div key={fileObj.id} className="flex items-center gap-3 p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 group transition-all">
                          <div className="w-8 h-8 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-lg flex items-center justify-center shrink-0">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate">{fileObj.file.name}</p>
                            <div className="flex items-center gap-2">
                              <p className="text-[10px] text-slate-400 dark:text-slate-500">{(fileObj.file.size / 1024 / 1024).toFixed(2)} MB</p>
                              {fileObj.pageCount !== undefined && (
                                <>
                                  <span className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700" />
                                  <p className="text-[10px] text-red-500 dark:text-red-400 font-medium">{fileObj.pageCount} {fileObj.pageCount === 1 ? 'page' : 'pages'}</p>
                                </>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 transition-opacity">
                            <button
                              onClick={() => removeMergeFile(fileObj.id)}
                              className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider ml-1">Output Filename</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={customFileName}
                      onChange={(e) => setCustomFileName(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-full pl-3 pr-12 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-red-500 focus:ring-2 focus:ring-red-100 dark:focus:ring-red-900/30 outline-none text-sm text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-3 top-2 text-slate-400 dark:text-slate-600 text-xs pointer-events-none">.pdf</span>
                  </div>
                </div>

                <button
                  onClick={mergePdfs}
                  disabled={isProcessing || mergeFiles.length < 2}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-lg shadow-red-100 dark:shadow-none"
                >
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileDown className="w-5 h-5" />}
                  Merge PDF Files
                </button>
              </div>
            )}
          </div>
        )}

        {error && (
          <div className="flex items-center gap-2 text-red-500 text-sm bg-red-50 dark:bg-red-900/20 p-3 rounded-lg">
            <AlertCircle className="w-4 h-4" />
            {error}
          </div>
        )}
      </div>
    </motion.div>
  );
}
