import React, { useState, useEffect, useRef } from 'react';
import { HelpCircle, Send, Loader2, CheckCircle2, XCircle, RefreshCw, Trophy, ChevronRight, ChevronLeft, FileText, BookOpen, Save, Trash2, Upload, Zap, Share2, Users, Copy, Check, Lock, Wifi, WifiOff, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";
import { getGeminiApiKey, cleanAIJsonResponse, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import { Download } from 'lucide-react';
import { io, Socket } from 'socket.io-client';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface Quiz {
  title: string;
  questions: Question[];
}

type Tab = 'paste' | 'curriculum' | 'pyq';
type Board = 'CBSE' | 'ICSE';
type Difficulty = 'Easy' | 'Medium' | 'Hard';
type QuestionType = 'MCQ' | 'T/F' | 'Assertion-Reason' | 'Mixed';

interface SavedQuiz {
  id: string;
  quiz: Quiz;
  timestamp: number;
}

export default function QuizMaker() {
  const [activeTab, setActiveTab] = useState<Tab>('paste');
  const [input, setInput] = useState('');
  
  // Curriculum States
  const [board, setBoard] = useState<Board>('CBSE');
  const [grade, setGrade] = useState('');
  const [subject, setSubject] = useState('');
  const [chapter, setChapter] = useState('');
  const [examType, setExamType] = useState('JEE Mains');
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [numQuestions, setNumQuestions] = useState('5');
  const [customNumQuestions, setCustomNumQuestions] = useState('');
  const [questionType, setQuestionType] = useState<QuestionType>('Mixed');

  const [isLoading, setIsLoading] = useState(false);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedQuizzes, setSavedQuizzes] = useState<SavedQuiz[]>([]);

  // Multiplayer States
  const [isMultiplayer, setIsMultiplayer] = useState(false);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [playerName, setPlayerName] = useState('');
  const [isNameSubmitted, setIsNameSubmitted] = useState(false);
  const [players, setPlayers] = useState<{ id: string; name: string; score: number; completed: boolean }[]>([]);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [joinCode, setJoinCode] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('quiz-maker');
      if (savedState) {
        setActiveTab(savedState.activeTab || 'paste');
        setInput(savedState.input || '');
        setBoard(savedState.board || 'CBSE');
        setGrade(savedState.grade || '');
        setSubject(savedState.subject || '');
        setChapter(savedState.chapter || '');
        setDifficulty(savedState.difficulty || 'Medium');
        setNumQuestions(savedState.numQuestions || '5');
        setCustomNumQuestions(savedState.customNumQuestions || '');
        setQuestionType(savedState.questionType || 'Mixed');
        setExamType(savedState.examType || 'JEE Mains');
        setQuiz(savedState.quiz || null);
        setCurrentQuestionIndex(savedState.currentQuestionIndex || 0);
        setScore(savedState.score || 0);
        setShowResults(savedState.showResults || false);
        setUserAnswers(savedState.userAnswers || []);
        setSavedQuizzes(savedState.savedQuizzes || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('quiz-maker', {
        activeTab, input, board, grade, subject, chapter, difficulty,
        numQuestions, customNumQuestions, questionType, examType, quiz,
        currentQuestionIndex, score, showResults, userAnswers, savedQuizzes,
        filename
      });
    }
  }, [
    activeTab, input, board, grade, subject, chapter, difficulty,
    numQuestions, customNumQuestions, questionType, examType, quiz,
    currentQuestionIndex, score, showResults, userAnswers, savedQuizzes, filename, isLoaded
  ]);

  useEffect(() => {
    // URL-based joining removed as per user request for "code only"
  }, []);

  useEffect(() => {
    if (isMultiplayer && !socket) {
      // Use relative path so it works on any domain/proxy
      const newSocket = io({
        path: '/socket.io',
        transports: ['websocket', 'polling']
      });
      setSocket(newSocket);

      newSocket.on('connect', () => setIsConnected(true));
      newSocket.on('disconnect', () => setIsConnected(false));

      newSocket.on('room-update', (data: { quiz: Quiz; players: any[] }) => {
        if (data.quiz) setQuiz(data.quiz);
        setPlayers(data.players);
      });

      return () => {
        newSocket.disconnect();
      };
    }
  }, [isMultiplayer]);

  useEffect(() => {
    if (socket && roomId && playerName && isNameSubmitted) {
      socket.emit('join-room', { roomId, playerName, quiz: quiz || null });
    }
  }, [socket, roomId, isNameSubmitted]);

  useEffect(() => {
    if (socket && roomId && isMultiplayer) {
      socket.emit('update-score', { roomId, score, completed: showResults });
    }
  }, [score, showResults, socket, roomId]);

  const createRoom = () => {
    const newRoomId = Math.random().toString(36).substring(2, 9);
    setRoomId(newRoomId);
    setIsMultiplayer(true);
    setIsNameSubmitted(false);
    setShowShareModal(true);
  };

  const copyShareLink = () => {
    const url = `${window.location.origin}${window.location.pathname}?room=${roomId}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleJoinRoom = () => {
    if (joinCode.trim()) {
      const cleanCode = joinCode.trim().toUpperCase();
      setRoomId(cleanCode);
      setIsMultiplayer(true);
      setIsNameSubmitted(false);
      setShowJoinModal(false);
    }
  };

  const downloadQuiz = () => {
    if (quiz) {
      let content = `${quiz.title}\n\n`;
      quiz.questions.forEach((q, i) => {
        content += `${i + 1}. ${q.question}\n`;
        q.options.forEach((opt, j) => {
          content += `   ${String.fromCharCode(65 + j)}) ${opt}\n`;
        });
        content += `\nCorrect Answer: ${String.fromCharCode(65 + q.correctAnswer)}\n`;
        content += `Explanation: ${q.explanation}\n\n`;
      });

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'quiz', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const generateQuiz = async () => {
    const finalNumQuestions = numQuestions === 'custom' ? parseInt(customNumQuestions) : parseInt(numQuestions);
    
    if (activeTab === 'paste') {
      if (!input.trim()) return;
      const wordCount = input.trim().split(/\s+/).length;
      if (wordCount < 20) {
        setError("Please provide at least 20 words of text for better quiz generation.");
        return;
      }
    }
    
    if (activeTab === 'curriculum' && (!grade || !subject || !chapter)) {
      setError("Please fill in all curriculum details.");
      return;
    }

    if (activeTab === 'pyq' && (!subject || !chapter)) {
      setError("Please fill in subject and chapter details.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setQuiz(null);
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowResults(false);
    setUserAnswers([]);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      let prompt = "";
      const isScienceSubject = subject.toLowerCase().includes('physic') || subject.toLowerCase().includes('chemist');
      
      if (activeTab === 'paste') {
        prompt = `Generate a ${difficulty} difficulty quiz based on the following text: "${input}". 
        Question Type: ${questionType}.
        ${isScienceSubject ? 'IMPORTANT: Since this is a Science subject, please include at least 2-3 numerical/calculation-based questions.' : ''}
        ${questionType === 'Mixed' ? 'IMPORTANT: The quiz MUST contain exactly 50% Multiple Choice Questions (MCQ), 30% True/False (T/F), and 20% Assertion-Reasoning questions.' : ''}
        Return a JSON object with a "title" and an array of ${finalNumQuestions} "questions". 
        Each question should have "question" (string), "options" (array of 4 strings), "correctAnswer" (index 0-3), and "explanation" (string).
        If the question type is T/F, provide only 2 options: ["True", "False"].
        If the question type is Assertion-Reason, follow the standard format (A: Assertion, R: Reason) with 4 standard options.`;
      } else if (activeTab === 'curriculum') {
        prompt = `Generate a ${difficulty} difficulty quiz for ${board} board, Class ${grade}, Subject: ${subject}, Chapter: ${chapter}.
        Question Type: ${questionType}.
        ${isScienceSubject ? 'IMPORTANT: Since this is a Science subject, please include at least 2-3 numerical/calculation-based questions.' : ''}
        ${questionType === 'Mixed' ? 'IMPORTANT: The quiz MUST contain exactly 50% Multiple Choice Questions (MCQ), 30% True/False (T/F), and 20% Assertion-Reasoning questions.' : ''}
        Return a JSON object with a "title" (e.g., "${subject}: ${chapter}") and an array of ${finalNumQuestions} "questions". 
        Each question should have "question" (string), "options" (array of 4 strings), "correctAnswer" (index 0-3), and "explanation" (string).
        If the question type is T/F, provide only 2 options: ["True", "False"].
        If the question type is Assertion-Reason, follow the standard format (A: Assertion, R: Reason) with 4 standard options.`;
      } else {
        prompt = `Generate a quiz consisting of actual or highly similar Previous Year Questions (PYQs) for the ${examType} exam.
        Subject: ${subject}, Chapter: ${chapter}, Difficulty: ${difficulty}.
        Question Type: ${questionType}.
        Return a JSON object with a "title" (e.g., "${examType} PYQs: ${chapter}") and an array of ${finalNumQuestions} "questions". 
        Each question should have "question" (string), "options" (array of 4 strings), "correctAnswer" (index 0-3), and "explanation" (string).
        Ensure the questions are representative of the ${examType} style and difficulty level.`;
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    question: { type: Type.STRING },
                    options: { type: Type.ARRAY, items: { type: Type.STRING } },
                    correctAnswer: { type: Type.INTEGER },
                    explanation: { type: Type.STRING }
                  },
                  required: ["question", "options", "correctAnswer", "explanation"]
                }
              }
            },
            required: ["title", "questions"]
          }
        }
      });

      const data = cleanAIJsonResponse(response);
      setQuiz(data);
    } catch (err) {
      setError(handleGeminiError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleAnswerSelect = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    
    const newUserAnswers = [...userAnswers];
    newUserAnswers[currentQuestionIndex] = index;
    setUserAnswers(newUserAnswers);

    if (index === quiz?.questions[currentQuestionIndex].correctAnswer) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(userAnswers[currentQuestionIndex + 1] ?? null);
    } else {
      setShowResults(true);
    }
  };

  const prevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setSelectedAnswer(userAnswers[currentQuestionIndex - 1] ?? null);
    }
  };

  const resetQuiz = () => {
    setQuiz(null);
    setInput('');
    setShowResults(false);
    setScore(0);
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setSelectedAnswer(null);
    setError(null);
  };

  const saveQuiz = () => {
    if (!quiz) return;
    const newSave: SavedQuiz = {
      id: Math.random().toString(36).substring(7),
      quiz,
      timestamp: Date.now()
    };
    setSavedQuizzes(prev => [newSave, ...prev]);
  };

  const deleteSavedQuiz = (id: string) => {
    setSavedQuizzes(prev => prev.filter(q => q.id !== id));
  };

  const loadSavedQuiz = (saved: SavedQuiz) => {
    setQuiz(saved.quiz);
    setCurrentQuestionIndex(0);
    setScore(0);
    setShowResults(false);
    setUserAnswers([]);
    setSelectedAnswer(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <HelpCircle className="w-5 h-5 text-emerald-500" />
          <h2>Quiz Maker</h2>
        </div>
        <div className="flex items-center gap-2">
          {!quiz && !isMultiplayer && (
            <button
              onClick={() => setShowJoinModal(true)}
              className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 dark:bg-indigo-900/20 px-3 py-1.5 rounded-lg transition-all"
            >
              <Users className="w-3.5 h-3.5" /> Join Room
            </button>
          )}
          {quiz && !isMultiplayer && (
            <button
              onClick={createRoom}
              className="flex items-center gap-1 text-xs font-bold text-amber-600 hover:text-amber-700 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-lg transition-all"
            >
              <Users className="w-3.5 h-3.5" /> Challenge Friend
            </button>
          )}
          {isMultiplayer && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
              <div className="relative">
                <Users className="w-3.5 h-3.5 text-indigo-600" />
                <div className={`absolute -top-1 -right-1 w-2 h-2 rounded-full border border-white dark:border-slate-900 ${isConnected ? 'bg-emerald-500' : 'bg-red-500'}`} />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-indigo-600">{players.length} Players</span>
                <span className="text-[8px] font-medium text-indigo-400 uppercase tracking-tighter">Room: {roomId}</span>
              </div>
              <button onClick={() => setShowShareModal(true)} className="ml-2 text-indigo-400 hover:text-indigo-600">
                <Share2 className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {quiz && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                />
                <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
              </div>
              <button
                onClick={downloadQuiz}
                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                title="Download Quiz"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          )}
          {quiz && (
            <button
              onClick={saveQuiz}
              className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
              title="Save Quiz"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          {quiz && (
            <button 
              onClick={resetQuiz}
              className="text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition-colors"
            >
              <RefreshCw className="w-3 h-3" /> New Quiz
            </button>
          )}
        </div>
      </div>

      <div className="p-6 flex-1 flex flex-col overflow-y-auto custom-scrollbar">
        {!quiz && !showResults ? (
          <div className="max-w-4xl mx-auto w-full space-y-8">
            <div className="text-center space-y-2">
              <h1 className="text-4xl font-black text-indigo-900 dark:text-indigo-400 flex items-center justify-center gap-2">
                QuizGen AI
              </h1>
              <p className="text-slate-500 dark:text-slate-400 text-sm">The ultimate quiz engine. Use curriculum knowledge or your own study materials.</p>
              
              <div className="pt-4 flex justify-center">
                <button
                  onClick={() => setShowJoinModal(true)}
                  className="flex items-center gap-2 px-6 py-2 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-full border border-indigo-100 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-all text-sm font-bold shadow-sm"
                >
                  <Users className="w-4 h-4" />
                  Have a Room Code? Join Now
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl max-w-xl mx-auto transition-colors">
              <button
                onClick={() => setActiveTab('paste')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-[10px] sm:text-sm font-medium rounded-lg transition-all ${
                  activeTab === 'paste' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                <FileText className="w-4 h-4" /> Paste Text
              </button>
              <button
                onClick={() => setActiveTab('curriculum')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-[10px] sm:text-sm font-medium rounded-lg transition-all ${
                  activeTab === 'curriculum' ? 'bg-white dark:bg-slate-700 text-emerald-600 dark:text-emerald-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                <BookOpen className="w-4 h-4" /> Curriculum
              </button>
              <button
                onClick={() => setActiveTab('pyq')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-[10px] sm:text-sm font-medium rounded-lg transition-all ${
                  activeTab === 'pyq' ? 'bg-white dark:bg-slate-700 text-amber-600 dark:text-amber-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                }`}
              >
                <Zap className="w-4 h-4" /> PYQ Mode
              </button>
            </div>

            <div className="bg-white dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800 rounded-2xl p-8 shadow-sm transition-colors">
              {activeTab === 'paste' ? (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">Generate from Text</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">AI will generate questions based on the text you provide.</p>
                  </div>
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Paste your study material or notes here (minimum 20 words)..."
                    className="w-full h-48 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none resize-none font-sans text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                  />

                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Difficulty</label>
                      <select 
                        value={difficulty} 
                        onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Questions</label>
                      <select 
                        value={numQuestions} 
                        onChange={(e) => setNumQuestions(e.target.value)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="5">5 Questions</option>
                        <option value="10">10 Questions</option>
                        <option value="20">20 Questions</option>
                        <option value="custom">Custom</option>
                      </select>
                      {numQuestions === 'custom' && (
                        <input 
                          type="number" 
                          value={customNumQuestions}
                          onChange={(e) => setCustomNumQuestions(e.target.value)}
                          placeholder="Enter number"
                          className="mt-2 w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                        />
                      )}
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Question Type</label>
                      <select 
                        value={questionType} 
                        onChange={(e) => setQuestionType(e.target.value as QuestionType)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="MCQ">MCQ</option>
                        <option value="T/F">True / False</option>
                        <option value="Assertion-Reason">Assertion-Reason</option>
                        <option value="Mixed">Mixed (All)</option>
                      </select>
                    </div>
                  </div>
                </div>
              ) : activeTab === 'curriculum' ? (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">Generate from Knowledge Base</h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">AI will generate questions based on curriculum standards.</p>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Board</label>
                      <select 
                        value={board} 
                        onChange={(e) => setBoard(e.target.value as Board)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="CBSE">CBSE</option>
                        <option value="ICSE">ICSE</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Class / Grade</label>
                      <input 
                        type="text" 
                        value={grade}
                        onChange={(e) => setGrade(e.target.value)}
                        placeholder="e.g. 10"
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Subject Name</label>
                      <input 
                        type="text" 
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        placeholder="e.g. Science"
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Chapter Name</label>
                      <input 
                        type="text" 
                        value={chapter}
                        onChange={(e) => setChapter(e.target.value)}
                        placeholder="e.g. Life Processes"
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Difficulty</label>
                      <select 
                        value={difficulty} 
                        onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Questions</label>
                      <select 
                        value={numQuestions} 
                        onChange={(e) => setNumQuestions(e.target.value)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="5">5 Questions</option>
                        <option value="10">10 Questions</option>
                        <option value="20">20 Questions</option>
                        <option value="custom">Custom</option>
                      </select>
                      {numQuestions === 'custom' && (
                        <input 
                          type="number" 
                          value={customNumQuestions}
                          onChange={(e) => setCustomNumQuestions(e.target.value)}
                          placeholder="Enter number"
                          className="mt-2 w-full p-2 rounded border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                        />
                      )}
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Question Type</label>
                      <select 
                        value={questionType} 
                        onChange={(e) => setQuestionType(e.target.value as QuestionType)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-emerald-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="MCQ">MCQ</option>
                        <option value="T/F">True / False</option>
                        <option value="Assertion-Reason">Assertion-Reason</option>
                        <option value="Mixed">Mixed (All)</option>
                      </select>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white text-amber-600 dark:text-amber-400 flex items-center gap-2">
                      <Zap className="w-5 h-5" /> PYQ Exam Mode
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 text-sm">AI will generate a quiz using Previous Year Questions from competitive exams.</p>
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Target Exam</label>
                      <select 
                        value={examType} 
                        onChange={(e) => setExamType(e.target.value)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option>JEE Mains</option>
                        <option>JEE Advanced</option>
                        <option>NEET</option>
                        <option>CBSE Class 10</option>
                        <option>CBSE Class 11</option>
                        <option>CBSE Class 12</option>
                        <option>ICSE Class 10</option>
                        <option>ISC Class 11</option>
                        <option>ISC Class 12</option>
                        <option>UPSC</option>
                        <option>CAT</option>
                        <option>GATE</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Subject</label>
                      <input 
                        type="text" 
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        placeholder="e.g. Physics"
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Chapter Name</label>
                      <input 
                        type="text" 
                        value={chapter}
                        onChange={(e) => setChapter(e.target.value)}
                        placeholder="e.g. Kinematics"
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Difficulty</label>
                      <select 
                        value={difficulty} 
                        onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="Easy">Easy</option>
                        <option value="Medium">Medium</option>
                        <option value="Hard">Hard</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Questions</label>
                      <select 
                        value={numQuestions} 
                        onChange={(e) => setNumQuestions(e.target.value)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="5">5 Questions</option>
                        <option value="10">10 Questions</option>
                        <option value="20">20 Questions</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">Question Type</label>
                      <select 
                        value={questionType} 
                        onChange={(e) => setQuestionType(e.target.value as QuestionType)}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-amber-500 outline-none text-sm text-slate-700 dark:text-slate-200 transition-all"
                      >
                        <option value="MCQ">MCQ</option>
                        <option value="Mixed">Mixed (All)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}
              <div className="mt-8 flex flex-col items-center gap-4">
                {error && (
                  <div className="w-full p-3 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-lg text-red-600 dark:text-red-400 text-xs flex items-center gap-2">
                    <XCircle className="w-4 h-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <button
                  onClick={generateQuiz}
                  disabled={isLoading}
                  className={`w-full md:w-auto px-12 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg disabled:opacity-50 ${
                    activeTab === 'paste' 
                      ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200 dark:shadow-none' 
                      : activeTab === 'curriculum'
                      ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-200 dark:shadow-none'
                      : 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200 dark:shadow-none'
                  }`}
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  {activeTab === 'paste' ? 'Generate Quiz' : activeTab === 'curriculum' ? 'Generate Curriculum Quiz' : 'Generate PYQ Quiz'}
                </button>
              </div>
            </div>
          </div>
        ) : showResults ? (
          <div className="max-w-2xl mx-auto w-full py-12 text-center space-y-8">
            <div className="relative inline-block">
              <div className="w-32 h-32 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mx-auto transition-colors">
                <Trophy className="w-16 h-16 text-emerald-500" />
              </div>
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg"
              >
                {Math.round((score / quiz!.questions.length) * 100)}%
              </motion.div>
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-black text-slate-900 dark:text-white">Quiz Completed!</h3>
              <p className="text-slate-500 dark:text-slate-400">You scored <span className="font-bold text-emerald-600 dark:text-emerald-400">{score}</span> out of <span className="font-bold text-slate-900 dark:text-white">{quiz?.questions.length}</span></p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => {
                  setShowResults(false);
                  setCurrentQuestionIndex(0);
                  setSelectedAnswer(userAnswers[0]);
                }}
                className="py-3 px-6 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-medium transition-colors"
              >
                Review Answers
              </button>
              <button
                onClick={resetQuiz}
                className="py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium transition-colors shadow-sm shadow-emerald-200 dark:shadow-none"
              >
                Create New Quiz
              </button>
            </div>
          </div>
        ) : (
          <div className="max-w-3xl mx-auto w-full flex-1 flex flex-col">
            <div className="mb-8 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">{quiz?.title}</h3>
                <p className="text-xs text-slate-400 dark:text-slate-500 font-medium uppercase tracking-wider">Question {currentQuestionIndex + 1} of {quiz?.questions.length}</p>
              </div>
              <div className="flex gap-1">
                {quiz?.questions.map((_, idx) => (
                  <div 
                    key={idx}
                    className={`h-1.5 w-8 rounded-full transition-colors ${
                      idx === currentQuestionIndex ? 'bg-emerald-500' : 
                      userAnswers[idx] !== undefined ? 'bg-slate-300 dark:bg-slate-700' : 'bg-slate-200 dark:bg-slate-800'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="flex-1 space-y-8">
              {/* Waiting for Host state */}
              {isMultiplayer && !quiz && (
                <div className="flex-1 flex flex-col items-center justify-center py-20 text-center space-y-6">
                  <div className="w-20 h-20 bg-amber-50 dark:bg-amber-900/20 rounded-full flex items-center justify-center animate-pulse">
                    <Loader2 className="w-10 h-10 text-amber-500 animate-spin" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white">Waiting for Host...</h3>
                    <p className="text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                      You've joined the room! Once the host starts the quiz, it will appear here automatically.
                    </p>
                  </div>
                  <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Connected Players</p>
                    <div className="flex flex-wrap justify-center gap-2">
                      {players.map(p => (
                        <span key={p.id} className="px-3 py-1 bg-white dark:bg-slate-900 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-sm">
                          {p.name} {p.id === socket?.id ? '(You)' : ''}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Leaderboard for Multiplayer */}
              {isMultiplayer && quiz && (
                <div className="bg-indigo-50 dark:bg-indigo-900/10 rounded-2xl p-4 border border-indigo-100 dark:border-indigo-800/50">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Trophy className="w-3.5 h-3.5" /> Live Leaderboard
                  </h4>
                  <div className="flex flex-wrap gap-4">
                    {players.sort((a, b) => b.score - a.score).map((p) => (
                      <div key={p.id} className="flex items-center gap-2 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                        <div className={`w-2 h-2 rounded-full ${p.completed ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{p.name}</span>
                        <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 ml-1">{p.score}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 transition-colors">
                <h4 className="text-lg font-medium text-slate-800 dark:text-slate-200 leading-relaxed">
                  {quiz?.questions[currentQuestionIndex].question}
                </h4>
              </div>

              <div className="grid gap-3">
                {quiz?.questions[currentQuestionIndex].options.map((option, idx) => {
                  const isSelected = selectedAnswer === idx;
                  const isCorrect = quiz.questions[currentQuestionIndex].correctAnswer === idx;
                  const showCorrectness = selectedAnswer !== null;

                  let buttonClass = "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-900 hover:bg-emerald-50/30 dark:hover:bg-emerald-900/10 text-slate-700 dark:text-slate-200";
                  if (showCorrectness) {
                    if (isCorrect) buttonClass = "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500 dark:border-emerald-500 text-emerald-700 dark:text-emerald-400";
                    else if (isSelected) buttonClass = "bg-red-50 dark:bg-red-900/20 border-red-500 dark:border-red-500 text-red-700 dark:text-red-400";
                    else buttonClass = "bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 opacity-50 text-slate-400 dark:text-slate-600";
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleAnswerSelect(idx)}
                      disabled={selectedAnswer !== null}
                      className={`w-full p-4 text-left rounded-xl border-2 transition-all flex items-center justify-between group ${buttonClass}`}
                    >
                      <span className="font-medium">{option}</span>
                      {showCorrectness && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
                      {showCorrectness && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-500" />}
                    </button>
                  );
                })}
              </div>

              <AnimatePresence>
                {selectedAnswer !== null && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30 rounded-xl transition-colors"
                  >
                    <p className="text-sm text-indigo-900 dark:text-indigo-300 leading-relaxed">
                      <span className="font-bold mr-2">Explanation:</span>
                      {quiz?.questions[currentQuestionIndex].explanation}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={prevQuestion}
                disabled={currentQuestionIndex === 0}
                className="flex items-center gap-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors font-medium"
              >
                <ChevronLeft className="w-5 h-5" /> Previous
              </button>
              
              <button
                onClick={nextQuestion}
                disabled={selectedAnswer === null}
                className="flex items-center gap-2 py-2 px-6 bg-slate-900 dark:bg-slate-700 text-white rounded-lg hover:bg-slate-800 dark:hover:bg-slate-600 disabled:opacity-30 disabled:cursor-not-allowed transition-all font-medium"
              >
                {currentQuestionIndex === quiz!.questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Saved Quizzes Section */}
        {!quiz && !showResults && savedQuizzes.length > 0 && (
          <div className="max-w-4xl mx-auto w-full pt-8 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Saved Quizzes</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all saved quizzes?')) setSavedQuizzes([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {savedQuizzes.map((save) => (
                <div key={save.id} className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between group transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white dark:bg-slate-900 rounded-lg flex items-center justify-center text-emerald-500 shadow-sm transition-colors">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">{save.quiz.title}</h4>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium uppercase tracking-wider">{save.quiz.questions.length} Questions</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button
                      onClick={() => loadSavedQuiz(save)}
                      className="p-2 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                      title="Load Quiz"
                    >
                      <Upload className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteSavedQuiz(save.id)}
                      className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Share Modal */}
      <AnimatePresence>
        {showShareModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 rounded-2xl flex items-center justify-center mx-auto">
                  <Share2 className="w-8 h-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Quiz Room Code</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">
                  Give this code to your friend. They must be on the <b>same website</b> to join!
                </p>
                
                <div className="flex items-center gap-2 p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700">
                  <span className="flex-1 text-2xl font-black text-indigo-600 dark:text-indigo-400 tracking-[0.5em] uppercase font-mono">
                    {roomId}
                  </span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(roomId || '');
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2000);
                    }}
                    className="p-2 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    {copiedLink ? <Check className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5 text-slate-400" />}
                  </button>
                </div>

                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-xl border border-indigo-100 dark:border-indigo-800/50 text-left">
                  <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-1">Server URL (Must Match)</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono break-all">{window.location.origin}</p>
                </div>

                <button
                  onClick={() => setShowShareModal(false)}
                  className="w-full py-3 bg-slate-900 dark:bg-slate-700 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Join Multiplayer Check */}
      {isMultiplayer && !isNameSubmitted && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800"
          >
            <div className="text-center space-y-6">
              <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center mx-auto">
                <Users className="w-8 h-8 text-indigo-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Join Quiz Challenge</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Enter your name to start the challenge with your friend.</p>
              
              <input
                type="text"
                placeholder="Your Name"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && playerName.trim()) {
                    setIsNameSubmitted(true);
                  }
                }}
                className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
              />

              <button
                disabled={!playerName.trim()}
                onClick={() => setIsNameSubmitted(true)}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
              >
                Join Challenge
              </button>
              <button
                onClick={() => {
                  setIsMultiplayer(false);
                  setRoomId(null);
                  // Remove room from URL
                  const newUrl = `${window.location.origin}${window.location.pathname}`;
                  window.history.pushState({ path: newUrl }, '', newUrl);
                }}
                className="text-xs text-slate-400 hover:text-slate-600 font-medium"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Manual Join Modal */}
      <AnimatePresence>
        {showJoinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800"
            >
              <div className="text-center space-y-6">
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl flex items-center justify-center mx-auto">
                  <Lock className="w-8 h-8 text-indigo-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Enter Room Code</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Enter the secret room code shared by your friend to join their quiz.</p>
                
                <div className="flex items-center justify-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">
                  <Wifi className={`w-3 h-3 ${isConnected ? 'text-emerald-500' : 'text-red-500'}`} />
                  {isConnected ? 'Connected to Server' : 'Connecting to Server...'}
                </div>

                <input
                  type="text"
                  placeholder="e.g. X7Y2Z9A"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && joinCode.trim()) {
                      handleJoinRoom();
                    }
                  }}
                  className="w-full p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white text-center font-mono text-xl tracking-widest uppercase"
                />

                <div className="p-4 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-left space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-3 h-3 text-amber-500" />
                    <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase">Important Note</p>
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Multiplayer only works if you and your friend are using the <b>same website URL</b>.
                  </p>
                  <p className="text-[9px] text-indigo-500 font-mono break-all">{window.location.origin}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setShowJoinModal(false)}
                    className="py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold rounded-xl hover:bg-slate-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    disabled={!joinCode.trim()}
                    onClick={handleJoinRoom}
                    className="py-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-lg"
                  >
                    Join Room
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
