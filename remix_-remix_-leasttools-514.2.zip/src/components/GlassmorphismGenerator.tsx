import React, { useState, useEffect } from 'react';
import { Copy, Check, RefreshCw, Layers } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function GlassmorphismGenerator() {
  const [blur, setBlur] = useState(10);
  const [transparency, setTransparency] = useState(0.2);
  const [color, setColor] = useState('#ffffff');
  const [borderRadius, setBorderRadius] = useState(16);
  const [borderWidth, setBorderWidth] = useState(1);
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('glassmorphism-generator');
      if (savedState) {
        setBlur(savedState.blur ?? 10);
        setTransparency(savedState.transparency ?? 0.2);
        setColor(savedState.color ?? '#ffffff');
        setBorderRadius(savedState.borderRadius ?? 16);
        setBorderWidth(savedState.borderWidth ?? 1);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('glassmorphism-generator', { blur, transparency, color, borderRadius, borderWidth });
    }
  }, [blur, transparency, color, borderRadius, borderWidth, isLoaded]);

  const hexToRgba = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  const glassStyle = {
    backgroundColor: hexToRgba(color, transparency),
    backdropFilter: `blur(${blur}px)`,
    WebkitBackdropFilter: `blur(${blur}px)`,
    borderRadius: `${borderRadius}px`,
    border: `${borderWidth}px solid ${hexToRgba('#ffffff', 0.1)}`,
  };

  const cssCode = `background: ${hexToRgba(color, transparency)};
backdrop-filter: blur(${blur}px);
-webkit-backdrop-filter: blur(${blur}px);
border-radius: ${borderRadius}px;
border: ${borderWidth}px solid rgba(255, 255, 255, 0.1);`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(cssCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Layers className="w-5 h-5 text-indigo-500" />
          <h2>Glassmorphism Generator</h2>
        </div>
        <button
          onClick={() => {
            setBlur(10);
            setTransparency(0.2);
            setColor('#ffffff');
            setBorderRadius(16);
            setBorderWidth(1);
          }}
          className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
          title="Reset"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Blur ({blur}px)</label>
              <input 
                type="range" min="0" max="40" step="1" 
                value={blur} onChange={(e) => setBlur(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Transparency ({transparency})</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={transparency} onChange={(e) => setTransparency(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Border Radius ({borderRadius}px)</label>
              <input 
                type="range" min="0" max="100" step="1" 
                value={borderRadius} onChange={(e) => setBorderRadius(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Border Width ({borderWidth}px)</label>
              <input 
                type="range" min="0" max="10" step="1" 
                value={borderWidth} onChange={(e) => setBorderWidth(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Base Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">CSS Output</label>
              <button 
                onClick={copyToClipboard}
                className="text-xs flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied!' : 'Copy CSS'}
              </button>
            </div>
            <pre className="p-4 bg-slate-950 text-indigo-300 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800">
              {cssCode}
            </pre>
          </div>
        </div>

        <div className="relative min-h-[300px] rounded-2xl overflow-hidden bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center p-8">
          {/* Background decorative elements to show transparency */}
          <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-400 rounded-full blur-xl opacity-50 animate-pulse" />
          <div className="absolute bottom-10 right-10 w-32 h-32 bg-blue-400 rounded-full blur-2xl opacity-50 animate-bounce" />
          <div className="absolute top-1/2 left-1/4 w-16 h-16 bg-green-400 rotate-45 opacity-30" />
          
          <div style={glassStyle} className="w-full h-full max-w-[280px] max-h-[200px] flex flex-col items-center justify-center text-center p-6 shadow-2xl">
            <h3 className="text-white font-bold text-xl mb-2">Glass Preview</h3>
            <p className="text-white/80 text-xs">Adjust the sliders to see the frosted glass effect in real-time.</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
