import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, RefreshCw, TreeDeciduous, Download, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function FractalTreeGenerator() {
  const [angle, setAngle] = useState(25);
  const [length, setLength] = useState(100);
  const [depth, setDepth] = useState(10);
  const [branchRatio, setBranchRatio] = useState(0.75);
  const [color, setColor] = useState('#10b981');
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('fractal-tree-generator');
      if (savedState) {
        setAngle(savedState.angle ?? 25);
        setLength(savedState.length ?? 100);
        setDepth(savedState.depth ?? 10);
        setBranchRatio(savedState.branchRatio ?? 0.75);
        setColor(savedState.color ?? '#10b981');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('fractal-tree-generator', { angle, length, depth, branchRatio, color });
    }
  }, [angle, length, depth, branchRatio, color, isLoaded]);

  const drawTree = (ctx: CanvasRenderingContext2D, x: number, y: number, len: number, ang: number, d: number) => {
    if (d === 0) return;

    const x2 = x + Math.cos(ang * Math.PI / 180) * len;
    const y2 = y + Math.sin(ang * Math.PI / 180) * len;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = color;
    ctx.lineWidth = d;
    ctx.stroke();

    drawTree(ctx, x2, y2, len * branchRatio, ang - angle, d - 1);
    drawTree(ctx, x2, y2, len * branchRatio, ang + angle, d - 1);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawTree(ctx, canvas.width / 2, canvas.height - 20, length, -90, depth);
  }, [angle, length, depth, branchRatio, color]);

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `fractal-tree-${angle}-${depth}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <TreeDeciduous className="w-5 h-5 text-emerald-500" />
          <h2>Fractal Tree Generator</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={downloadCanvas}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setAngle(25);
              setLength(100);
              setDepth(10);
              setBranchRatio(0.75);
              setColor('#10b981');
            }}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Reset"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Branch Angle ({angle}°)</label>
              <input 
                type="range" min="0" max="90" step="1" 
                value={angle} onChange={(e) => setAngle(parseInt(e.target.value))}
                className="w-1/2 accent-emerald-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Initial Length ({length}px)</label>
              <input 
                type="range" min="10" max="150" step="1" 
                value={length} onChange={(e) => setLength(parseInt(e.target.value))}
                className="w-1/2 accent-emerald-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Recursion Depth ({depth})</label>
              <input 
                type="range" min="1" max="12" step="1" 
                value={depth} onChange={(e) => setDepth(parseInt(e.target.value))}
                className="w-1/2 accent-emerald-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Branch Ratio ({branchRatio})</label>
              <input 
                type="range" min="0.5" max="0.9" step="0.01" 
                value={branchRatio} onChange={(e) => setBranchRatio(parseFloat(e.target.value))}
                className="w-1/2 accent-emerald-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Tree Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
          </div>

          <div className="p-4 bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">About Fractal Trees</h3>
            <p className="text-[10px] text-emerald-700 dark:text-emerald-400 leading-relaxed">
              Fractal trees are generated using recursion. Each branch splits into two smaller branches at a specific angle. 
              This simple rule creates complex, organic shapes that mimic real trees.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden">
          <canvas 
            ref={canvasRef} 
            width={500} 
            height={500} 
            className="w-full h-full max-w-[500px] max-h-[500px] object-contain drop-shadow-lg"
          />
        </div>
      </div>
    </motion.div>
  );
}
