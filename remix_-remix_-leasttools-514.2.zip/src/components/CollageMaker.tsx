import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, Trash2, Grid, Image as ImageIcon, Settings, X, Plus, Loader2, ZoomIn, Link as LinkIcon, FileText, Save, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { jsPDF } from "jspdf";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { saveImagesToDB, loadImagesFromDB, clearImagesFromDB, saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

interface CollageImage {
  id: string;
  url: string;
  file: File;
}

interface SavedCollage {
  id: string;
  image: string; // Data URL of the exported collage
  timestamp: number;
}

export default function CollageMaker() {
  const [images, setImages] = useState<CollageImage[]>([]);
  const [columns, setColumns] = useState(3);
  const [gap, setGap] = useState(10);
  const [backgroundColor, setBackgroundColor] = useState('#ffffff');
  const [aspectRatio, setAspectRatio] = useState('1/1'); // '1/1', '16/9', '4/3', 'original'
  const [smartExpand, setSmartExpand] = useState(false);
  const [isRearranging, setIsRearranging] = useState(false);
  const [selectedImage, setSelectedImage] = useState<CollageImage | null>(null);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [bulkLinks, setBulkLinks] = useState('');
  const [isBulkLoading, setIsBulkLoading] = useState(false);
  const [showDownloadOptions, setShowDownloadOptions] = useState(false);
  const [downloadLayout, setDownloadLayout] = useState<any>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [filename, setFilename] = useState('');
  const [savedItems, setSavedItems] = useState<SavedCollage[]>([]);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load state on mount and Global Paste Listener
  useEffect(() => {
    const loadState = async () => {
      // Load settings and images from DB
      try {
        const savedState = await loadToolState('collage-maker');
        if (savedState) {
          setColumns(savedState.columns || 3);
          setGap(savedState.gap || 10);
          setBackgroundColor(savedState.backgroundColor || '#ffffff');
          setAspectRatio(savedState.aspectRatio || '1/1');
          setSmartExpand(savedState.smartExpand !== undefined ? savedState.smartExpand : false);
          setSavedItems(savedState.savedItems || []);
          setFilename(savedState.filename || '');
        }

        const savedImages = await loadImagesFromDB();
        if (savedImages && savedImages.length > 0) {
          const loadedImages = savedImages.map(img => ({
            ...img,
            url: URL.createObjectURL(img.file)
          }));
          setImages(loadedImages);
        }
      } catch (e) {
        console.error("Failed to load state from DB", e);
      }
      setIsLoaded(true);
    };
    loadState();

    const handleGlobalPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      const newImages: CollageImage[] = [];
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const file = new File([blob], `pasted-image-${Math.random().toString(36).substring(7)}.png`, { type: blob.type });
            newImages.push({
              id: Math.random().toString(36).substring(7),
              url: URL.createObjectURL(file),
              file: file
            });
          }
        }
      }

      if (newImages.length > 0) {
        setImages(prev => [...prev, ...newImages]);
        e.preventDefault();
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, []);

  // Save settings immediately
  useEffect(() => {
    if (!isLoaded) return;
    saveToolState('collage-maker', { columns, gap, backgroundColor, aspectRatio, smartExpand, savedItems, filename });
  }, [columns, gap, backgroundColor, aspectRatio, smartExpand, savedItems, filename, isLoaded]);

  // Save images with debounce and on unmount
  useEffect(() => {
    if (!isLoaded) return;

    const saveImages = async () => {
      const imagesToSave = images.map(({ id, file }) => ({ id, file }));
      await saveImagesToDB(imagesToSave);
    };

    const timeout = setTimeout(saveImages, 500);
    
    return () => {
      clearTimeout(timeout);
      // We don't await here but the promise will still execute
      saveImages();
    };
  }, [images, isLoaded]);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      images.forEach(img => URL.revokeObjectURL(img.url));
    };
  }, []);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (showDownloadOptions || showBulkAdd || selectedImage) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showDownloadOptions, showBulkAdd, selectedImage]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files);
      const newImages: CollageImage[] = files.map((file: File) => ({
        id: Math.random().toString(36).substring(7),
        url: URL.createObjectURL(file),
        file: file
      }));
      setImages(prev => [...prev, ...newImages]);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      const newImages: CollageImage[] = [];
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const file = new File([blob], `pasted-image-${Math.random().toString(36).substring(7)}.png`, { type: blob.type });
            newImages.push({
              id: Math.random().toString(36).substring(7),
              url: URL.createObjectURL(file),
              file: file
            });
          }
        }
      }
      if (newImages.length > 0) {
        setImages(prev => [...prev, ...newImages]);
      } else {
        alert('No image found in clipboard. Please copy an image first.');
      }
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const fetchImageAsBlob = (url: string): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error("Failed to get canvas context"));
          return;
        }
        ctx.drawImage(img, 0, 0);
        canvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error("Failed to create blob"));
        }, 'image/png');
      };
      img.onerror = () => reject(new Error("Failed to load image. This might be due to CORS restrictions on the source server."));
      img.src = url;
    });
  };

  const handleBulkAdd = async () => {
    const links = bulkLinks.split('\n').map(l => l.trim()).filter(l => l !== '');
    if (links.length === 0) return;
    
    setIsBulkLoading(true);
    const newImages: CollageImage[] = [];
    const failedLinks: string[] = [];
    
    for (const link of links) {
      try {
        const blob = await fetchImageAsBlob(link);
        const file = new File([blob], `image-${Math.random().toString(36).substring(7)}.png`, { type: blob.type });
        newImages.push({
          id: Math.random().toString(36).substring(7),
          url: URL.createObjectURL(file),
          file: file
        });
      } catch (e) {
        console.error("Failed to load link", link, e);
        failedLinks.push(link);
      }
    }
    
    setImages(prev => [...prev, ...newImages]);
    if (failedLinks.length > 0) {
      alert(`Failed to load ${failedLinks.length} images. Some servers block direct access (CORS).`);
      setBulkLinks(failedLinks.join('\n'));
    } else {
      setBulkLinks('');
      setShowBulkAdd(false);
    }
    setIsBulkLoading(false);
  };

  const removeImage = (id: string) => {
    setImages(prev => {
      const newImages = prev.filter(img => img.id !== id);
      const removed = prev.find(img => img.id === id);
      if (removed) URL.revokeObjectURL(removed.url);
      return newImages;
    });
  };

  const calculateLayout = () => {
    const outputWidth = 2100; // 210mm * 10
    const pageHeight = 2970; // 297mm * 10
    
    // Calculate cell size
    const scaledGap = gap * 5; 

    const colWidth = (outputWidth - (scaledGap * (columns + 1))) / columns;
    
    // Calculate row height based on aspect ratio
    let rowHeight = colWidth; // Default square
    const [w, h] = aspectRatio.split('/').map(Number);
    if (w && h) {
      rowHeight = colWidth * (h / w);
    }
    
    // Calculate rows needed
    const rows = Math.ceil(images.length / columns);
    
    // How many rows fit per page?
    const rowsPerPage = Math.max(1, Math.floor((pageHeight - scaledGap) / (rowHeight + scaledGap)));
    
    const totalPages = Math.max(1, Math.ceil(rows / rowsPerPage));

    return { outputWidth, pageHeight, rows, rowHeight, scaledGap, colWidth, rowsPerPage, totalPages };
  };

  const generateCanvas = async (layout: any, startRow: number, endRow: number) => {
    const { outputWidth, pageHeight, rowHeight, scaledGap, colWidth, rows } = layout;
    
    const canvas = document.createElement('canvas');
    canvas.width = outputWidth;
    canvas.height = pageHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Fill background
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const startIndex = startRow * columns;
    const endIndex = Math.min(endRow * columns, images.length);
    
    const imagesToDraw = images.slice(startIndex, endIndex);
    
    // Load images
    const loadPromises = imagesToDraw.map(img => {
      return new Promise<HTMLImageElement | null>((resolve) => {
        const image = new Image();
        image.crossOrigin = "anonymous";
        
        const timeout = setTimeout(() => {
            console.warn(`Image load timed out: ${img.url}`);
            resolve(null);
        }, 15000);

        image.onload = () => {
            clearTimeout(timeout);
            resolve(image);
        };
        image.onerror = () => {
          clearTimeout(timeout);
          resolve(null);
        };
        image.src = img.url;
      });
    });

    try {
      const loadedImages = await Promise.all(loadPromises);
      
      loadedImages.forEach((img, i) => {
        if (!img) return;

        const globalIndex = startIndex + i;
        const globalRow = Math.floor(globalIndex / columns);
        const localRow = globalRow - startRow;
        const colIndex = globalIndex % columns;

        const x = scaledGap + (colIndex * (colWidth + scaledGap));
        const y = scaledGap + (localRow * (rowHeight + scaledGap));

        const imgAspect = img.width / img.height;
        const cellAspect = colWidth / rowHeight;

        let drawWidth, drawHeight, offsetX, offsetY;

        if (smartExpand) {
          if (imgAspect > cellAspect) {
            drawWidth = colWidth;
            drawHeight = colWidth / imgAspect;
            offsetX = x;
            offsetY = y + (rowHeight - drawHeight) / 2;
          } else {
            drawHeight = rowHeight;
            drawWidth = rowHeight * imgAspect;
            offsetX = x + (colWidth - drawWidth) / 2;
            offsetY = y;
          }
        } else {
          if (imgAspect > cellAspect) {
            drawHeight = rowHeight;
            drawWidth = rowHeight * imgAspect;
            offsetX = x - (drawWidth - colWidth) / 2;
            offsetY = y;
          } else {
            drawWidth = colWidth;
            drawHeight = colWidth / imgAspect;
            offsetX = x;
            offsetY = y - (drawHeight - rowHeight) / 2;
          }
        }

        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, colWidth, rowHeight);
        ctx.clip();
        
        ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
        ctx.restore();
      });
      
      return canvas;

    } catch (err) {
      console.error("Error generating canvas part", err);
      return null;
    }
  };

  const handleDownload = async () => {
    if (images.length === 0) return;

    try {
      const layout = calculateLayout();
      
      if (layout.totalPages > 1) {
        setDownloadLayout(layout);
        setShowDownloadOptions(true);
      } else {
        const canvas = await generateCanvas(layout, 0, layout.rowsPerPage);
        if (canvas) {
          const dataUrl = canvas.toDataURL('image/png');
          const link = document.createElement('a');
          link.download = getDownloadFilename(filename, 'collage', 'png');
          link.href = dataUrl;
          link.click();
        }
      }
    } catch (error) {
      console.error("Download failed", error);
    }
  };

  const handleDownloadImages = async () => {
    setIsDownloading(true);
    try {
      const layout = downloadLayout || calculateLayout();
      const { totalPages, rowsPerPage } = layout;
      
      const zip = new JSZip();
      let hasContent = false;
      
      for (let i = 0; i < totalPages; i++) {
        const startRow = i * rowsPerPage;
        const endRow = (i + 1) * rowsPerPage;
        
        const canvas = await generateCanvas(layout, startRow, endRow);
        if (canvas) {
          const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'));
          if (blob) {
            zip.file(`collage-page-${i + 1}.png`, blob);
            hasContent = true;
          }
        }
      }
      
      if (hasContent) {
        const content = await zip.generateAsync({ type: "blob" });
        saveAs(content, getDownloadFilename(filename, 'collage', 'zip'));
        setShowDownloadOptions(false);
      }
    } catch (error) {
      console.error("Failed to download images", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadPDF = async () => {
    setIsDownloading(true);
    try {
      const layout = downloadLayout || calculateLayout();
      const { totalPages, rowsPerPage } = layout;
      
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      for (let i = 0; i < totalPages; i++) {
        if (i > 0) doc.addPage();
        
        const startRow = i * rowsPerPage;
        const endRow = (i + 1) * rowsPerPage;
        
        const canvas = await generateCanvas(layout, startRow, endRow);
        if (canvas) {
          const imgData = canvas.toDataURL('image/png');
          doc.addImage(imgData, 'PNG', 0, 0, 210, 297);
        }
      }
      
      doc.save(getDownloadFilename(filename, 'collage', 'pdf'));
      setShowDownloadOptions(false);
    } catch (error) {
      console.error("Failed to download PDF", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const downloadSingleImage = (img: CollageImage) => {
    const link = document.createElement('a');
    link.href = img.url;
    link.download = `image-${img.id}.png`;
    link.click();
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    // Small delay to allow the drag ghost to be created before we change the style
    setTimeout(() => {
      const target = e.target as HTMLElement;
      target.style.opacity = '0.4';
    }, 0);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDragEnter = (index: number) => {
    if (draggedIndex === null || draggedIndex === index) return;

    const newImages = [...images];
    const draggedItem = newImages[draggedIndex];
    newImages.splice(draggedIndex, 1);
    newImages.splice(index, 0, draggedItem);
    
    setImages(newImages);
    setDraggedIndex(index);
  };
  
  const handleDragEnd = (e: React.DragEvent) => {
    setDraggedIndex(null);
    const target = e.target as HTMLElement;
    target.style.opacity = '1';
  };

  const saveToHistory = async () => {
    if (images.length === 0) return;
    const layout = calculateLayout();
    const canvas = await generateCanvas(layout, 0, -1);
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/png');
      const newItem: SavedCollage = {
        id: Math.random().toString(36).substring(7),
        image: dataUrl,
        timestamp: Date.now()
      };
      setSavedItems(prev => [newItem, ...prev]);
    }
  };

  const deleteSaved = (id: string) => {
    setSavedItems(prev => prev.filter(item => item.id !== id));
  };

  const downloadSaved = (image: string) => {
    const link = document.createElement('a');
    link.href = image;
    link.download = `saved-collage-${Date.now()}.png`;
    link.click();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full relative transition-colors"
    >
      {/* Bulk Add Modal */}
      <AnimatePresence>
        {showBulkAdd && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
                <div className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-200">
                  <LinkIcon className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  <h3>Bulk Add Image Links</h3>
                </div>
                <button onClick={() => setShowBulkAdd(false)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400 dark:text-slate-500" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <p className="text-sm text-slate-500 dark:text-slate-400">Paste image URLs below (one per line). Note: Some links may not work due to security restrictions (CORS).</p>
                <textarea
                  value={bulkLinks}
                  onChange={(e) => setBulkLinks(e.target.value)}
                  placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.png"
                  className="w-full h-48 p-3 border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none text-sm font-mono resize-none text-slate-700 dark:text-slate-200 placeholder:text-slate-400 dark:placeholder:text-slate-600"
                />
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowBulkAdd(false)}
                    className="flex-1 py-2.5 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 rounded-xl font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleBulkAdd}
                    disabled={isBulkLoading || !bulkLinks.trim()}
                    className="flex-1 py-2.5 bg-purple-600 text-white rounded-xl font-medium hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isBulkLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        Add Images
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Zoom Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4 md:p-12 backdrop-blur-md"
            onClick={() => setSelectedImage(null)}
          >
            <div 
              className="relative shadow-2xl overflow-hidden flex items-center justify-center rounded-2xl border border-white/10" 
              style={{ 
                aspectRatio: aspectRatio.replace('/', ' / '),
                maxHeight: '80vh',
                maxWidth: '90vw',
                backgroundColor: backgroundColor,
                width: '100%',
                height: 'auto'
              }}
              onClick={e => e.stopPropagation()}
            >
              <img 
                src={selectedImage.url} 
                alt="Zoomed view" 
                className="max-w-full max-h-full object-contain"
              />
              
              {/* Modal Controls */}
              <div className="absolute top-4 right-4 flex gap-2">
                <button
                  onClick={() => downloadSingleImage(selectedImage)}
                  className="p-2 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white rounded-full transition-all border border-white/20"
                  title="Download"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setSelectedImage(null)}
                  className="p-2 bg-white/10 hover:bg-red-500/50 backdrop-blur-md text-white rounded-full transition-all border border-white/20"
                  title="Close"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Info Tag */}
              <div className="absolute bottom-4 left-4 px-3 py-1 bg-black/40 backdrop-blur-md rounded-full border border-white/10">
                <p className="text-[10px] font-bold text-white/80 uppercase tracking-widest">
                  {aspectRatio.replace('/', ':')} View
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Download Options Modal */}
      <AnimatePresence>
        {showDownloadOptions && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-900/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/50">
                <div className="flex items-center gap-2 font-medium text-slate-700 dark:text-slate-200">
                  <Download className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                  <h3>Download Options</h3>
                </div>
                <button onClick={() => setShowDownloadOptions(false)} className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400 dark:text-slate-500" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  Your collage is too long for a single page. How would you like to download it?
                </p>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider ml-1">Output Filename</label>
                  <input
                    type="text"
                    value={filename}
                    onChange={(e) => setFilename(e.target.value)}
                    placeholder="Enter Filename (Optional)"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-purple-500 focus:ring-2 focus:ring-purple-100 dark:focus:ring-purple-900/30 outline-none text-sm text-slate-700 dark:text-slate-200"
                  />
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                  <button
                    onClick={handleDownloadImages}
                    disabled={isDownloading}
                    className="flex items-center gap-3 p-4 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:border-purple-200 dark:hover:border-purple-900/50 transition-all group text-left disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="w-10 h-10 bg-purple-50 dark:bg-purple-900/20 rounded-lg flex items-center justify-center group-hover:bg-purple-100 dark:group-hover:bg-purple-900/40 transition-colors">
                      {isDownloading ? <Loader2 className="w-5 h-5 text-purple-600 dark:text-purple-400 animate-spin" /> : <ImageIcon className="w-5 h-5 text-purple-600 dark:text-purple-400" />}
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-900 dark:text-white">Download as Images (ZIP)</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Save as a zip file containing separate images</p>
                    </div>
                  </button>

                  <button
                    onClick={handleDownloadPDF}
                    disabled={isDownloading}
                    className="flex items-center gap-3 p-4 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:border-red-200 dark:hover:border-red-900/50 transition-all group text-left disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="w-10 h-10 bg-red-50 dark:bg-red-900/20 rounded-lg flex items-center justify-center group-hover:bg-red-100 dark:group-hover:bg-red-900/40 transition-colors">
                      {isDownloading ? <Loader2 className="w-5 h-5 text-red-600 dark:text-red-400 animate-spin" /> : <FileText className="w-5 h-5 text-red-600 dark:text-red-400" />}
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-900 dark:text-white">Download as PDF</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Save as a multi-page PDF document (A4)</p>
                    </div>
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Grid className="w-5 h-5 text-purple-500" />
          <h2>Quick Collage</h2>
        </div>
        <div className="flex gap-2 items-center">
          {images.length > 0 && (
            <button
              onClick={saveToHistory}
              className="p-2 text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors"
              title="Save to History"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setImages([])}
            disabled={images.length === 0}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors disabled:opacity-50"
            title="Clear all"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={handleDownload}
            disabled={images.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Download</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Sidebar Controls */}
        <div className="w-full md:w-64 bg-slate-50 dark:bg-slate-900/50 border-r border-slate-200 dark:border-slate-800 p-4 flex flex-col gap-6 overflow-y-auto custom-scrollbar transition-colors">
          
          {/* Upload */}
          <div className="space-y-3">
            <div className="p-4 border-2 border-dashed border-purple-200 dark:border-purple-900/50 bg-purple-50 dark:bg-purple-900/10 rounded-xl flex flex-col items-center gap-3">
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-purple-400 dark:text-purple-600" />
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  <button onClick={() => fileInputRef.current?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                  {" or "}
                  <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                  {" an image"}
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setShowBulkAdd(true)}
              className="w-full py-2 border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 hover:bg-slate-50 dark:hover:bg-slate-900 text-slate-600 dark:text-slate-400 rounded-xl flex items-center justify-center gap-2 transition-all text-sm font-medium"
            >
              <LinkIcon className="w-4 h-4" />
              Bulk Add Links
            </button>
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileUpload}
              multiple 
              accept="image/*"
              className="hidden" 
            />
            <p className="text-xs text-slate-400 dark:text-slate-500 text-center mt-2">{images.length} images selected</p>
            
            {images.length > 0 && (
              <button
                onClick={() => setIsRearranging(!isRearranging)}
                className={`w-full py-2 border rounded-xl flex items-center justify-center gap-2 transition-all text-sm font-medium ${isRearranging ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800' : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900'}`}
              >
                <LayoutGrid className="w-4 h-4" />
                {isRearranging ? 'Done Rearranging' : 'Rearrange Items'}
              </button>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-medium text-sm">
              <Settings className="w-4 h-4" />
              Settings
            </div>
            
            {/* Columns */}
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2 block">Columns: {columns}</label>
              <input 
                type="range" 
                min="1" 
                max="5" 
                value={columns} 
                onChange={(e) => setColumns(parseInt(e.target.value))}
                className="w-full accent-purple-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-600 px-1">
                <span>1</span><span>5</span>
              </div>
            </div>

            {/* Gap */}
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2 block">Gap: {gap}px</label>
              <input 
                type="range" 
                min="0" 
                max="50" 
                value={gap} 
                onChange={(e) => setGap(parseInt(e.target.value))}
                className="w-full accent-purple-600"
              />
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2 block">Cell Aspect Ratio</label>
              <div className="grid grid-cols-3 gap-2">
                {['1/1', '16/9', '9/16', '4/3', '3/4'].map(ratio => (
                  <button
                    key={ratio}
                    onClick={() => setAspectRatio(ratio)}
                    className={`px-2 py-1.5 text-xs rounded-lg border transition-colors ${
                      aspectRatio === ratio 
                        ? 'bg-purple-100 dark:bg-purple-900/30 border-purple-500 dark:border-purple-400 text-purple-700 dark:text-purple-300 font-medium' 
                        : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-purple-300 dark:hover:border-purple-700'
                    }`}
                  >
                    {ratio.replace('/', ':')}
                  </button>
                ))}
              </div>
            </div>

            {/* Fit Images */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Fit Images</label>
              </div>
              
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between bg-white dark:bg-slate-950 p-2 rounded-lg border border-slate-200 dark:border-slate-800 transition-colors">
                  <span className="text-xs text-slate-600 dark:text-slate-400">No Crop</span>
                  <button
                    onClick={() => setSmartExpand(!smartExpand)}
                    className={`relative w-8 h-4 rounded-full transition-colors ${smartExpand ? 'bg-purple-600' : 'bg-slate-300 dark:bg-slate-700'}`}
                  >
                    <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${smartExpand ? 'translate-x-4' : 'translate-x-0'}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Background Color */}
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2 block">Background</label>
              <div className="flex items-center gap-2">
                <input 
                  type="color" 
                  value={backgroundColor}
                  onChange={(e) => setBackgroundColor(e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border-0 p-0 bg-transparent"
                />
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">{backgroundColor}</span>
              </div>
            </div>

            {/* Filename */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2 block">Default Filename</label>
              <input
                type="text"
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 text-slate-700 dark:text-slate-200 focus:border-purple-500 outline-none transition-colors"
                placeholder="leasttools-collage"
              />
            </div>
          </div>
        </div>

        {/* Preview Area */}
        <div className="flex-1 bg-slate-200/50 dark:bg-slate-950 p-4 md:p-8 flex flex-col items-center gap-8 overflow-y-auto custom-scrollbar transition-colors">
          {images.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-slate-400 dark:text-slate-600">
              <ImageIcon className="w-12 h-12 mb-3 opacity-20" />
              <p>Add images to start creating</p>
            </div>
          ) : isRearranging ? (
            <div className="w-full max-w-4xl">
              <div className="mb-6 text-center">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Rearrange Items</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">Drag and drop images to change their order in the collage.</p>
              </div>
              <Reorder.Group 
                axis="y" 
                values={images} 
                onReorder={setImages}
                className="space-y-3 max-w-2xl mx-auto"
              >
                {images.map((img) => (
                  <Reorder.Item 
                    key={img.id} 
                    value={img}
                    className="flex items-center gap-4 p-3 bg-white dark:bg-slate-800 rounded-2xl border-2 border-purple-400 dark:border-purple-600 shadow-sm cursor-grab active:cursor-grabbing"
                    whileDrag={{ scale: 1.01 }}
                  >
                    <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700">
                      <img src={img.url} alt="Collage item" className="w-full h-full object-cover pointer-events-none" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{img.file.name}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{(img.file.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeImage(img.id);
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                      title="Remove image"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </Reorder.Item>
                ))}
              </Reorder.Group>
            </div>
          ) : (() => {
            const layout = calculateLayout();
            const pages = Array.from({ length: layout.totalPages }, (_, i) => i);
            
            return (
              <>
                <div className="sticky top-0 z-20 bg-white/90 dark:bg-slate-900/90 backdrop-blur px-4 py-2 rounded-full shadow-sm border border-slate-200 dark:border-slate-800 text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2 transition-colors">
                  <span className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
                  Pages Used: {layout.totalPages}
                </div>
                {pages.map(pageIndex => {
                  const startIndex = pageIndex * layout.rowsPerPage * columns;
                  const pageImages = images.slice(startIndex, startIndex + (layout.rowsPerPage * columns));
                  
                  return (
                    <div 
                      key={pageIndex}
                      className="bg-white dark:bg-slate-900 shadow-2xl relative flex-shrink-0 group/page border border-slate-100 dark:border-slate-800"
                      style={{
                        width: '100%',
                        maxWidth: '600px',
                        aspectRatio: '210 / 297',
                        backgroundColor: backgroundColor,
                        padding: `${(layout.scaledGap / layout.outputWidth) * 100}%`,
                        display: 'grid',
                        gridTemplateColumns: `repeat(${columns}, 1fr)`,
                        gridAutoRows: `${(layout.rowHeight / layout.outputWidth) * 600}px`, // Fixed height based on maxWidth
                        gap: `${(layout.scaledGap / layout.outputWidth) * 100}%`,
                        alignContent: 'start'
                      }}
                    >
                      {/* Page Number Indicator */}
                      <div className="absolute -top-4 left-0 text-[10px] font-bold text-slate-400 dark:text-slate-600 uppercase tracking-widest">
                        Page {pageIndex + 1}
                      </div>
                      {pageImages.map((img, index) => {
                        const globalIndex = startIndex + index;
                        return (
                          <div 
                            key={img.id} 
                            draggable
                            onDragStart={(e) => handleDragStart(e, globalIndex)}
                            onDragOver={handleDragOver}
                            onDragEnter={() => handleDragEnter(globalIndex)}
                            onDragEnd={handleDragEnd}
                            className="relative group overflow-hidden cursor-move"
                            style={{ 
                              backgroundColor: backgroundColor 
                            }}
                            onClick={() => {
                              if (draggedIndex === null) setSelectedImage(img);
                            }}
                          >
                            <img 
                              src={img.url} 
                              alt="Collage item" 
                              className={`w-full h-full ${smartExpand ? 'object-contain' : 'object-cover'}`}
                            />
                            
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                              <ZoomIn className="w-6 h-6 text-white drop-shadow-md" />
                            </div>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                removeImage(img.id);
                              }}
                              className="absolute top-2 right-2 p-1.5 bg-black/50 hover:bg-red-500 text-white rounded-full transition-colors z-10"
                              title="Remove image"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </>
            );
          })()}
        </div>

        {/* History Section */}
        {savedItems.length > 0 && (
          <div className="p-6 border-t border-slate-100 dark:border-slate-800 space-y-4 bg-slate-50 dark:bg-slate-900/50 transition-colors">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Saved Collages</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) setSavedItems([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {savedItems.map((item) => (
                <div key={item.id} className="group relative bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden aspect-square">
                  <img src={item.image} alt="Saved collage" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                    <div className="flex gap-2">
                      <button
                        onClick={() => downloadSaved(item.image)}
                        className="p-1.5 bg-white dark:bg-slate-800 text-purple-600 dark:text-purple-400 rounded-lg hover:bg-purple-50 dark:hover:bg-slate-700 transition-colors"
                        title="Download"
                      >
                        <Download className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => deleteSaved(item.id)}
                        className="p-1.5 bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-slate-700 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
