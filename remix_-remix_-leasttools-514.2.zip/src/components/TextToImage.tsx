import React from 'react';
import { ImagePlus, ExternalLink, Download, Globe } from 'lucide-react';
import { motion } from 'motion/react';

export default function TextToImage() {
  const links = [
    {
      name: 'Perchance AI',
      description: 'Free, No Login, Unlimited, Uncensored, Generate upto 32 images at once, 70+ Art Styles, and many more.',
      url: 'https://perchance.org/ai-text-to-image-generator'
    },
    {
      name: 'Magic Studio',
      description: 'Free, No Login, Generate image within a second, Watermark',
      url: 'https://magicstudio.com/ai-art-generator'
    }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ImagePlus className="w-5 h-5 text-purple-500" />
          <h2>Text to image</h2>
        </div>
      </div>

      <div className="p-6 space-y-8">
        <div className="bg-purple-100/50 dark:bg-purple-900/20 border border-purple-100 dark:border-purple-900/30 rounded-2xl p-8 text-center space-y-4">
          <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-2">
            <ImagePlus className="w-8 h-8 text-purple-600 dark:text-purple-400" />
          </div>
          <h3 className="text-2xl font-black text-purple-900 dark:text-purple-100 tracking-tight">Text to image</h3>
          <p className="text-slate-600 dark:text-slate-400 text-sm max-w-md mx-auto font-medium">
            Discover the best AI image generation websites.
          </p>
        </div>

        <div className="space-y-6">
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest px-1">Available Websites</h4>
          <div className="grid gap-6">
            {links.map((link, index) => (
              <div key={index} className="flex gap-4 p-1">
                <div className="flex-shrink-0 w-8 h-8 bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400 rounded-full flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1 space-y-2">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white">{link.name}</h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">{link.description}</p>
                  </div>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 transition-colors group"
                  >
                    Visit Website
                    <ExternalLink className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-6 border-t border-slate-100 dark:border-slate-800">
          <p className="text-center text-xs text-slate-400 dark:text-slate-500 italic">
            More AI websites will be added soon.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
