import React, { useState, useEffect } from 'react';
import { Calculator, DollarSign, Calendar, Percent, ArrowRight, TrendingUp, Info } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function LoanCalculator() {
  const [principal, setPrincipal] = useState<number>(50000);
  const [interestRate, setInterestRate] = useState<number>(5);
  const [tenure, setTenure] = useState<number>(5);
  const [tenureType, setTenureType] = useState<'years' | 'months'>('years');

  const [emi, setEmi] = useState<number>(0);
  const [totalInterest, setTotalInterest] = useState<number>(0);
  const [totalPayment, setTotalPayment] = useState<number>(0);

  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('loan-calculator');
      if (saved) {
        setPrincipal(saved.principal || 50000);
        setInterestRate(saved.interestRate || 5);
        setTenure(saved.tenure || 5);
        setTenureType(saved.tenureType || 'years');
      }
    };
    init();
  }, []);

  useEffect(() => {
    calculateEMI();
    saveToolState('loan-calculator', { principal, interestRate, tenure, tenureType });
  }, [principal, interestRate, tenure, tenureType]);

  const calculateEMI = () => {
    const p = principal;
    const r = interestRate / 12 / 100;
    const n = tenureType === 'years' ? tenure * 12 : tenure;

    if (r === 0) {
      const emiVal = p / n;
      setEmi(emiVal);
      setTotalPayment(p);
      setTotalInterest(0);
      return;
    }

    const emiVal = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPay = emiVal * n;
    const totalInt = totalPay - p;

    setEmi(emiVal);
    setTotalPayment(totalPay);
    setTotalInterest(totalInt);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Calculator className="w-5 h-5 text-blue-500" />
          <h2>Loan / EMI Calculator</h2>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Inputs */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Loan Amount</label>
                  <span className="text-lg font-bold text-blue-600 dark:text-blue-400">${principal.toLocaleString()}</span>
                </div>
                <div className="relative pt-1">
                  <input
                    type="range"
                    min="1000"
                    max="1000000"
                    step="1000"
                    value={principal}
                    onChange={(e) => setPrincipal(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-2">
                    <span>$1K</span>
                    <span>$1M</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Interest Rate (p.a)</label>
                  <span className="text-lg font-bold text-blue-600 dark:text-blue-400">{interestRate}%</span>
                </div>
                <div className="relative pt-1">
                  <input
                    type="range"
                    min="1"
                    max="30"
                    step="0.1"
                    value={interestRate}
                    onChange={(e) => setInterestRate(parseFloat(e.target.value))}
                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-2">
                    <span>1%</span>
                    <span>30%</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Loan Tenure</label>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-blue-600 dark:text-blue-400">{tenure} {tenureType}</span>
                    <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-lg">
                      <button
                        onClick={() => setTenureType('years')}
                        className={`px-2 py-1 text-[10px] font-bold rounded-md transition-all ${tenureType === 'years' ? 'bg-white dark:bg-slate-700 text-blue-500 shadow-sm' : 'text-slate-500'}`}
                      >
                        Yr
                      </button>
                      <button
                        onClick={() => setTenureType('months')}
                        className={`px-2 py-1 text-[10px] font-bold rounded-md transition-all ${tenureType === 'months' ? 'bg-white dark:bg-slate-700 text-blue-500 shadow-sm' : 'text-slate-500'}`}
                      >
                        Mo
                      </button>
                    </div>
                  </div>
                </div>
                <div className="relative pt-1">
                  <input
                    type="range"
                    min="1"
                    max={tenureType === 'years' ? 30 : 360}
                    step="1"
                    value={tenure}
                    onChange={(e) => setTenure(parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-slate-400 mt-2">
                    <span>1</span>
                    <span>{tenureType === 'years' ? 30 : 360}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800 flex gap-3">
              <Info className="w-5 h-5 text-blue-500 shrink-0" />
              <p className="text-xs text-blue-700 dark:text-blue-300 leading-relaxed">
                This calculator provides an estimate of your monthly payments. Actual rates and terms may vary based on your lender.
              </p>
            </div>
          </div>

          {/* Results */}
          <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-xl shadow-slate-200/50 dark:shadow-none flex flex-col gap-8">
            <div className="text-center space-y-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Monthly EMI</span>
              <div className="text-5xl font-bold text-slate-800 dark:text-slate-100">
                ${emi.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Principal Amount</span>
                <span className="text-lg font-bold text-slate-700 dark:text-slate-200">${principal.toLocaleString()}</span>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Total Interest</span>
                <span className="text-lg font-bold text-slate-700 dark:text-slate-200">${totalInterest.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
              </div>
            </div>

            <div className="p-6 bg-blue-600 rounded-2xl text-white shadow-lg shadow-blue-500/30">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold uppercase tracking-widest opacity-80">Total Amount Payable</span>
                <TrendingUp className="w-4 h-4 opacity-80" />
              </div>
              <div className="text-3xl font-bold">
                ${totalPayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </div>
              <div className="mt-4 h-2 bg-white/20 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-white transition-all duration-500" 
                  style={{ width: `${(principal / totalPayment) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-bold mt-2 opacity-80">
                <span>Principal ({(principal / totalPayment * 100).toFixed(0)}%)</span>
                <span>Interest ({(totalInterest / totalPayment * 100).toFixed(0)}%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
