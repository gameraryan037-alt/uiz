import React, { useState, useRef, useEffect } from 'react';
import { Image as ImageIcon, Download, RotateCcw, Sliders, Maximize, Zap, Trash2, Upload, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function ManualImageEnhancer() {
  const [image, setImage] = useState<string | null>(null);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [saturation, setSaturation] = useState(100);
  const [sharpness, setSharpness] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('manual-image-enhancer');
      if (savedState) {
        setBrightness(savedState.brightness ?? 100);
        setContrast(savedState.contrast ?? 100);
        setSaturation(savedState.saturation ?? 100);
        setSharpness(savedState.sharpness ?? 0);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('manual-image-enhancer', { brightness, contrast, saturation, sharpness });
    }
  }, [brightness, contrast, saturation, sharpness, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const applyFilters = () => {
    if (!image || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;

      // Apply CSS-like filters first
      ctx.filter = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
      ctx.drawImage(img, 0, 0);

      // Apply Sharpening (Convolution Matrix) if sharpness > 0
      if (sharpness > 0) {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const sharpenedData = sharpen(imageData, sharpness / 100);
        ctx.putImageData(sharpenedData, 0, 0);
      }
    };
    img.src = image;
  };

  // Sharpening algorithm using a convolution matrix
  const sharpen = (imageData: ImageData, amount: number) => {
    const { width, height, data } = imageData;
    const output = new ImageData(width, height);
    const dst = output.data;
    
    // Sharpening kernel:
    // [ 0, -1,  0]
    // [-1,  5, -1]
    // [ 0, -1,  0]
    // We blend the sharpened version with the original based on 'amount'
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        for (let c = 0; c < 3; c++) { // R, G, B
          const idx = (y * width + x) * 4 + c;
          
          let sum = 0;
          // Apply 3x3 kernel
          for (let ky = -1; ky <= 1; ky++) {
            for (let kx = -1; kx <= 1; kx++) {
              const py = Math.min(Math.max(y + ky, 0), height - 1);
              const px = Math.min(Math.max(x + kx, 0), width - 1);
              const pIdx = (py * width + px) * 4 + c;
              
              let weight = 0;
              if (kx === 0 && ky === 0) weight = 5;
              else if (Math.abs(kx) + Math.abs(ky) === 1) weight = -1;
              
              sum += data[pIdx] * weight;
            }
          }
          
          // Blend original with sharpened
          const original = data[idx];
          dst[idx] = original + (sum - original) * amount;
        }
        dst[(y * width + x) * 4 + 3] = data[(y * width + x) * 4 + 3]; // Alpha
      }
    }
    return output;
  };

  useEffect(() => {
    if (image) {
      applyFilters();
    }
  }, [image, brightness, contrast, saturation, sharpness]);

  const downloadImage = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'enhanced-image.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  };

  const reset = () => {
    setBrightness(100);
    setContrast(100);
    setSaturation(100);
    setSharpness(0);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Maximize className="w-5 h-5 text-amber-500" />
          <h2>Image Enhancer</h2>
        </div>
        <div className="flex items-center gap-2">
          {image && (
            <button
              onClick={reset}
              className="p-2 text-slate-400 hover:text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
              title="Reset Filters"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        {!image ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-12 flex flex-col items-center justify-center gap-4 hover:border-amber-500 hover:bg-amber-50/50 dark:hover:bg-amber-900/10 transition-all cursor-pointer group"
          >
            <div className="w-20 h-20 bg-amber-50 dark:bg-amber-900/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
              <Upload className="w-10 h-10 text-amber-500" />
            </div>
            <div className="text-center">
              <p className="text-slate-700 dark:text-slate-200 font-bold text-lg">Upload Image to Enhance</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Improve clarity, sharpness, and colors manually.</p>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              accept="image/*" 
              className="hidden" 
            />
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Controls */}
            <div className="lg:col-span-1 space-y-6">
              <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Sharpness (De-blur)</label>
                    <span className="text-xs font-mono text-amber-500">{sharpness}%</span>
                  </div>
                  <input 
                    type="range" min="0" max="100" 
                    value={sharpness} 
                    onChange={(e) => setSharpness(parseInt(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Brightness</label>
                    <span className="text-xs font-mono text-amber-500">{brightness}%</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" 
                    value={brightness} 
                    onChange={(e) => setBrightness(parseInt(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Contrast</label>
                    <span className="text-xs font-mono text-amber-500">{contrast}%</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" 
                    value={contrast} 
                    onChange={(e) => setContrast(parseInt(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Saturation</label>
                    <span className="text-xs font-mono text-amber-500">{saturation}%</span>
                  </div>
                  <input 
                    type="range" min="0" max="200" 
                    value={saturation} 
                    onChange={(e) => setSaturation(parseInt(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-start gap-3">
                <Info className="w-5 h-5 text-slate-400 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-200 uppercase tracking-wider">How it works</p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    This tool uses advanced algorithms to sharpen edges and adjust color balance. Increase <strong>Sharpness</strong> to remove blurriness and reveal hidden details.
                  </p>
                </div>
              </div>
            </div>

            {/* Preview */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
                <div className="absolute inset-0 bg-grid-slate-100/50 dark:bg-grid-slate-900/20 [mask-image:radial-gradient(white,transparent)]" />
                
                <div className="relative z-10 max-w-full max-h-full overflow-auto custom-scrollbar p-4">
                  <canvas 
                    ref={canvasRef} 
                    className="max-w-full h-auto shadow-2xl rounded-lg"
                  />
                </div>

                <div className="absolute bottom-6 right-6 flex gap-2">
                  <button
                    onClick={downloadImage}
                    className="flex items-center gap-2 px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl shadow-lg shadow-amber-500/20 transition-all font-bold text-sm"
                  >
                    <Download className="w-4 h-4" />
                    Save Enhanced
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-center gap-4">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs font-bold text-slate-500 hover:text-amber-500 transition-colors flex items-center gap-2"
                >
                  <ImageIcon className="w-4 h-4" />
                  Change Image
                </button>
                <button 
                  onClick={() => setImage(null)}
                  className="text-xs font-bold text-red-500/70 hover:text-red-500 transition-colors flex items-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Remove
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImageUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
