import React, { useState, useEffect } from 'react';
import { ArrowRightLeft, Scale, Ruler, Clock, Hash, Save, Trash2, X, Download, HardDrive, Monitor, Thermometer } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

type UnitCategory = 'weight' | 'length' | 'time' | 'digital' | 'design' | 'temperature';

interface Unit {
  label: string;
  value: string;
  factor: number; // Factor relative to base unit
  offset?: number; // For temperature
}

const UNITS: Record<UnitCategory, Unit[]> = {
  weight: [
    { label: 'Gram (g)', value: 'g', factor: 1 },
    { label: 'Kilogram (kg)', value: 'kg', factor: 1000 },
    { label: 'Milligram (mg)', value: 'mg', factor: 0.001 },
    { label: 'Pound (lb)', value: 'lb', factor: 453.592 },
    { label: 'Ounce (oz)', value: 'oz', factor: 28.3495 },
  ],
  length: [
    { label: 'Meter (m)', value: 'm', factor: 1 },
    { label: 'Centimeter (cm)', value: 'cm', factor: 0.01 },
    { label: 'Millimeter (mm)', value: 'mm', factor: 0.001 },
    { label: 'Kilometer (km)', value: 'km', factor: 1000 },
    { label: 'Inch (in)', value: 'in', factor: 0.0254 },
    { label: 'Foot (ft)', value: 'ft', factor: 0.3048 },
    { label: 'Yard (yd)', value: 'yd', factor: 0.9144 },
    { label: 'Mile (mi)', value: 'mi', factor: 1609.34 },
  ],
  time: [
    { label: 'Second (sec)', value: 'sec', factor: 1 },
    { label: 'Minute (min)', value: 'min', factor: 60 },
    { label: 'Hour (hr)', value: 'hr', factor: 3600 },
    { label: 'Day', value: 'day', factor: 86400 },
    { label: 'Week', value: 'week', factor: 604800 },
  ],
  digital: [
    { label: 'Bytes (B)', value: 'B', factor: 1 },
    { label: 'Kilobytes (KB)', value: 'KB', factor: 1024 },
    { label: 'Megabytes (MB)', value: 'MB', factor: 1024 * 1024 },
    { label: 'Gigabytes (GB)', value: 'GB', factor: 1024 * 1024 * 1024 },
    { label: 'Terabytes (TB)', value: 'TB', factor: 1024 * 1024 * 1024 * 1024 },
  ],
  design: [
    { label: 'Pixels (px)', value: 'px', factor: 1 },
    { label: 'REM (rem)', value: 'rem', factor: 16 }, // Assuming 16px base
    { label: 'Points (pt)', value: 'pt', factor: 1.333 },
  ],
  temperature: [
    { label: 'Celsius (°C)', value: 'C', factor: 1, offset: 0 },
    { label: 'Fahrenheit (°F)', value: 'F', factor: 1.8, offset: 32 },
    { label: 'Kelvin (K)', value: 'K', factor: 1, offset: 273.15 },
  ],
};

interface SavedConversion {
  id: string;
  fromValue: string;
  fromUnit: string;
  toValue: string;
  toUnit: string;
  category: UnitCategory;
  timestamp: number;
}

export default function UnitConverter() {
  const [category, setCategory] = useState<UnitCategory>('weight');
  const [fromUnit, setFromUnit] = useState(UNITS.weight[1].value); // kg
  const [toUnit, setToUnit] = useState(UNITS.weight[0].value); // g
  const [fromValue, setFromValue] = useState<string>('1');
  const [toValue, setToValue] = useState<string>('');
  const [filename, setFilename] = useState('');
  const [savedConversions, setSavedConversions] = useState<SavedConversion[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('unit-converter');
      if (saved) {
        setCategory(saved.category || 'weight');
        setFromUnit(saved.fromUnit);
        setToUnit(saved.toUnit);
        setFromValue(saved.fromValue || '1');
        setSavedConversions(saved.savedConversions || []);
        setFilename(saved.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('unit-converter', { category, fromUnit, toUnit, fromValue, savedConversions, filename });
    }
  }, [category, fromUnit, toUnit, fromValue, savedConversions, filename, isLoaded]);

  useEffect(() => {
    // Reset units when category changes
    setFromUnit(UNITS[category][0].value);
    setToUnit(UNITS[category][1].value);
  }, [category]);

  useEffect(() => {
    convert(fromValue, fromUnit, toUnit);
  }, [fromValue, fromUnit, toUnit, category]);

  const convert = (val: string, from: string, to: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) {
      setToValue('');
      return;
    }

    const units = UNITS[category];
    const fromUnitObj = units.find(u => u.value === from)!;
    const toUnitObj = units.find(u => u.value === to)!;

    let result: number;

    if (category === 'temperature') {
      // Convert to Celsius first
      const celsius = (num - (fromUnitObj.offset || 0)) / fromUnitObj.factor;
      // Convert from Celsius to target
      result = (celsius * toUnitObj.factor) + (toUnitObj.offset || 0);
    } else {
      const fromFactor = fromUnitObj.factor;
      const toFactor = toUnitObj.factor;
      result = (num * fromFactor) / toFactor;
    }
    
    // Format result to avoid long decimals
    if (result === 0) {
      setToValue('0');
    } else if (Math.abs(result) < 0.00001 || Math.abs(result) > 1000000) {
      setToValue(result.toExponential(4));
    } else {
      setToValue(parseFloat(result.toFixed(6)).toString());
    }
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
    setFromValue(toValue);
  };

  const saveConversion = () => {
    if (!fromValue || !toValue) return;
    
    const newSave: SavedConversion = {
      id: Math.random().toString(36).substring(7),
      fromValue,
      fromUnit,
      toValue,
      toUnit,
      category,
      timestamp: Date.now()
    };
    
    setSavedConversions(prev => [newSave, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedConversions(prev => prev.filter(s => s.id !== id));
  };

  const clearAllSaved = () => {
    if (confirm('Are you sure you want to clear all saved conversions?')) {
      setSavedConversions([]);
    }
  };

  const downloadConversions = () => {
    if (savedConversions.length > 0) {
      let content = `Saved Conversions\n`;
      content += `=================\n\n`;
      savedConversions.forEach((save, i) => {
        content += `${i + 1}. ${save.fromValue} ${save.fromUnit} = ${save.toValue} ${save.toUnit} (${save.category})\n`;
      });

      const element = document.createElement('a');
      const file = new Blob([content], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'conversions', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const categories = [
    { id: 'weight', label: 'Weight', icon: Scale },
    { id: 'length', label: 'Length', icon: Ruler },
    { id: 'time', label: 'Time', icon: Clock },
    { id: 'digital', label: 'Digital', icon: HardDrive },
    { id: 'design', label: 'Design', icon: Monitor },
    { id: 'temperature', label: 'Temp', icon: Thermometer },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ArrowRightLeft className="w-5 h-5 text-indigo-500" />
          <h2>Unit Converter</h2>
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        {/* Category Selection */}
        <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl max-w-md mx-auto transition-colors">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id as UnitCategory)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-lg transition-all ${
                category === cat.id ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              <cat.icon className="w-4 h-4" /> {cat.label}
            </button>
          ))}
        </div>

        <div className="max-w-xl mx-auto w-full space-y-6">
          <div className="grid md:grid-cols-[1fr,auto,1fr] items-center gap-4">
            {/* From */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">From</label>
              <div className="space-y-3">
                <select
                  value={fromUnit}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 focus:border-indigo-500 outline-none text-sm bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 font-medium transition-colors"
                >
                  {UNITS[category].map(u => (
                    <option key={u.value} value={u.value}>{u.label}</option>
                  ))}
                </select>
                <input
                  type="number"
                  value={fromValue}
                  onChange={(e) => setFromValue(e.target.value)}
                  placeholder="0"
                  className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-800 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none text-xl font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-950 transition-all"
                />
              </div>
            </div>

            {/* Swap Button */}
            <div className="flex justify-center md:pt-8">
              <button
                onClick={swapUnits}
                className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 rounded-full hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors shadow-sm"
              >
                <ArrowRightLeft className="w-5 h-5" />
              </button>
            </div>

            {/* To */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider ml-1">To</label>
              <div className="space-y-3">
                <select
                  value={toUnit}
                  onChange={(e) => setToUnit(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 focus:border-indigo-500 outline-none text-sm bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 font-medium transition-colors"
                >
                  {UNITS[category].map(u => (
                    <option key={u.value} value={u.value}>{u.label}</option>
                  ))}
                </select>
                <div className="w-full p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xl font-bold text-indigo-600 dark:text-indigo-400 min-h-[60px] flex items-center transition-colors">
                  {toValue || '0'}
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 p-4 bg-indigo-50 dark:bg-indigo-900/10 rounded-xl border border-indigo-100 dark:border-indigo-900/30 flex items-start gap-3 transition-colors">
              <Hash className="w-5 h-5 text-indigo-500 dark:text-indigo-400 mt-0.5" />
              <p className="text-sm text-indigo-900 dark:text-indigo-100 leading-relaxed">
                Converting <span className="font-bold">{fromValue || '0'}</span> {UNITS[category].find(u => u.value === fromUnit)?.label} to <span className="font-bold">{toValue || '0'}</span> {UNITS[category].find(u => u.value === toUnit)?.label}.
              </p>
            </div>
            <button
              onClick={saveConversion}
              disabled={!fromValue || !toValue}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              Save Conversion
            </button>
          </div>

          {/* Saved Conversions */}
          {savedConversions.length > 0 && (
            <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">Saved Conversions</h3>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadConversions}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                  <button 
                    onClick={clearAllSaved}
                    className="text-xs text-red-500 hover:text-red-700 font-medium"
                  >
                    Clear All
                  </button>
                </div>
              </div>
              <div className="grid gap-3">
                {savedConversions.map((save) => (
                  <div key={save.id} className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 flex items-center justify-between group transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-white dark:bg-slate-700 rounded-lg flex items-center justify-center text-indigo-500 dark:text-indigo-400 shadow-sm transition-colors">
                        {save.category === 'weight' ? <Scale className="w-4 h-4" /> : 
                         save.category === 'length' ? <Ruler className="w-4 h-4" /> : 
                         <Clock className="w-4 h-4" />}
                      </div>
                      <div className="text-sm">
                        <span className="font-bold text-slate-900 dark:text-white">{save.fromValue}</span> <span className="text-slate-600 dark:text-slate-400">{save.fromUnit}</span>
                        <span className="mx-2 text-slate-400 dark:text-slate-600">→</span>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">{save.toValue}</span> <span className="text-slate-600 dark:text-slate-400">{save.toUnit}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => deleteSaved(save.id)}
                      className="p-2 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
