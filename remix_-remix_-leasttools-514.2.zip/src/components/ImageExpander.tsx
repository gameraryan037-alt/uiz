import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, Download, Check, Loader2, Image as ImageIcon, Sparkles, Trash2, AlertCircle, Maximize2, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError, withRetry } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

interface SavedExpansion {
  id: string;
  image: string;
  expandedImage: string;
  aspectRatio: string;
  timestamp: number;
}

export default function ImageExpander() {
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const [aspectRatio, setAspectRatio] = useState('16:9'); // '1:1', '16:9', '4:3', '9:16', '3:4'
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedItems, setSavedItems] = useState<SavedExpansion[]>([]);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('image-expander');
      if (savedState) {
        setImage(savedState.image || null);
        setExpandedImage(savedState.expandedImage || null);
        setAspectRatio(savedState.aspectRatio || '16:9');
        setSavedItems(savedState.savedItems || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('image-expander', { image, expandedImage, aspectRatio, savedItems, filename });
    }
  }, [image, expandedImage, aspectRatio, savedItems, filename, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setExpandedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onloadend = () => {
              setImage(reader.result as string);
              setExpandedImage(null);
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const expandImage = async () => {
    if (!image) return;
    setIsProcessing(true);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];
      setErrorDetails(null);
      
      const prompt = "Expand the background of this image to fill the requested aspect ratio. Keep the central subject exactly the same and blend the new background naturally.";

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Request timed out. Please check your internet connection or API key.")), 60000)
      );

      const response = await withRetry(async () => {
        return await Promise.race([
          ai.models.generateContent({
            model: "gemini-2.5-flash-image",
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                  }
                },
                { text: prompt }
              ]
            },
            config: {
              imageConfig: {
                aspectRatio: aspectRatio as any
              }
            }
          }),
          timeoutPromise
        ]);
      }) as any;

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            const base64EncodeString: string = part.inlineData.data;
            setExpandedImage(`data:image/png;base64,${base64EncodeString}`);
            break;
          }
        }
      } else {
        throw new Error("The AI did not return an image. It might have been blocked by safety filters.");
      }
    } catch (error: any) {
      const userMessage = handleGeminiError(error);
      setErrorDetails(userMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = () => {
    if (expandedImage) {
      const link = document.createElement('a');
      link.href = expandedImage;
      link.download = getDownloadFilename(filename, 'expanded', 'png');
      link.click();
    }
  };

  const saveToHistory = () => {
    if (!image || !expandedImage) return;
    const newItem: SavedExpansion = {
      id: Math.random().toString(36).substring(7),
      image,
      expandedImage,
      aspectRatio,
      timestamp: Date.now()
    };
    setSavedItems(prev => [newItem, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedItems(prev => prev.filter(item => item.id !== id));
  };

  const ratios = [
    { label: '1:1', value: '1:1' },
    { label: '16:9', value: '16:9' },
    { label: '4:3', value: '4:3' },
    { label: '9:16', value: '9:16' },
    { label: '3:4', value: '3:4' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Maximize2 className="w-5 h-5 text-purple-500" />
          <h2>AI Image Expander</h2>
        </div>
        <div className="flex items-center gap-2">
          {expandedImage && (
            <button
              onClick={saveToHistory}
              className="p-2 text-slate-400 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-purple-900/20 rounded-lg transition-colors"
              title="Save to History"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          {(image || expandedImage) && (
            <button
              onClick={() => {
                setImage(null);
                setExpandedImage(null);
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {errorDetails && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{errorDetails}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Upload Section */}
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Original Image</label>
            <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${image ? 'border-purple-200 dark:border-purple-900/50 bg-purple-50/30 dark:bg-purple-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-600 bg-slate-50 dark:bg-slate-950'}`}>
              {image ? (
                <div className="relative w-full aspect-square rounded-lg overflow-hidden shadow-sm">
                  <img src={image} alt="Upload preview" className="w-full h-full object-contain" />
                  <button 
                    onClick={() => setImage(null)}
                    className="absolute top-2 right-2 p-1.5 bg-white/80 dark:bg-slate-800/80 backdrop-blur rounded-full shadow-sm hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors"
                  >
                    <Check className="w-4 h-4 rotate-45" />
                  </button>
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleImageUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                    <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                      <button onClick={() => document.getElementById('file-upload-expander')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                      {" or "}
                      <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                      {" an image"}
                    </p>
                  </div>
                  <input id="file-upload-expander" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Target Aspect Ratio</label>
              <div className="flex flex-wrap gap-2">
                {ratios.map((r) => (
                  <button
                    key={r.value}
                    onClick={() => setAspectRatio(r.value)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      aspectRatio === r.value 
                        ? 'bg-purple-600 text-white shadow-md' 
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={expandImage}
              disabled={!image || isProcessing}
              className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all shadow-lg shadow-purple-100 dark:shadow-none disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Expanding...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Expand Background
                </>
              )}
            </button>
          </div>

          {/* Result Section */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Expanded Result</label>
              {expandedImage && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-purple-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.png</span>
                  </div>
                  <button
                    onClick={downloadImage}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              )}
            </div>
            <div className="flex-1 min-h-[300px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col items-center justify-center overflow-hidden transition-colors shadow-inner">
              {expandedImage ? (
                <img src={expandedImage} alt="Expanded result" className="max-w-full max-h-full object-contain rounded-lg shadow-sm" />
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50">
                  <ImageIcon className="w-12 h-12 mb-2" />
                  <p>Expanded image will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* History Section */}
        {savedItems.length > 0 && (
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider ml-1">History</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) setSavedItems([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {savedItems.map((item) => (
                <div key={item.id} className="group relative bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden aspect-square transition-colors">
                  <img src={item.expandedImage} alt="Saved result" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                    <p className="text-[10px] text-white font-bold uppercase tracking-wider">{item.aspectRatio}</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setImage(item.image);
                          setExpandedImage(item.expandedImage);
                          setAspectRatio(item.aspectRatio);
                        }}
                        className="p-1.5 bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-50 dark:hover:bg-slate-700 transition-colors"
                        title="Load"
                      >
                        <Upload className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => deleteSaved(item.id)}
                        className="p-1.5 bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-slate-700 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
