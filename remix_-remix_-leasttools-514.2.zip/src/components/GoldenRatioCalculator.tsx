import React, { useState, useEffect, useRef } from 'react';
import { Upload, Trash2, Eye, EyeOff, Maximize, RefreshCw, Image as ImageIcon } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function GoldenRatioCalculator() {
  const [image, setImage] = useState<string | null>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [opacity, setOpacity] = useState(0.5);
  const [rotation, setRotation] = useState(0);
  const [flipX, setFlipX] = useState(false);
  const [flipY, setFlipY] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('golden-ratio-calculator');
      if (savedState) {
        setImage(savedState.image ?? null);
        setShowOverlay(savedState.showOverlay ?? true);
        setOpacity(savedState.opacity ?? 0.5);
        setRotation(savedState.rotation ?? 0);
        setFlipX(savedState.flipX ?? false);
        setFlipY(savedState.flipY ?? false);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('golden-ratio-calculator', { image, showOverlay, opacity, rotation, flipX, flipY });
    }
  }, [image, showOverlay, opacity, rotation, flipX, flipY, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = () => setImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const renderSpiral = () => {
    if (!showOverlay) return null;

    return (
      <svg 
        viewBox="0 0 100 100" 
        className="absolute inset-0 w-full h-full pointer-events-none transition-all duration-300"
        style={{ 
          opacity, 
          transform: `rotate(${rotation}deg) scale(${flipX ? -1 : 1}, ${flipY ? -1 : 1})`,
          stroke: 'white',
          strokeWidth: 0.5,
          fill: 'none'
        }}
      >
        {/* Fibonacci Spiral Approximation using Arcs */}
        <path d="M 0,0 L 100,0 L 100,100 L 0,100 Z" stroke="rgba(255,255,255,0.2)" />
        <path d="M 61.8,0 L 61.8,100 M 61.8,61.8 L 100,61.8 M 61.8,38.2 L 0,38.2 M 38.2,0 L 38.2,38.2" stroke="rgba(255,255,255,0.5)" />
        <path d="M 0,0 A 100,100 0 0 1 100,100 A 61.8,61.8 0 0 1 38.2,38.2 A 38.2,38.2 0 0 1 76.4,0 A 23.6,23.6 0 0 1 100,23.6" stroke="gold" strokeWidth="1" />
      </svg>
    );
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Maximize className="w-5 h-5 text-indigo-500" />
          <h2>Golden Ratio Calculator</h2>
        </div>
        <div className="flex items-center gap-2">
          {image && (
            <button
              onClick={() => setImage(null)}
              className="p-2 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
              title="Clear Image"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => {
              setRotation(0);
              setFlipX(false);
              setFlipY(false);
              setOpacity(0.5);
            }}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Reset Overlay"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Overlay Opacity ({Math.round(opacity * 100)}%)</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={opacity} onChange={(e) => setOpacity(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Rotation ({rotation}°)</label>
              <div className="flex gap-2">
                {[0, 90, 180, 270].map(deg => (
                  <button 
                    key={deg}
                    onClick={() => setRotation(deg)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all ${rotation === deg ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                  >
                    {deg}°
                  </button>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Flip Overlay</label>
              <div className="flex gap-2">
                <button 
                  onClick={() => setFlipX(!flipX)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all ${flipX ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                >
                  Flip X
                </button>
                <button 
                  onClick={() => setFlipY(!flipY)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all ${flipY ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
                >
                  Flip Y
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Show Overlay</label>
              <button 
                onClick={() => setShowOverlay(!showOverlay)}
                className={`p-2 rounded-lg border transition-all ${showOverlay ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
              >
                {showOverlay ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">About Golden Ratio</h3>
            <p className="text-[10px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
              The Golden Ratio (φ ≈ 1.618) is a mathematical ratio commonly found in nature and art. 
              Use this tool to overlay the Fibonacci spiral on your images to help with composition and cropping.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden group">
          {image ? (
            <div ref={containerRef} className="relative w-full h-full flex items-center justify-center">
              <img 
                src={image} 
                alt="Uploaded" 
                className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="relative w-full h-full max-w-full max-h-full aspect-square">
                  {renderSpiral()}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-slate-100 dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto">
                <ImageIcon className="w-8 h-8 text-slate-400" />
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-500">Upload an image to start</p>
                <button 
                  onClick={() => document.getElementById('golden-ratio-upload')?.click()}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
                >
                  Select Image
                </button>
                <input 
                  id="golden-ratio-upload" 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload} 
                  className="hidden" 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
