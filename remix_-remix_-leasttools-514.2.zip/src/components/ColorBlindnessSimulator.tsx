import React, { useState, useRef } from 'react';
import { Eye, Upload, Download, RefreshCw, Info } from 'lucide-react';

interface Deficiency {
  id: string;
  name: string;
  description: string;
  matrix: string;
}

const DEFICIENCIES: Deficiency[] = [
  {
    id: 'normal',
    name: 'Normal Vision',
    description: 'Standard color perception.',
    matrix: '1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0',
  },
  {
    id: 'protanopia',
    name: 'Protanopia',
    description: 'Red-blind; unable to perceive red light.',
    matrix: '0.567 0.433 0 0 0  0.558 0.442 0 0 0  0 0.242 0.758 0 0  0 0 0 1 0',
  },
  {
    id: 'protanomaly',
    name: 'Protanomaly',
    description: 'Red-weak; reduced sensitivity to red light.',
    matrix: '0.817 0.183 0 0 0  0.333 0.667 0 0 0  0 0.125 0.875 0 0  0 0 0 1 0',
  },
  {
    id: 'deuteranopia',
    name: 'Deuteranopia',
    description: 'Green-blind; unable to perceive green light.',
    matrix: '0.625 0.375 0 0 0  0.7 0.3 0 0 0  0 0.3 0.7 0 0  0 0 0 1 0',
  },
  {
    id: 'deuteranomaly',
    name: 'Deuteranomaly',
    description: 'Green-weak; reduced sensitivity to green light.',
    matrix: '0.8 0.2 0 0 0  0.258 0.742 0 0 0  0 0.142 0.858 0 0  0 0 0 1 0',
  },
  {
    id: 'tritanopia',
    name: 'Tritanopia',
    description: 'Blue-blind; unable to perceive blue light.',
    matrix: '0.95 0.05 0 0 0  0 0.433 0.567 0 0  0 0.475 0.525 0 0  0 0 0 1 0',
  },
  {
    id: 'tritanomaly',
    name: 'Tritanomaly',
    description: 'Blue-weak; reduced sensitivity to blue light.',
    matrix: '0.967 0.033 0 0 0  0 0.733 0.267 0 0  0 0.183 0.817 0 0  0 0 0 1 0',
  },
  {
    id: 'achromatopsia',
    name: 'Achromatopsia',
    description: 'Total color blindness; perceiving only shades of gray.',
    matrix: '0.299 0.587 0.114 0 0  0.299 0.587 0.114 0 0  0.299 0.587 0.114 0 0  0 0 0 1 0',
  },
  {
    id: 'achromatomaly',
    name: 'Achromatomaly',
    description: 'Partial color blindness; significantly reduced color perception.',
    matrix: '0.618 0.320 0.062 0 0  0.163 0.775 0.062 0 0  0.163 0.320 0.516 0 0  0 0 0 1 0',
  },
];

export default function ColorBlindnessSimulator() {
  const [image, setImage] = useState<string | null>(null);
  const [selectedDeficiency, setSelectedDeficiency] = useState<string>('normal');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const reset = () => {
    setImage(null);
    setSelectedDeficiency('normal');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="max-w-5xl mx-auto p-6 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800">
      {/* SVG Filters Definition */}
      <svg style={{ display: 'none' }}>
        <defs>
          {DEFICIENCIES.map((d) => (
            <filter key={d.id} id={`filter-${d.id}`}>
              <feColorMatrix type="matrix" values={d.matrix} />
            </filter>
          ))}
        </defs>
      </svg>

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl">
            <Eye className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Color Blindness Simulator</h2>
            <p className="text-slate-500 dark:text-slate-400">Visualize how images appear to people with color vision deficiencies.</p>
          </div>
        </div>
        {image && (
          <button
            onClick={reset}
            className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Reset
          </button>
        )}
      </div>

      {!image ? (
        <div 
          onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl hover:border-indigo-500 dark:hover:border-indigo-500 transition-all cursor-pointer bg-slate-50 dark:bg-slate-800/50 group"
        >
          <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl shadow-sm mb-4 group-hover:scale-110 transition-transform">
            <Upload className="w-8 h-8 text-indigo-500" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Upload an image</h3>
          <p className="text-slate-500 dark:text-slate-400 text-center max-w-xs">
            Select a colorful image to see the simulation effects clearly.
          </p>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden"
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="relative aspect-video bg-slate-100 dark:bg-slate-800 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-inner">
              <img
                src={image}
                alt="Simulator Preview"
                className="w-full h-full object-contain transition-all duration-300"
                style={{ filter: `url(#filter-${selectedDeficiency})` }}
              />
              <div className="absolute top-4 left-4 px-3 py-1.5 bg-black/50 backdrop-blur-md text-white text-xs font-bold rounded-full uppercase tracking-widest">
                {DEFICIENCIES.find(d => d.id === selectedDeficiency)?.name}
              </div>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800/30 flex gap-4">
              <Info className="w-5 h-5 text-blue-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-blue-900 dark:text-blue-300 mb-1">
                  {DEFICIENCIES.find(d => d.id === selectedDeficiency)?.name}
                </h4>
                <p className="text-xs text-blue-700 dark:text-blue-400 leading-relaxed">
                  {DEFICIENCIES.find(d => d.id === selectedDeficiency)?.description}
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest opacity-50 mb-2">Select Deficiency</h3>
            <div className="grid grid-cols-1 gap-2">
              {DEFICIENCIES.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setSelectedDeficiency(d.id)}
                  className={`flex flex-col p-3 text-left rounded-xl border transition-all ${
                    selectedDeficiency === d.id
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none'
                      : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-indigo-300 dark:hover:border-indigo-700'
                  }`}
                >
                  <span className="text-sm font-bold">{d.name}</span>
                  <span className={`text-[10px] ${selectedDeficiency === d.id ? 'text-indigo-100' : 'text-slate-500'}`}>
                    {d.id === 'normal' ? 'Standard vision' : d.id.includes('anopia') ? 'Blindness' : 'Weakness'}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
