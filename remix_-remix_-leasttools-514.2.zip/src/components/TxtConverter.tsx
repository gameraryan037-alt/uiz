import React, { useState, useRef, useEffect } from 'react';
import { Download, FileText, Copy, Check, Upload, Trash2, AlertCircle, FileUp, FileDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

type Mode = 'write' | 'read';

export default function TxtConverter() {
  const [mode, setMode] = useState<Mode>('write');
  const [text, setText] = useState('');
  const [filename, setFilename] = useState('');
  const [readContent, setReadContent] = useState<string | null>(null);
  const [readFileName, setReadFileName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('txt-converter');
      if (savedState) {
        setText(savedState.text || '');
        setFilename(savedState.filename || '');
        setReadContent(savedState.readContent || null);
        setReadFileName(savedState.readFileName || null);
        setMode(savedState.mode || 'write');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('txt-converter', { text, filename, readContent, readFileName, mode });
    }
  }, [text, filename, readContent, readFileName, mode, isLoaded]);

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = getDownloadFilename(filename, 'txt', 'txt');
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    processFile(file);
  };

  const processFile = (file: File) => {
    setError(null);
    if (file.type !== 'text/plain' && !file.name.endsWith('.txt')) {
      setError('Please upload a valid .txt file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result;
      if (typeof text === 'string') {
        setReadContent(text);
        setReadFileName(file.name);
      }
    };
    reader.onerror = () => setError('Error reading file');
    reader.readAsText(file);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileText className="w-5 h-5 text-indigo-500" />
          <h2>Txt Converter</h2>
        </div>
        <div className="flex bg-slate-200 dark:bg-slate-800 p-1 rounded-lg transition-colors">
          <button
            onClick={() => setMode('write')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'write' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            Text to .txt
          </button>
          <button
            onClick={() => setMode('read')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${mode === 'read' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
          >
            .txt to Text
          </button>
        </div>
      </div>

      <div className="p-6 flex-1 flex flex-col">
        {mode === 'write' ? (
          <div className="flex-1 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Write Content</label>
              <button
                onClick={() => handleCopy(text)}
                disabled={!text}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium flex items-center gap-1 disabled:opacity-50"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied' : 'Copy All'}
              </button>
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Type or paste your text here..."
              className="flex-1 w-full min-h-[300px] p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none resize-none font-mono text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
            <div className="flex gap-3 items-end">
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 ml-1">Filename</label>
                <div className="relative">
                  <input
                    type="text"
                    value={filename}
                    onChange={(e) => setFilename(e.target.value)}
                    placeholder="Enter Filename (Optional)"
                    className="w-full pl-3 pr-12 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 dark:focus:ring-indigo-900/30 outline-none text-sm text-slate-700 dark:text-slate-200"
                  />
                  <span className="absolute right-3 top-2.5 text-slate-400 dark:text-slate-600 text-sm pointer-events-none">.txt</span>
                </div>
              </div>
              <button
                onClick={handleDownload}
                disabled={!text}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium text-sm flex items-center gap-2 transition-colors disabled:opacity-50 shadow-lg shadow-indigo-100 dark:shadow-none"
              >
                <Download className="w-4 h-4" />
                Download .txt
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col">
            {!readContent ? (
              <div 
                className="flex-1 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl flex flex-col items-center justify-center p-12 text-center hover:border-indigo-400 dark:hover:border-indigo-600 hover:bg-indigo-50/30 dark:hover:bg-indigo-900/10 transition-all cursor-pointer group"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Upload className="w-8 h-8" />
                </div>
                <h3 className="text-slate-900 dark:text-white font-lg font-medium mb-1">Upload .txt File</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm mb-4">Click to browse or drag & drop</p>
                {error && (
                  <div className="flex items-center gap-2 text-red-500 text-sm bg-red-50 dark:bg-red-900/20 px-3 py-2 rounded-lg">
                    <AlertCircle className="w-4 h-4" />
                    {error}
                  </div>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".txt"
                  className="hidden"
                />
              </div>
            ) : (
              <div className="flex-1 flex flex-col h-full">
                <div className="flex items-center justify-between mb-3 px-1">
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                    <FileText className="w-3 h-3" />
                    {readFileName}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCopy(readContent)}
                      className="p-2 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                      title="Copy content"
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => { setReadContent(null); setReadFileName(null); }}
                      className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                      title="Clear"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="flex-1 w-full p-6 rounded-xl bg-slate-100/50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-sm text-slate-700 dark:text-slate-200 overflow-auto whitespace-pre-wrap transition-colors">
                  {readContent}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
