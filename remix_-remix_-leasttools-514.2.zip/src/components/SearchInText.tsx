import React, { useState, useEffect, useMemo } from 'react';
import { Search, Trash2 } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function SearchInText() {
  const [text, setText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('search-in-text');
      if (savedState) {
        setText(savedState.text || '');
        setSearchTerm(savedState.searchTerm || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('search-in-text', { text, searchTerm });
    }
  }, [text, searchTerm, isLoaded]);

  const matchCount = useMemo(() => {
    if (!searchTerm || !text) return 0;
    try {
      const regex = new RegExp(searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      const matches = text.match(regex);
      return matches ? matches.length : 0;
    } catch (e) {
      return 0;
    }
  }, [text, searchTerm]);

  const renderHighlightedText = () => {
    if (!text) return <span className="text-slate-400 italic">No text content...</span>;
    if (!searchTerm) return <div className="whitespace-pre-wrap font-sans text-sm text-slate-700 dark:text-slate-200">{text}</div>;

    try {
      const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      const parts = text.split(regex);
      
      return (
        <div className="whitespace-pre-wrap font-sans text-sm text-slate-700 dark:text-slate-200">
          {parts.map((part, i) => 
            part.toLowerCase() === searchTerm.toLowerCase() ? 
            <mark key={i} className="bg-yellow-300 text-slate-900 rounded-sm px-0.5 font-medium shadow-sm">{part}</mark> : 
            <span key={i}>{part}</span>
          )}
        </div>
      );
    } catch (e) {
      return <div className="whitespace-pre-wrap font-sans text-sm text-slate-700 dark:text-slate-200">{text}</div>;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      const searchInput = document.querySelector('input[placeholder="Type word to find..."]') as HTMLInputElement;
      searchInput?.focus();
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Search className="w-5 h-5 text-blue-500" />
          <h2>Search & Highlight</h2>
        </div>
        <div className="flex items-center gap-2">
          {(text || searchTerm) && (
            <button
              onClick={() => {
                setText('');
                setSearchTerm('');
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col gap-4 min-h-0">
        {/* Search Input Area */}
        <div className="relative shrink-0">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-slate-500" />
          <input 
            type="text" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Type word to find..."
            className="w-full pl-12 pr-4 py-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900/30 outline-none text-base transition-all shadow-sm dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600"
          />
        </div>

        {/* Stats Bar */}
        {searchTerm && (
          <div className="flex items-center gap-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/30 px-4 py-2 rounded-lg text-sm shrink-0 animate-in fade-in slide-in-from-top-2">
            <span className="font-medium text-blue-700 dark:text-blue-300">Results:</span>
            <span className="bg-white dark:bg-slate-800 px-2 py-0.5 rounded border border-blue-100 dark:border-blue-900/30 text-blue-600 dark:text-blue-400 font-bold text-xs">
              {matchCount}
            </span>
            <span className="text-blue-600 dark:text-blue-400">matches found</span>
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 flex flex-col gap-4 min-h-0">
          {/* Input Textarea - Shrinks when searching to show preview */}
          <div className={`transition-all duration-300 ease-in-out flex flex-col ${searchTerm ? 'h-1/3 min-h-[120px]' : 'h-full'}`}>
            <label className="text-xs font-medium text-slate-400 dark:text-slate-500 mb-1 ml-1 uppercase tracking-wider">Input Text</label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Paste or type your text here..."
              className="flex-1 w-full p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 dark:focus:ring-blue-900/30 outline-none resize-none font-sans text-sm text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
          </div>
          
          {/* Highlight Preview - Only visible when searching */}
          {searchTerm && (
            <div className="flex-1 flex flex-col min-h-0 animate-in fade-in slide-in-from-bottom-4">
              <label className="text-xs font-medium text-slate-400 dark:text-slate-500 mb-1 ml-1 uppercase tracking-wider">Highlight View</label>
              <div className="flex-1 overflow-auto p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 shadow-inner custom-scrollbar">
                {renderHighlightedText()}
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
