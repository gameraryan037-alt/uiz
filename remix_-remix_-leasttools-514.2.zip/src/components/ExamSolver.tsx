import React, { useState, useEffect, useRef } from 'react';
import { FileText, Upload, Loader2, Image as ImageIcon, Sparkles, Trash2, AlertCircle, FileUp, Zap, Search, Clipboard } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import * as pdfjsLib from 'pdfjs-dist';
import { getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';
import { Download } from 'lucide-react';
import Markdown from 'react-markdown';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';

// Set worker path for pdfjs
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export default function ExamSolver() {
  const [input, setInput] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [solution, setSolution] = useState<string | null>(null);
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('exam-solver');
      if (savedState) {
        setInput(savedState.input || '');
        setImage(savedState.image || null);
        setSolution(savedState.solution || null);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('exam-solver', { input, image, solution, filename });
    }
  }, [input, image, solution, filename, isLoaded]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorDetails(null);
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setPdfFile(null);
      };
      reader.readAsDataURL(file);
    } else if (file.type === 'application/pdf') {
      setPdfFile(file);
      setImage(null);
    } else {
      setErrorDetails('Unsupported file type. Please upload an image or PDF.');
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onloadend = () => {
              setImage(reader.result as string);
              setPdfFile(null);
              setSolution(null);
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const downloadSolution = () => {
    if (solution) {
      const element = document.createElement('a');
      const file = new Blob([solution], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = getDownloadFilename(filename, 'solution', 'txt');
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
  };

  const solveExam = async () => {
    if (!input.trim() && !image && !pdfFile) return;
    setIsProcessing(true);
    setErrorDetails(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      let parts: any[] = [];

      // 1. Add text input if present
      if (input.trim()) {
        parts.push({ text: `Question/Context: ${input}` });
      }

      // 2. Add image if present
      if (image) {
        const base64Data = image.split(',')[1];
        const mimeType = image.split(';')[0].split(':')[1];
        parts.push({
          inlineData: {
            mimeType,
            data: base64Data
          }
        });
      }

      // 3. Add PDF if present (convert first page to image for analysis)
      if (pdfFile) {
        const arrayBuffer = await pdfFile.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        if (context) {
          canvas.height = viewport.height;
          canvas.width = viewport.width;
          const renderContext: any = {
            canvasContext: context,
            viewport: viewport,
          };
          await page.render(renderContext).promise;
          const pdfImageBase64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
          parts.push({
            inlineData: {
              mimeType: 'image/jpeg',
              data: pdfImageBase64
            }
          });
        }
      }

      const prompt = `You are an expert Exam Solver. Analyze the provided text and images carefully. 
      Identify any diagrams, figures, charts, or mathematical equations. 
      Provide a detailed, step-by-step solution to the questions found. 
      If there are multiple questions, solve them one by one. 
      Use clear formatting and explain the reasoning behind each step. 
      If a diagram is present, describe it and explain how it relates to the solution.`;

      parts.push({ text: prompt });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: { parts }
      });

      setSolution(response.text || 'No solution generated.');
    } catch (error: any) {
      setErrorDetails(handleGeminiError(error));
    } finally {
      setIsProcessing(false);
    }
  };

  const clearAll = () => {
    setInput('');
    setImage(null);
    setPdfFile(null);
    setSolution(null);
    setErrorDetails(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Zap className="w-5 h-5 text-yellow-500" />
          <h2>AI Exam Solver</h2>
        </div>
        {(input || image || pdfFile || solution) && (
          <button
            onClick={clearAll}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            title="Clear all"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {errorDetails && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{errorDetails}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          {/* Input Section */}
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Question Text (Optional)</label>
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your question here or paste text..."
                className="w-full h-32 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-yellow-500 focus:ring-2 focus:ring-yellow-200 dark:focus:ring-yellow-900/30 outline-none resize-none text-sm leading-relaxed text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Upload Image or PDF</label>
              <div 
                className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${image || pdfFile ? 'border-yellow-200 dark:border-yellow-900/50 bg-yellow-50/30 dark:bg-yellow-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-yellow-400 dark:hover:border-yellow-600 bg-slate-50 dark:bg-slate-950'}`}
              >
                {image ? (
                  <div className="relative w-full aspect-video rounded-lg overflow-hidden shadow-sm">
                    <img src={image} alt="Preview" className="w-full h-full object-contain" />
                    <input 
                      type="file" 
                      accept="image/*,application/pdf" 
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                ) : pdfFile ? (
                  <div className="flex flex-col items-center gap-2">
                    <FileUp className="w-10 h-10 text-yellow-600 dark:text-yellow-500" />
                    <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[200px]">{pdfFile.name}</p>
                    <p className="text-xs text-slate-400 dark:text-slate-500">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    <input 
                      type="file" 
                      accept="image/*,application/pdf" 
                      onChange={handleFileUpload}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex flex-col items-center gap-2">
                      <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                      <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                        <button onClick={() => fileInputRef.current?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                        {" or "}
                        <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                        {" an image/PDF"}
                      </p>
                    </div>
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      accept="image/*,application/pdf" 
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={solveExam}
              disabled={(!input.trim() && !image && !pdfFile) || isProcessing}
              className="w-full py-3 bg-yellow-500 hover:bg-yellow-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-yellow-100 dark:shadow-none disabled:opacity-50 disabled:shadow-none"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Solving...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Solve with AI
                </>
              )}
            </button>
          </div>

          {/* Result Section */}
          <div className="space-y-4 flex flex-col">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Detailed Solution</label>
              {solution && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-yellow-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                  <button
                    onClick={downloadSolution}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(solution);
                      alert('Solution copied to clipboard!');
                    }}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-yellow-600 dark:hover:text-yellow-400 transition-colors"
                  >
                    <Clipboard className="w-3 h-3" />
                    Copy
                  </button>
                </div>
              )}
            </div>
            <div className="flex-1 min-h-[400px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 overflow-y-auto transition-all shadow-inner custom-scrollbar">
              {isProcessing ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 italic">
                  <Loader2 className="w-10 h-10 animate-spin mb-4 text-yellow-500" />
                  <p>Analyzing questions and diagrams...</p>
                  <p className="text-xs mt-2">This may take a few moments for complex problems.</p>
                </div>
              ) : solution ? (
                <div className="markdown-body prose prose-slate dark:prose-invert prose-sm max-w-none">
                  <Markdown>{solution}</Markdown>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50">
                  <Search className="w-12 h-12 mb-2" />
                  <p>Solution will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
