import React, { useState, useEffect } from 'react';
import { ClipboardCheck, Plus, Trash2, Check, X, Flame, Calendar, ChevronLeft, ChevronRight, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

interface Habit {
  id: string;
  name: string;
  color: string;
  completedDates: string[]; // ISO date strings (YYYY-MM-DD)
}

const COLORS = [
  'bg-red-500', 'bg-orange-500', 'bg-amber-500', 'bg-emerald-500', 
  'bg-blue-500', 'bg-indigo-500', 'bg-violet-500', 'bg-pink-500'
];

export default function HabitTracker() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [newHabitName, setNewHabitName] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - d.getDay()); // Start of current week (Sunday)
    d.setHours(0, 0, 0, 0);
    return d;
  });

  useEffect(() => {
    const init = async () => {
      const saved = await loadToolState('habit-tracker');
      if (saved && saved.habits) {
        setHabits(saved.habits);
      }
    };
    init();
  }, []);

  useEffect(() => {
    saveToolState('habit-tracker', { habits });
  }, [habits]);

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;

    const habit: Habit = {
      id: Math.random().toString(36).substr(2, 9),
      name: newHabitName,
      color: selectedColor,
      completedDates: []
    };

    setHabits([...habits, habit]);
    setNewHabitName('');
  };

  const toggleHabit = (habitId: string, dateStr: string) => {
    setHabits(habits.map(h => {
      if (h.id === habitId) {
        const isCompleted = h.completedDates.includes(dateStr);
        return {
          ...h,
          completedDates: isCompleted 
            ? h.completedDates.filter(d => d !== dateStr)
            : [...h.completedDates, dateStr]
        };
      }
      return h;
    }));
  };

  const removeHabit = (id: string) => {
    setHabits(habits.filter(h => h.id !== id));
  };

  const getWeekDays = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(currentWeekStart);
      d.setDate(d.getDate() + i);
      days.push(d);
    }
    return days;
  };

  const formatDate = (date: Date) => date.toISOString().split('T')[0];

  const getStreak = (habit: Habit) => {
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let checkDate = new Date(today);
    while (habit.completedDates.includes(formatDate(checkDate))) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    }
    return streak;
  };

  const weekDays = getWeekDays();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ClipboardCheck className="w-5 h-5 text-emerald-500" />
          <h2>Habit Tracker</h2>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => {
              const d = new Date(currentWeekStart);
              d.setDate(d.getDate() - 7);
              setCurrentWeekStart(d);
            }}
            className="p-2 text-slate-400 hover:text-emerald-500 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
            {currentWeekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {weekDays[6].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
          <button 
            onClick={() => {
              const d = new Date(currentWeekStart);
              d.setDate(d.getDate() + 7);
              setCurrentWeekStart(d);
            }}
            className="p-2 text-slate-400 hover:text-emerald-500 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Add Habit */}
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">New Habit</h3>
            <form onSubmit={addHabit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Habit Name</label>
                <input
                  type="text"
                  value={newHabitName}
                  onChange={(e) => setNewHabitName(e.target.value)}
                  placeholder="Drink water, Exercise..."
                  className="w-full px-4 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Color Theme</label>
                <div className="flex flex-wrap gap-2">
                  {COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setSelectedColor(color)}
                      className={`w-8 h-8 rounded-full ${color} transition-all ${selectedColor === color ? 'ring-4 ring-slate-200 dark:ring-slate-700 scale-110' : 'opacity-60 hover:opacity-100'}`}
                    />
                  ))}
                </div>
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-bold shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Add Habit
              </button>
            </form>

            {/* Stats Summary */}
            <div className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4">
              <div className="flex items-center gap-3">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span className="text-sm font-bold text-slate-700 dark:text-slate-200">Weekly Progress</span>
              </div>
              <div className="space-y-2">
                {habits.map(habit => {
                  const weekCount = habit.completedDates.filter(d => weekDays.some(wd => formatDate(wd) === d)).length;
                  return (
                    <div key={habit.id} className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        <span>{habit.name}</span>
                        <span>{weekCount}/7</span>
                      </div>
                      <div className="h-1.5 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden">
                        <div 
                          className={`h-full ${habit.color} transition-all duration-500`} 
                          style={{ width: `${(weekCount / 7) * 100}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Habit Grid */}
          <div className="lg:col-span-2 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100">Daily Tracker</h3>
            <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
              <div className="grid grid-cols-[1fr_repeat(7,48px)] border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                <div className="p-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Habit</div>
                {weekDays.map(day => (
                  <div key={day.toString()} className="p-4 text-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">{day.toLocaleDateString('en-US', { weekday: 'short' })}</span>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{day.getDate()}</span>
                  </div>
                ))}
              </div>

              <div className="divide-y divide-slate-200 dark:divide-slate-700">
                <AnimatePresence mode="popLayout">
                  {habits.length === 0 ? (
                    <div className="p-12 text-center text-slate-400 text-sm font-medium">
                      No habits added yet. Start by adding one!
                    </div>
                  ) : (
                    habits.map((habit) => (
                      <motion.div
                        key={habit.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="grid grid-cols-[1fr_repeat(7,48px)] items-center group"
                      >
                        <div className="p-4 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-2 h-2 rounded-full ${habit.color}`} />
                            <span className="font-bold text-slate-700 dark:text-slate-200">{habit.name}</span>
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="flex items-center gap-1 text-orange-500">
                              <Flame className="w-3 h-3 fill-current" />
                              <span className="text-[10px] font-bold">{getStreak(habit)}</span>
                            </div>
                            <button
                              onClick={() => removeHabit(habit.id)}
                              className="p-1 text-slate-300 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        {weekDays.map(day => {
                          const dateStr = formatDate(day);
                          const isCompleted = habit.completedDates.includes(dateStr);
                          return (
                            <div key={dateStr} className="p-2 flex justify-center">
                              <button
                                onClick={() => toggleHabit(habit.id, dateStr)}
                                className={`w-8 h-8 rounded-lg border-2 transition-all flex items-center justify-center ${
                                  isCompleted 
                                    ? `${habit.color} border-transparent text-white shadow-lg shadow-${habit.color.split('-')[1]}-500/20 scale-110` 
                                    : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700'
                                }`}
                              >
                                {isCompleted && <Check className="w-4 h-4" />}
                              </button>
                            </div>
                          );
                        })}
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
