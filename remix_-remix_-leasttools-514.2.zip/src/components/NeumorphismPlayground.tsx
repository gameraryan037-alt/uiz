import React, { useState, useEffect } from 'react';
import { Copy, Check, RefreshCw, Box } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function NeumorphismPlayground() {
  const [size, setSize] = useState(150);
  const [radius, setRadius] = useState(30);
  const [distance, setDistance] = useState(20);
  const [intensity, setIntensity] = useState(0.15);
  const [blur, setBlur] = useState(40);
  const [color, setColor] = useState('#e0e0e0');
  const [shape, setShape] = useState<'flat' | 'concave' | 'convex' | 'pressed'>('flat');
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('neumorphism-playground');
      if (savedState) {
        setSize(savedState.size ?? 150);
        setRadius(savedState.radius ?? 30);
        setDistance(savedState.distance ?? 20);
        setIntensity(savedState.intensity ?? 0.15);
        setBlur(savedState.blur ?? 40);
        setColor(savedState.color ?? '#e0e0e0');
        setShape(savedState.shape ?? 'flat');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('neumorphism-playground', { size, radius, distance, intensity, blur, color, shape });
    }
  }, [size, radius, distance, intensity, blur, color, shape, isLoaded]);

  const hexToRgb = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return { r, g, b };
  };

  const getShadowColor = (hex: string, multiplier: number) => {
    const { r, g, b } = hexToRgb(hex);
    const nr = Math.min(255, Math.max(0, Math.round(r * multiplier)));
    const ng = Math.min(255, Math.max(0, Math.round(g * multiplier)));
    const nb = Math.min(255, Math.max(0, Math.round(b * multiplier)));
    return `rgb(${nr}, ${ng}, ${nb})`;
  };

  const lightShadow = getShadowColor(color, 1 + intensity);
  const darkShadow = getShadowColor(color, 1 - intensity);

  const getBackground = () => {
    if (shape === 'flat' || shape === 'pressed') return color;
    const { r, g, b } = hexToRgb(color);
    const light = getShadowColor(color, 1.05);
    const dark = getShadowColor(color, 0.95);
    if (shape === 'concave') return `linear-gradient(145deg, ${dark}, ${light})`;
    if (shape === 'convex') return `linear-gradient(145deg, ${light}, ${dark})`;
    return color;
  };

  const getBoxShadow = () => {
    if (shape === 'pressed') {
      return `inset ${distance}px ${distance}px ${blur}px ${darkShadow}, inset -${distance}px -${distance}px ${blur}px ${lightShadow}`;
    }
    return `${distance}px ${distance}px ${blur}px ${darkShadow}, -${distance}px -${distance}px ${blur}px ${lightShadow}`;
  };

  const cssCode = `border-radius: ${radius}px;
background: ${getBackground()};
box-shadow: ${getBoxShadow()};`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(cssCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Box className="w-5 h-5 text-indigo-500" />
          <h2>Neumorphism Playground</h2>
        </div>
        <button
          onClick={() => {
            setSize(150);
            setRadius(30);
            setDistance(20);
            setIntensity(0.15);
            setBlur(40);
            setColor('#e0e0e0');
            setShape('flat');
          }}
          className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
          title="Reset"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 grid lg:grid-cols-2 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Base Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Size ({size}px)</label>
              <input 
                type="range" min="50" max="300" step="1" 
                value={size} onChange={(e) => setSize(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Radius ({radius}px)</label>
              <input 
                type="range" min="0" max="150" step="1" 
                value={radius} onChange={(e) => setRadius(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Distance ({distance}px)</label>
              <input 
                type="range" min="0" max="50" step="1" 
                value={distance} onChange={(e) => setDistance(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Intensity ({intensity})</label>
              <input 
                type="range" min="0.01" max="0.5" step="0.01" 
                value={intensity} onChange={(e) => setIntensity(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Blur ({blur}px)</label>
              <input 
                type="range" min="0" max="100" step="1" 
                value={blur} onChange={(e) => setBlur(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Shape</label>
            <div className="grid grid-cols-4 gap-2">
              {(['flat', 'concave', 'convex', 'pressed'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setShape(s)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold capitalize transition-all border ${shape === s ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">CSS Output</label>
              <button 
                onClick={copyToClipboard}
                className="text-xs flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied!' : 'Copy CSS'}
              </button>
            </div>
            <pre className="p-4 bg-slate-950 text-indigo-300 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800">
              {cssCode}
            </pre>
          </div>
        </div>

        <div className="flex items-center justify-center p-8 rounded-2xl" style={{ backgroundColor: color }}>
          <div 
            style={{
              width: `${size}px`,
              height: `${size}px`,
              borderRadius: `${radius}px`,
              background: getBackground(),
              boxShadow: getBoxShadow(),
              transition: 'all 0.3s ease'
            }}
            className="flex items-center justify-center text-center p-4"
          >
            <span className="text-slate-400 dark:text-slate-500 font-bold text-xs uppercase tracking-widest">Preview</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
