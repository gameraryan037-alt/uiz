import React, { useState } from 'react';
import { Shield, ArrowRightLeft, Clipboard, Check, Trash2, FileCode, Type } from 'lucide-react';
import { motion } from 'motion/react';

export default function Base64Tool() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<'encode' | 'decode'>('encode');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const process = () => {
    setError(null);
    try {
      if (!input.trim()) {
        setOutput('');
        return;
      }
      if (mode === 'encode') {
        setOutput(btoa(input));
      } else {
        setOutput(atob(input));
      }
    } catch (e: any) {
      setError(mode === 'decode' ? 'Invalid Base64 string' : e.message);
      setOutput('');
    }
  };

  const copyToClipboard = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleMode = () => {
    setMode(mode === 'encode' ? 'decode' : 'encode');
    setInput(output);
    setOutput('');
    setError(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Shield className="w-5 h-5 text-blue-500" />
          <h2>Base64 Encoder / Decoder</h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => { setInput(''); setOutput(''); setError(null); }}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={copyToClipboard}
            disabled={!output}
            className="p-2 text-slate-400 hover:text-blue-500 transition-colors disabled:opacity-30"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Clipboard className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
        <div className="flex justify-center">
          <div className="flex p-1 bg-slate-200 dark:bg-slate-800 rounded-xl gap-1 w-full max-w-xs">
            <button
              onClick={() => setMode('encode')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === 'encode' 
                  ? 'bg-white dark:bg-slate-700 text-blue-500 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Encode
            </button>
            <button
              onClick={() => setMode('decode')}
              className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                mode === 'decode' 
                  ? 'bg-white dark:bg-slate-700 text-blue-500 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              Decode
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              {mode === 'encode' ? 'Text to Encode' : 'Base64 to Decode'}
            </label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={mode === 'encode' ? 'Enter plain text...' : 'Enter Base64 string...'}
              className="w-full h-48 p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Result</label>
            <div className="relative h-48">
              <textarea
                readOnly
                value={output}
                placeholder="Result will appear here..."
                className="w-full h-full p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl font-mono text-sm outline-none resize-none"
              />
              {error && (
                <div className="absolute inset-0 bg-red-500/5 backdrop-blur-[1px] flex items-center justify-center rounded-2xl">
                  <span className="text-xs font-bold text-red-500 bg-white dark:bg-slate-800 px-3 py-1.5 rounded-lg border border-red-100 dark:border-red-900 shadow-sm">
                    {error}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={process}
            className="flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold shadow-lg shadow-blue-500/20 transition-all"
          >
            {mode === 'encode' ? 'Encode to Base64' : 'Decode Base64'}
          </button>
          <button
            onClick={toggleMode}
            className="p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-400 rounded-2xl hover:text-blue-500 transition-all"
          >
            <ArrowRightLeft className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 bg-blue-50 dark:bg-blue-900/20 rounded-2xl border border-blue-100 dark:border-blue-800">
          <div className="flex items-center gap-3 mb-2">
            <FileCode className="w-4 h-4 text-blue-500" />
            <h4 className="text-xs font-bold text-blue-900 dark:text-blue-100 uppercase tracking-widest">Developer Tip</h4>
          </div>
          <p className="text-[10px] text-blue-700 dark:text-blue-300 leading-relaxed font-medium">
            Base64 encoding is commonly used to embed image data in HTML/CSS or to pass binary data in environments that only support text. 
            Note: This tool uses standard UTF-8 encoding.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
