import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, FileText, Copy, Check, Loader2, File as FileIcon, Sparkles, Save, Trash2, FileType, Image as ImageIcon, ScanLine } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError, withRetry } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

interface SavedText {
  id: string;
  sourceName: string;
  sourceType: string;
  extractedText: string;
  timestamp: number;
}

export default function TextExtractor() {
  const [file, setFile] = useState<{ data: string; name: string; type: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedText, setExtractedText] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedItems, setSavedItems] = useState<SavedText[]>([]);

  // Persistence and Global Paste Listener
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('text-extractor');
      if (savedState) {
        setFile(savedState.file || null);
        setExtractedText(savedState.extractedText || null);
        setSavedItems(savedState.savedItems || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();

    const handleGlobalPaste = (e: ClipboardEvent) => {
      // Don't intercept if user is typing in an input or textarea (unless it's an image)
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA';
      
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            processFile(blob);
            // If it's an image, we usually want to prevent default even in inputs
            // to avoid pasting the image as a string or something weird
            e.preventDefault();
            return;
          }
        } else if (items[i].type === 'text/plain' && !isInput) {
          // Only handle text paste if not in an input
          items[i].getAsString((text) => {
            setFile({
              data: text,
              name: 'Pasted Text',
              type: 'text/plain'
            });
            setExtractedText(text);
          });
        }
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('text-extractor', { file, extractedText, savedItems, filename });
    }
  }, [file, extractedText, savedItems, filename, isLoaded]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      processFile(uploadedFile);
    }
  };

  const processFile = (uploadedFile: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setFile({
        data: reader.result as string,
        name: uploadedFile.name,
        type: uploadedFile.type || 'text/plain'
      });
      setExtractedText(null);
    };
    
    if (uploadedFile.type.startsWith('image/') || uploadedFile.type === 'application/pdf') {
      reader.readAsDataURL(uploadedFile);
    } else {
      reader.readAsText(uploadedFile);
    }
  };

  const handlePaste = async () => {
    try {
      // Try modern clipboard API first
      if (navigator.clipboard && navigator.clipboard.read) {
        const clipboardItems = await navigator.clipboard.read();
        for (const item of clipboardItems) {
          for (const type of item.types) {
            if (type.startsWith('image/')) {
              const blob = await item.getType(type);
              processFile(new File([blob], 'pasted-image.png', { type: blob.type }));
              return;
            } else if (type === 'text/plain') {
              const blob = await item.getType(type);
              const text = await blob.text();
              setFile({
                data: text,
                name: 'Pasted Text',
                type: 'text/plain'
              });
              setExtractedText(text);
              return;
            }
          }
        }
      } else {
        // Fallback for browsers that don't support clipboard.read()
        const text = await navigator.clipboard.readText();
        if (text) {
          setFile({
            data: text,
            name: 'Pasted Text',
            type: 'text/plain'
          });
          setExtractedText(text);
          return;
        }
      }
      alert('No supported content found in clipboard. Please copy an image or text first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      // Final fallback
      try {
        const text = await navigator.clipboard.readText();
        if (text) {
          setFile({
            data: text,
            name: 'Pasted Text',
            type: 'text/plain'
          });
          setExtractedText(text);
          return;
        }
      } catch (innerErr) {
        console.error('Fallback clipboard read failed: ', innerErr);
      }
      alert('Failed to paste. Please ensure you have allowed clipboard access or try using Ctrl+V.');
    }
  };

  const extractText = async () => {
    if (!file) return;

    // If it's already text, just set it
    if (file.type === 'text/plain' || !file.data.startsWith('data:')) {
      setExtractedText(file.data);
      return;
    }

    setIsProcessing(true);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = file.data.split(',')[1];
      const mimeType = file.data.split(';')[0].split(':')[1];
      
      const response = await withRetry(async () => {
        return await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [
            {
              parts: [
                { text: `Extract all text from this ${file.type.includes('pdf') ? 'PDF document' : 'image'} accurately. Preserve the layout and structure as much as possible. If there is no text, say 'No text found'.` },
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                  }
                }
              ]
            }
          ]
        });
      });

      setExtractedText(response.text || "No text could be extracted.");
    } catch (error: any) {
      const userMessage = handleGeminiError(error);
      alert(userMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const saveToHistory = () => {
    if (!file || !extractedText) return;
    const newItem: SavedText = {
      id: Math.random().toString(36).substring(7),
      sourceName: file.name,
      sourceType: file.type,
      extractedText,
      timestamp: Date.now()
    };
    setSavedItems(prev => [newItem, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedItems(prev => prev.filter(item => item.id !== id));
  };

  const copyToClipboard = () => {
    if (extractedText) {
      navigator.clipboard.writeText(extractedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadText = () => {
    if (extractedText) {
      const blob = new Blob([extractedText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = getDownloadFilename(filename, 'extracted', 'txt');
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <ImageIcon className="w-10 h-10 text-blue-500" />;
    if (type === 'application/pdf') return <FileText className="w-10 h-10 text-red-500" />;
    return <FileIcon className="w-10 h-10 text-slate-500" />;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <ScanLine className="w-5 h-5 text-blue-500" />
          <h2>Text Extractor</h2>
        </div>
        <div className="flex items-center gap-2">
          {extractedText && (
            <button
              onClick={saveToHistory}
              className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
              title="Save to History"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          {file && (
            <button
              onClick={() => {
                setFile(null);
                setExtractedText(null);
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {/* Upload Section */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Upload File (Image, PDF, TXT)</label>
            <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${file ? 'border-blue-200 dark:border-blue-900/50 bg-blue-50/30 dark:bg-blue-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 bg-slate-50 dark:bg-slate-950'}`}>
              {file ? (
                <div className="w-full space-y-4">
                  <div className="flex flex-col items-center gap-3">
                    {file.type.startsWith('image/') ? (
                      <div className="relative w-full aspect-video rounded-lg overflow-hidden shadow-sm bg-white dark:bg-slate-900">
                        <img src={file.data} alt="Upload preview" className="w-full h-full object-contain" />
                      </div>
                    ) : (
                      <div className="p-6 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center gap-2">
                        {getFileIcon(file.type)}
                        <p className="text-sm font-medium text-slate-700 dark:text-slate-200 truncate max-w-[200px]">{file.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase tracking-widest">{file.type.split('/')[1] || 'file'}</p>
                      </div>
                    )}
                    <button 
                      onClick={() => setFile(null)}
                      className="text-xs text-red-500 hover:text-red-600 font-medium underline"
                    >
                      Remove File
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                    <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                      <button onClick={() => document.getElementById('file-upload-extractor')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                      {" or "}
                      <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                      {" content"}
                    </p>
                    <p className="text-[10px] text-slate-400 dark:text-slate-600 uppercase tracking-widest">Images, PDFs, or TXT</p>
                  </div>
                  <input id="file-upload-extractor" type="file" accept="image/*,application/pdf,text/plain" onChange={handleFileUpload} className="hidden" />
                </div>
              )}
            </div>

            <button
              onClick={extractText}
              disabled={!file || isProcessing}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Extracting...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  {file?.type === 'text/plain' ? 'Load Text' : 'Extract Text'}
                </>
              )}
            </button>
          </div>

          {/* Result Section */}
          <div className="space-y-4 flex flex-col">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Extracted Content</label>
                {extractedText && (
                  <div className="flex items-center gap-3">
                    <button
                      onClick={copyToClipboard}
                      className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    >
                      {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                    <button
                      onClick={downloadText}
                      className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                    >
                      <FileText className="w-3 h-3" />
                      Download
                    </button>
                  </div>
                )}
              </div>
              {extractedText && (
                <div className="relative">
                  <input
                    type="text"
                    value={filename}
                    onChange={(e) => setFilename(e.target.value)}
                    placeholder="Enter Filename (Optional)"
                    className="w-full px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 rounded-lg focus:ring-1 focus:ring-blue-500 outline-none dark:text-slate-200"
                  />
                  <span className="absolute right-3 top-1.5 text-xs text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                </div>
              )}
            </div>
            <div className="flex-1 min-h-[200px] bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 font-sans text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap overflow-y-auto custom-scrollbar transition-colors">
              {extractedText || (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 dark:text-slate-600 opacity-50">
                  <FileText className="w-12 h-12 mb-2" />
                  <p>Extracted content will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* History Section */}
        {savedItems.length > 0 && (
          <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">History</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) setSavedItems([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {savedItems.map((item) => (
                <div key={item.id} className="group relative bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border border-slate-100 dark:border-slate-800 transition-all hover:shadow-sm">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-white dark:bg-slate-800 rounded-lg">
                      {item.sourceType.startsWith('image/') ? <ImageIcon className="w-4 h-4 text-blue-500" /> : <FileText className="w-4 h-4 text-slate-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-700 dark:text-slate-200 truncate">{item.sourceName}</p>
                      <p className="text-[10px] text-slate-400">{new Date(item.timestamp).toLocaleDateString()}</p>
                    </div>
                    <button
                      onClick={() => deleteSaved(item.id)}
                      className="p-1.5 text-slate-300 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed mb-3">{item.extractedText}</p>
                  <button
                    onClick={() => {
                      setExtractedText(item.extractedText);
                      setFile({
                        data: '', // We don't store full data in history to save space
                        name: item.sourceName,
                        type: item.sourceType
                      });
                    }}
                    className="text-[10px] font-bold text-blue-600 dark:text-blue-400 hover:underline uppercase tracking-wider"
                  >
                    View Full Text
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
