import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, RefreshCw, Grid, Download, Trash2, Pencil, Eraser } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function TessellationMaker() {
  const [gridSize, setGridSize] = useState(100);
  const [color, setColor] = useState('#6366f1');
  const [lineWidth, setLineWidth] = useState(2);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<'pencil' | 'eraser'>('pencil');
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('tessellation-maker');
      if (savedState) {
        setGridSize(savedState.gridSize ?? 100);
        setColor(savedState.color ?? '#6366f1');
        setLineWidth(savedState.lineWidth ?? 2);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('tessellation-maker', { gridSize, color, lineWidth });
    }
  }, [gridSize, color, lineWidth, isLoaded]);

  const drawTessellation = () => {
    const canvas = canvasRef.current;
    const drawing = drawingRef.current;
    if (!canvas || !drawing) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const rows = Math.ceil(canvas.height / gridSize) + 1;
    const cols = Math.ceil(canvas.width / gridSize) + 1;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        ctx.save();
        ctx.translate(c * gridSize, r * gridSize);
        
        // Mirroring logic
        if (c % 2 === 1) {
          ctx.translate(gridSize, 0);
          ctx.scale(-1, 1);
        }
        if (r % 2 === 1) {
          ctx.translate(0, gridSize);
          ctx.scale(1, -1);
        }

        ctx.drawImage(drawing, 0, 0, gridSize, gridSize);
        ctx.restore();
      }
    }
  };

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const drawing = drawingRef.current;
    if (drawing) {
      const ctx = drawing.getContext('2d');
      ctx?.beginPath();
    }
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const drawing = drawingRef.current;
    if (!drawing) return;
    const ctx = drawing.getContext('2d');
    if (!ctx) return;

    const rect = drawing.getBoundingClientRect();
    const x = (('touches' in e) ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = (('touches' in e) ? e.touches[0].clientY : e.clientY) - rect.top;

    // Scale coordinates to internal canvas size
    const scaleX = drawing.width / rect.width;
    const scaleY = drawing.height / rect.height;

    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.strokeStyle = tool === 'eraser' ? '#ffffff' : color;
    
    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
    } else {
      ctx.globalCompositeOperation = 'source-over';
    }

    ctx.lineTo(x * scaleX, y * scaleY);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x * scaleX, y * scaleY);

    drawTessellation();
  };

  const clearCanvas = () => {
    const drawing = drawingRef.current;
    const canvas = canvasRef.current;
    if (!drawing || !canvas) return;
    const dCtx = drawing.getContext('2d');
    const cCtx = canvas.getContext('2d');
    dCtx?.clearRect(0, 0, drawing.width, drawing.height);
    cCtx?.clearRect(0, 0, canvas.width, canvas.height);
  };

  const downloadCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `tessellation.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  useEffect(() => {
    drawTessellation();
  }, [gridSize]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Grid className="w-5 h-5 text-indigo-500" />
          <h2>Tessellation Maker</h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={clearCanvas}
            className="p-2 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
            title="Clear"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={downloadCanvas}
            className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-6 grid lg:grid-cols-3 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Grid Size ({gridSize}px)</label>
              <input 
                type="range" min="50" max="200" step="1" 
                value={gridSize} onChange={(e) => setGridSize(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Line Width ({lineWidth}px)</label>
              <input 
                type="range" min="1" max="20" step="1" 
                value={lineWidth} onChange={(e) => setLineWidth(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Brush Color</label>
              <input 
                type="color" 
                value={color} onChange={(e) => setColor(e.target.value)}
                className="w-12 h-8 rounded cursor-pointer bg-transparent"
              />
            </div>
            <div className="flex gap-2">
              <button 
                onClick={() => setTool('pencil')}
                className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 border transition-all ${tool === 'pencil' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
              >
                <Pencil className="w-4 h-4" />
                Pencil
              </button>
              <button 
                onClick={() => setTool('eraser')}
                className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-2 border transition-all ${tool === 'eraser' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'}`}
              >
                <Eraser className="w-4 h-4" />
                Eraser
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Draw Here (One Tile)</label>
            <div className="bg-white dark:bg-slate-950 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 aspect-square overflow-hidden cursor-crosshair">
              <canvas 
                ref={drawingRef} 
                width={gridSize} 
                height={gridSize} 
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="w-full h-full"
              />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden">
          <canvas 
            ref={canvasRef} 
            width={800} 
            height={600} 
            className="w-full h-full object-contain drop-shadow-lg"
          />
        </div>
      </div>
    </motion.div>
  );
}
