import React, { useState, useMemo } from 'react';
import { Maximize2, Smartphone, Monitor, Tablet, Image as ImageIcon, Copy, Check } from 'lucide-react';

interface Ratio {
  name: string;
  ratio: string;
  w: number;
  h: number;
  icon: React.ElementType;
}

const COMMON_RATIOS: Ratio[] = [
  { name: 'Square', ratio: '1:1', w: 1, h: 1, icon: Maximize2 },
  { name: 'Instagram Portrait', ratio: '4:5', w: 4, h: 5, icon: Smartphone },
  { name: 'Classic Photo', ratio: '3:2', w: 3, h: 2, icon: ImageIcon },
  { name: 'Standard Monitor', ratio: '4:3', w: 4, h: 3, icon: Monitor },
  { name: 'Widescreen', ratio: '16:9', w: 16, h: 9, icon: Monitor },
  { name: 'TikTok/Reels', ratio: '9:16', w: 9, h: 16, icon: Smartphone },
  { name: 'Cinematic', ratio: '21:9', w: 21, h: 9, icon: Monitor },
  { name: 'Golden Ratio', ratio: '1.618:1', w: 1.618, h: 1, icon: Tablet },
];

export default function AspectRatioVisualizer() {
  const [width, setWidth] = useState<number>(1920);
  const [height, setHeight] = useState<number>(1080);
  const [copied, setCopied] = useState(false);

  const gcd = (a: number, b: number): number => {
    return b === 0 ? a : gcd(b, a % b);
  };

  const currentRatio = useMemo(() => {
    if (!width || !height) return '0:0';
    const common = gcd(width, height);
    return `${width / common}:${height / common}`;
  }, [width, height]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl">
          <Maximize2 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Aspect Ratio Visualizer</h2>
          <p className="text-slate-500 dark:text-slate-400">Compare dimensions and visualize ratios for social media and web.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Width (px)</label>
              <input
                type="number"
                value={width}
                onChange={(e) => setWidth(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Height (px)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full px-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-800/30">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-semibold text-indigo-900 dark:text-indigo-300 uppercase tracking-wider">Current Ratio</span>
              <button
                onClick={() => copyToClipboard(currentRatio)}
                className="p-1.5 hover:bg-indigo-100 dark:hover:bg-indigo-800 rounded-lg transition-colors"
                title="Copy ratio"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
              </button>
            </div>
            <div className="text-3xl font-black text-indigo-600 dark:text-indigo-400 tracking-tighter">
              {currentRatio}
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-widest opacity-50">Common Ratios</h3>
            <div className="grid grid-cols-2 gap-2">
              {COMMON_RATIOS.map((r) => (
                <button
                  key={r.name}
                  onClick={() => {
                    const base = 1080;
                    setWidth(Math.round(base * r.w / r.h));
                    setHeight(base);
                  }}
                  className="flex items-center gap-3 p-3 text-left bg-slate-50 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 border border-slate-200 dark:border-slate-700 hover:border-indigo-200 dark:hover:border-indigo-800 rounded-xl transition-all group"
                >
                  <r.icon className="w-4 h-4 text-slate-400 group-hover:text-indigo-500" />
                  <div>
                    <div className="text-xs font-bold text-slate-900 dark:text-white">{r.name}</div>
                    <div className="text-[10px] text-slate-500">{r.ratio}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 min-h-[400px]">
          <div className="relative w-full h-full flex items-center justify-center">
            <div 
              className="bg-indigo-500/10 border-2 border-indigo-500 rounded-lg shadow-2xl shadow-indigo-500/20 transition-all duration-500 ease-out flex items-center justify-center overflow-hidden"
              style={{
                aspectRatio: `${width}/${height}`,
                maxWidth: '100%',
                maxHeight: '100%',
                width: width >= height ? '100%' : 'auto',
                height: height > width ? '100%' : 'auto',
              }}
            >
              <div className="text-center p-4">
                <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest mb-1">Preview</div>
                <div className="text-lg font-black text-indigo-900 dark:text-indigo-100">{width} × {height}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: 'Instagram Square', w: 1080, h: 1080 },
          { label: 'YouTube Widescreen', w: 1920, h: 1080 },
          { label: 'TikTok/Reels', w: 1080, h: 1920 },
        ].map((preset) => (
          <button
            key={preset.label}
            onClick={() => {
              setWidth(preset.w);
              setHeight(preset.h);
            }}
            className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:border-indigo-500 transition-all text-left"
          >
            <div className="text-xs font-bold text-slate-500 uppercase mb-1">{preset.label}</div>
            <div className="text-sm font-bold text-slate-900 dark:text-white">{preset.w} × {preset.h}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
