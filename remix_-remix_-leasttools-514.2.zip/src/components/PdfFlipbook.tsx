import React, { useState, useRef, useEffect } from 'react';
import { Book, ChevronLeft, ChevronRight, Upload, Download, Maximize2, Minimize2, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as pdfjsLib from 'pdfjs-dist';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';

// Set worker path for PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

export default function PdfFlipbook() {
  const [pdf, setPdf] = useState<any>(null);
  const [pages, setPages] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setPages([]);
    setCurrentPage(0);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdfDoc = await loadingTask.promise;
      setPdf(pdfDoc);

      const pageImages: string[] = [];
      for (let i = 1; i <= pdfDoc.numPages; i++) {
        const page = await pdfDoc.getPage(i);
        const viewport = page.getViewport({ scale: 1.5 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        await page.render({ canvasContext: context!, viewport, canvas }).promise;
        pageImages.push(canvas.toDataURL('image/jpeg', 0.8));
      }
      setPages(pageImages);
    } catch (error) {
      console.error('Error loading PDF:', error);
      alert('Failed to load PDF. Please try another file.');
    } finally {
      setIsLoading(false);
    }
  };

  const nextPage = () => {
    if (currentPage < pages.length - 1) {
      setCurrentPage(prev => prev + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setCurrentPage(prev => prev - 1);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-100 dark:bg-indigo-900/30 rounded-2xl">
            <Book className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Interactive PDF Flipbook</h2>
            <p className="text-slate-500 dark:text-slate-400">Convert static PDFs into immersive 3D interactive experiences.</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {pages.length > 0 && (
            <button
              onClick={toggleFullscreen}
              className="p-2 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
          )}
          <label className="cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-lg shadow-indigo-200 dark:shadow-none">
            <Upload className="w-4 h-4" />
            {pages.length > 0 ? 'Change PDF' : 'Upload PDF'}
            <input type="file" accept=".pdf" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      </div>

      <div 
        ref={containerRef}
        className={`relative bg-slate-100 dark:bg-slate-950 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-inner min-h-[600px] flex flex-col items-center justify-center ${isFullscreen ? 'p-0 rounded-none border-none' : 'p-12'}`}
      >
        {isLoading ? (
          <div className="flex flex-col items-center gap-4">
            <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-slate-500 font-bold animate-pulse">Rendering Pages...</p>
          </div>
        ) : pages.length > 0 ? (
          <>
            <div className="relative w-full max-w-4xl aspect-[3/2] perspective-2000 flex items-center justify-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentPage}
                  initial={{ rotateY: 90, opacity: 0 }}
                  animate={{ rotateY: 0, opacity: 1 }}
                  exit={{ rotateY: -90, opacity: 0 }}
                  transition={{ duration: 0.6, ease: "easeInOut" }}
                  className="relative w-full h-full flex items-center justify-center"
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  <div className="flex shadow-2xl rounded-lg overflow-hidden bg-white dark:bg-slate-900">
                    {/* Left Page */}
                    <div className="w-1/2 border-r border-slate-200 dark:border-slate-800">
                      {currentPage % 2 === 0 ? (
                        currentPage > 0 ? (
                          <img src={pages[currentPage - 1]} alt="Left Page" className="w-full h-full object-contain" />
                        ) : (
                          <div className="w-full h-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-300 font-bold italic">Cover</div>
                        )
                      ) : (
                        <img src={pages[currentPage]} alt="Left Page" className="w-full h-full object-contain" />
                      )}
                    </div>
                    {/* Right Page */}
                    <div className="w-1/2">
                      {currentPage % 2 === 0 ? (
                        <img src={pages[currentPage]} alt="Right Page" className="w-full h-full object-contain" />
                      ) : (
                        currentPage < pages.length - 1 ? (
                          <img src={pages[currentPage + 1]} alt="Right Page" className="w-full h-full object-contain" />
                        ) : (
                          <div className="w-full h-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-300 font-bold italic">End</div>
                        )
                      )}
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Navigation Controls */}
              <button
                onClick={prevPage}
                disabled={currentPage === 0}
                className="absolute left-4 top-1/2 -translate-y-1/2 p-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-full shadow-xl text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30 transition-all z-10"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={nextPage}
                disabled={currentPage >= pages.length - 1}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-full shadow-xl text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800 disabled:opacity-30 transition-all z-10"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>

            {/* Progress Bar */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3">
              <div className="flex items-center gap-4">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Page {currentPage + 1} of {pages.length}</span>
              </div>
              <div className="w-64 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-indigo-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentPage + 1) / pages.length) * 100}%` }}
                />
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center text-center p-12">
            <div className="w-20 h-20 bg-white dark:bg-slate-900 rounded-3xl shadow-xl flex items-center justify-center mb-6">
              <Book className="w-10 h-10 text-indigo-500" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">No Flipbook Loaded</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-xs mt-2">
              Upload a PDF document to transform it into an interactive 3D flipbook.
            </p>
          </div>
        )}
      </div>

      {pages.length > 0 && (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <Share2 className="w-5 h-5 text-indigo-500" />
              <h4 className="font-bold text-slate-900 dark:text-white">Embed Flipbook</h4>
            </div>
            <p className="text-sm text-slate-500 mb-4">Get the code to embed this interactive viewer on your own website.</p>
            <button className="w-full py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs hover:bg-slate-200 transition-all">
              Copy Embed Code
            </button>
          </div>
          
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <Download className="w-5 h-5 text-emerald-500" />
              <h4 className="font-bold text-slate-900 dark:text-white">Export Images</h4>
            </div>
            <p className="text-sm text-slate-500 mb-4">Download all rendered pages as high-quality JPEG images for offline use.</p>
            <button className="w-full py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs hover:bg-slate-200 transition-all">
              Download ZIP
            </button>
          </div>

          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <Maximize2 className="w-5 h-5 text-amber-500" />
              <h4 className="font-bold text-slate-900 dark:text-white">Presentation Mode</h4>
            </div>
            <p className="text-sm text-slate-500 mb-4">Enter a distraction-free mode perfect for sharing your document in meetings.</p>
            <button onClick={toggleFullscreen} className="w-full py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl font-bold text-xs hover:bg-slate-200 transition-all">
              Start Presentation
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
