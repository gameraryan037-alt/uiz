import React, { useState, useEffect } from 'react';
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { Copy, Check, AlertCircle, Sparkles, Loader2, Languages, ArrowRight, Download, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { cleanAIJsonResponse, getGeminiApiKey, handleGeminiError } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

interface Mistake {
  original: string;
  corrected: string;
  explanation: string;
}

interface GrammarResult {
  correctedText: string;
  mistakes: Mistake[];
  totalMistakes: number;
}

export default function GrammarCorrection() {
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<GrammarResult | null>(null);
  const [filename, setFilename] = useState('');
  const [copied, setCopied] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('grammar-correction');
      if (savedState) {
        setInputText(savedState.inputText || '');
        setResult(savedState.result || null);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('grammar-correction', { inputText, result, filename });
    }
  }, [inputText, result, filename, isLoaded]);

  const handleCorrect = async () => {
    if (!inputText.trim()) return;
    setIsProcessing(true);
    setResult(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      
      const prompt = `Correct the grammar of this text. 
      CRITICAL: The output language MUST be the same as the input language (English, Hindi, or Hinglish). 
      If the input contains multiple languages, use the majority language for the correction.
      Preserve all original newlines and paragraph breaks in the "correctedText".
      Return JSON ONLY:
      {
        "correctedText": "full text with preserved newlines",
        "mistakes": [{"original": "...", "corrected": "...", "explanation": "..."}],
        "totalMistakes": number
      }
      
      Text: "${inputText.replace(/"/g, '\\"')}"`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0,
          seed: 42
        }
      });

      const data = cleanAIJsonResponse(response) as GrammarResult;
      setResult(data);
    } catch (error: any) {
      const userMessage = handleGeminiError(error);
      alert(userMessage);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      handleCorrect();
    }
  };

  const copyToClipboard = () => {
    if (result?.correctedText) {
      navigator.clipboard.writeText(result.correctedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const downloadText = () => {
    if (result?.correctedText) {
      const blob = new Blob([result.correctedText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = getDownloadFilename(filename, 'grammar', 'txt');
      link.click();
      URL.revokeObjectURL(url);
    }
  };

  const clearAll = () => {
    setInputText('');
    setResult(null);
    setFilename('');
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Languages className="w-5 h-5 text-pink-500" />
          <h2>Grammar Correction</h2>
        </div>
        <div className="flex items-center gap-2">
          {(inputText || result) && (
            <button
              onClick={clearAll}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Clear all"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
            Auto-Detect Language
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 relative">
        {/* Input Section */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Input Text</label>
          <div className="relative">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Enter text to correct (English, Hindi, or Hinglish)..."
              className="w-full min-h-[150px] p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 dark:focus:ring-pink-900/30 outline-none resize-y font-sans text-slate-700 dark:text-slate-200 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
            <button
              onClick={handleCorrect}
              disabled={isProcessing || !inputText.trim()}
              className="absolute bottom-4 right-4 px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white rounded-lg text-sm font-medium flex items-center gap-2 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Correcting...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Fix Grammar
                </>
              )}
            </button>
          </div>
        </div>

        {/* Results Section */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Stats */}
              <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-800 w-fit">
                <AlertCircle className="w-4 h-4 text-orange-500" />
                <span>Found <span className="font-bold text-slate-900 dark:text-white">{result.totalMistakes}</span> mistakes</span>
              </div>

              {/* Output Box */}
              <div className="space-y-2">
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Corrected Output</label>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={copyToClipboard}
                        className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-pink-600 dark:hover:text-pink-400 transition-colors"
                      >
                        {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        {copied ? 'Copied!' : 'Copy'}
                      </button>
                      <button
                        onClick={downloadText}
                        className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-pink-600 dark:hover:text-pink-400 transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        Download
                      </button>
                    </div>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-full px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded-lg focus:ring-1 focus:ring-pink-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-3 top-1.5 text-xs text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
                  </div>
                </div>
                <div className="w-full min-h-[120px] max-h-[300px] overflow-y-auto p-4 rounded-xl border border-green-200 dark:border-green-900/30 bg-green-50/30 dark:bg-green-900/10 text-slate-800 dark:text-slate-200 font-medium leading-relaxed whitespace-pre-wrap shadow-inner custom-scrollbar">
                  {result.correctedText}
                </div>
              </div>

              {/* Mistakes Breakdown */}
              {result.mistakes.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Mistakes Breakdown</h3>
                  <div className="grid gap-3">
                    {result.mistakes.map((mistake, index) => (
                      <div key={index} className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center gap-4 transition-colors">
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2 text-sm">
                            <span className="text-red-500 line-through decoration-red-500/50">{mistake.original}</span>
                            <ArrowRight className="w-3 h-3 text-slate-300 dark:text-slate-600" />
                            <span className="text-green-600 dark:text-green-400 font-medium">{mistake.corrected}</span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{mistake.explanation}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
