import React, { useState, useEffect } from 'react';
import { Type, AlignLeft, Hash, Clock, Trash2, Settings, Check, Download, FileDigit } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getDownloadFilename } from '../utils/filename';

export default function WordCounter() {
  const [text, setText] = useState('');
  const [includeSpacesSymbols, setIncludeSpacesSymbols] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('word-counter');
      if (savedState) {
        setText(savedState.text || '');
        setIncludeSpacesSymbols(savedState.includeSpacesSymbols ?? true);
        setIncludeNumbers(savedState.includeNumbers ?? true);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('word-counter', { text, includeSpacesSymbols, includeNumbers, filename });
    }
  }, [text, includeSpacesSymbols, includeNumbers, filename, isLoaded]);

  const clearText = () => {
    setText('');
  };

  const calculateStats = () => {
    const trimmed = text.trim();
    if (!trimmed) return { words: 0, characters: 0, paragraphs: 0, readingTime: 0 };

    // Words Calculation
    let wordsArray = trimmed.split(/\s+/);
    
    if (!includeNumbers) {
      // Exclude words that are purely numeric (e.g., "123", "4.5")
      wordsArray = wordsArray.filter(w => !/^\d+(\.\d+)?$/.test(w.replace(/,/g, '')));
    }
    
    const words = wordsArray.length;

    // Characters Calculation
    let characters = text.length;
    if (!includeSpacesSymbols) {
      // Remove spaces and non-alphanumeric symbols (keep letters and numbers)
      characters = text.replace(/[^a-zA-Z0-9]/g, '').length;
    }

    const paragraphs = text.split(/\n+/).filter(p => p.trim() !== '').length;
    const readingTime = Math.ceil(words / 200);

    // Top 5 Words
    const wordFreq: Record<string, number> = {};
    wordsArray.forEach(w => {
      const word = w.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (word && word.length > 1) {
        wordFreq[word] = (wordFreq[word] || 0) + 1;
      }
    });
    const topWords = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    return { words, characters, paragraphs, readingTime, topWords };
  };

  const stats = calculateStats();

  const downloadStats = () => {
    if (!text) return;
    const content = `Word Counter Statistics\n` +
      `=======================\n\n` +
      `Words: ${stats.words}\n` +
      `Characters: ${stats.characters}\n` +
      `Paragraphs: ${stats.paragraphs}\n` +
      `Estimated Reading Time: ${stats.readingTime} minute(s)\n\n` +
      `Top 5 Words:\n` +
      `${stats.topWords.map(([w, c]) => `- ${w}: ${c}`).join('\n')}\n\n` +
      `Original Text:\n` +
      `--------------\n` +
      `${text}`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = getDownloadFilename(filename, 'word-count', 'txt');
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      (e.target as HTMLElement).blur();
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileDigit className="w-5 h-5 text-orange-500" />
          <h2>Word Counter</h2>
        </div>
        <div className="flex items-center gap-2">
          {text && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  value={filename}
                  onChange={(e) => setFilename(e.target.value)}
                  placeholder="Enter Filename (Optional)"
                  className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-orange-500 outline-none text-slate-700 dark:text-slate-200"
                />
                <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.txt</span>
              </div>
              <button
                onClick={downloadStats}
                className="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                title="Download Stats"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={clearText}
                className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                title="Clear text"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
      
      <div className="p-4 flex-1 flex flex-col gap-4">
        {/* Settings Toggles */}
        <div className="flex flex-wrap gap-4 text-sm text-slate-600 dark:text-slate-400 bg-slate-200/50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 transition-colors">
          <label className="flex items-center gap-2 cursor-pointer select-none hover:text-slate-900 dark:hover:text-white transition-colors">
            <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${includeSpacesSymbols ? 'bg-orange-500 border-orange-500' : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-700'}`}>
              {includeSpacesSymbols && <Check className="w-3 h-3 text-white" />}
            </div>
            <input 
              type="checkbox" 
              checked={includeSpacesSymbols} 
              onChange={(e) => setIncludeSpacesSymbols(e.target.checked)} 
              className="hidden" 
            />
            <span>Count Spaces & Symbols</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer select-none hover:text-slate-900 dark:hover:text-white transition-colors">
            <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${includeNumbers ? 'bg-orange-500 border-orange-500' : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-700'}`}>
              {includeNumbers && <Check className="w-3 h-3 text-white" />}
            </div>
            <input 
              type="checkbox" 
              checked={includeNumbers} 
              onChange={(e) => setIncludeNumbers(e.target.checked)} 
              className="hidden" 
            />
            <span>Count Numbers</span>
          </label>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-slate-200/50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 transition-colors">
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 mb-1">
              <Type className="w-3 h-3" />
              <span className="text-xs font-medium uppercase tracking-wider">Words</span>
            </div>
            <p className="text-2xl font-semibold text-slate-700 dark:text-slate-200">{stats.words}</p>
          </div>
          <div className="bg-slate-200/50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 transition-colors">
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 mb-1">
              <Hash className="w-3 h-3" />
              <span className="text-xs font-medium uppercase tracking-wider">Chars</span>
            </div>
            <p className="text-2xl font-semibold text-slate-700 dark:text-slate-200">{stats.characters}</p>
          </div>
          <div className="bg-slate-200/50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 transition-colors">
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 mb-1">
              <AlignLeft className="w-3 h-3" />
              <span className="text-xs font-medium uppercase tracking-wider">Paragraphs</span>
            </div>
            <p className="text-2xl font-semibold text-slate-700 dark:text-slate-200">{stats.paragraphs}</p>
          </div>
          <div className="bg-slate-200/50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800 transition-colors">
            <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 mb-1">
              <Clock className="w-3 h-3" />
              <span className="text-xs font-medium uppercase tracking-wider">Read Time</span>
            </div>
            <p className="text-2xl font-semibold text-slate-700 dark:text-slate-200">{stats.readingTime}m</p>
          </div>
        </div>

        {stats.topWords.length > 0 && (
          <div className="bg-slate-200/30 dark:bg-slate-800/30 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Top 5 Most Used Words</h3>
            <div className="flex flex-wrap gap-2">
              {stats.topWords.map(([word, count]) => (
                <div key={word} className="px-3 py-1.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200">{word}</span>
                  <span className="text-[10px] font-bold text-orange-500 bg-orange-50 dark:bg-orange-900/20 px-1.5 py-0.5 rounded">{count}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type or paste your text here to analyze..."
          className="flex-1 w-full min-h-[200px] p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 dark:focus:ring-orange-900/30 outline-none resize-none font-sans text-sm text-slate-700 dark:text-slate-200 transition-all leading-relaxed placeholder:text-slate-400 dark:placeholder:text-slate-600"
        />
      </div>
    </motion.div>
  );
}
