import React, { useState, useEffect, useRef } from 'react';
import { Copy, Check, RefreshCw, Zap, Download, Trash2, MousePointer2 } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
}

export default function ParticlePhysicsSandbox() {
  const [particleCount, setParticleCount] = useState(100);
  const [gravity, setGravity] = useState(0.1);
  const [friction, setFriction] = useState(0.99);
  const [bounce, setBounce] = useState(0.7);
  const [interaction, setInteraction] = useState<'attract' | 'repel' | 'none'>('attract');
  const [isLoaded, setIsLoaded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: 0, y: 0, active: false });
  const animationRef = useRef<number>(0);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('particle-physics-sandbox');
      if (savedState) {
        setParticleCount(savedState.particleCount ?? 100);
        setGravity(savedState.gravity ?? 0.1);
        setFriction(savedState.friction ?? 0.99);
        setBounce(savedState.bounce ?? 0.7);
        setInteraction(savedState.interaction ?? 'attract');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('particle-physics-sandbox', { particleCount, gravity, friction, bounce, interaction });
    }
  }, [particleCount, gravity, friction, bounce, interaction, isLoaded]);

  const initParticles = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const particles: Particle[] = [];
    const colors = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 10,
        vy: (Math.random() - 0.5) * 10,
        size: Math.random() * 5 + 2,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }
    particlesRef.current = particles;
  };

  const update = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    particlesRef.current.forEach(p => {
      // Apply gravity
      p.vy += gravity;

      // Apply friction
      p.vx *= friction;
      p.vy *= friction;

      // Mouse interaction
      if (mouseRef.current.active && interaction !== 'none') {
        const dx = mouseRef.current.x - p.x;
        const dy = mouseRef.current.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const force = interaction === 'attract' ? 0.5 : -0.5;
        
        if (dist < 200) {
          p.vx += (dx / dist) * force;
          p.vy += (dy / dist) * force;
        }
      }

      // Update position
      p.x += p.vx;
      p.y += p.vy;

      // Boundary check
      if (p.x + p.size > canvas.width) {
        p.x = canvas.width - p.size;
        p.vx *= -bounce;
      } else if (p.x - p.size < 0) {
        p.x = p.size;
        p.vx *= -bounce;
      }

      if (p.y + p.size > canvas.height) {
        p.y = canvas.height - p.size;
        p.vy *= -bounce;
      } else if (p.y - p.size < 0) {
        p.y = p.size;
        p.vy *= -bounce;
      }

      // Draw
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.fill();
    });

    animationRef.current = requestAnimationFrame(update);
  };

  useEffect(() => {
    initParticles();
    animationRef.current = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animationRef.current);
  }, [particleCount, interaction]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    mouseRef.current = {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height),
      active: true
    };
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Zap className="w-5 h-5 text-indigo-500" />
          <h2>Particle Physics Sandbox</h2>
        </div>
        <button
          onClick={initParticles}
          className="p-2 text-slate-400 hover:text-indigo-500 rounded-lg transition-colors"
          title="Reset Particles"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="p-6 grid lg:grid-cols-3 gap-8 overflow-y-auto custom-scrollbar">
        <div className="space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Particle Count ({particleCount})</label>
              <input 
                type="range" min="10" max="500" step="10" 
                value={particleCount} onChange={(e) => setParticleCount(parseInt(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Gravity ({gravity})</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={gravity} onChange={(e) => setGravity(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Friction ({friction})</label>
              <input 
                type="range" min="0.9" max="1" step="0.001" 
                value={friction} onChange={(e) => setFriction(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Bounce ({bounce})</label>
              <input 
                type="range" min="0" max="1" step="0.01" 
                value={bounce} onChange={(e) => setBounce(parseFloat(e.target.value))}
                className="w-1/2 accent-indigo-500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Mouse Interaction</label>
            <div className="grid grid-cols-3 gap-2">
              {(['attract', 'repel', 'none'] as const).map((i) => (
                <button
                  key={i}
                  onClick={() => setInteraction(i)}
                  className={`py-2 px-3 rounded-lg text-xs font-bold capitalize transition-all border ${interaction === i ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-indigo-500'}`}
                >
                  {i}
                </button>
              ))}
            </div>
          </div>

          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-900/30 rounded-xl space-y-2">
            <h3 className="text-xs font-bold text-indigo-800 dark:text-indigo-300 uppercase tracking-wider">Instructions</h3>
            <p className="text-[10px] text-indigo-700 dark:text-indigo-400 leading-relaxed">
              Move your mouse over the canvas to interact with the particles. 
              Adjust the physics parameters to see how they affect the particle behavior.
            </p>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 min-h-[400px] relative overflow-hidden cursor-none">
          <canvas 
            ref={canvasRef} 
            width={800} 
            height={600} 
            onMouseMove={handleMouseMove}
            onMouseLeave={() => mouseRef.current.active = false}
            className="w-full h-full object-contain"
          />
          {mouseRef.current.active && (
            <div 
              className="absolute pointer-events-none w-8 h-8 border-2 border-indigo-500 rounded-full flex items-center justify-center bg-indigo-500/10"
              style={{ 
                left: `${(mouseRef.current.x / 800) * 100}%`, 
                top: `${(mouseRef.current.y / 600) * 100}%`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              <MousePointer2 className="w-4 h-4 text-indigo-500" />
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
