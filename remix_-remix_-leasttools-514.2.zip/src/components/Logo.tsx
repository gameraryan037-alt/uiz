import React from 'react';

export const Logo = ({ className = "w-8 h-8" }: { className?: string }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4F46E5" />
          <stop offset="100%" stopColor="#7C3AED" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      
      {/* Background Shape */}
      <rect 
        x="10" 
        y="10" 
        width="80" 
        height="80" 
        rx="24" 
        fill="url(#logo-gradient)" 
        className="drop-shadow-lg"
      />
      
      {/* Abstract Tool/L Shape */}
      <path 
        d="M35 30V70H65" 
        stroke="white" 
        strokeWidth="12" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        opacity="0.9"
      />
      
      {/* Accent Dot */}
      <circle 
        cx="65" 
        cy="30" 
        r="6" 
        fill="white"
        className="animate-pulse"
      />
      
      {/* Inner Detail */}
      <path 
        d="M45 45L55 55M55 45L45 55" 
        stroke="white" 
        strokeWidth="4" 
        strokeLinecap="round"
        opacity="0.5"
      />
    </svg>
  );
};
