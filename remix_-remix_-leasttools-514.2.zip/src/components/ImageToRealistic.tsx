import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Upload, Download, Check, Loader2, Image as ImageIcon, Sparkles, Trash2, AlertCircle, Wand2, Save } from 'lucide-react';
import { motion } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';
import { getGeminiApiKey, handleGeminiError, withRetry } from '../utils/ai';
import { getDownloadFilename } from '../utils/filename';

type Style = 'Realistic' | 'Drawing' | 'Sketch' | 'Anime';

interface SavedRealistic {
  id: string;
  image: string;
  resultImage: string;
  style: Style;
  timestamp: number;
}

export default function ImageToRealistic() {
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>(null);
  const [style, setStyle] = useState<Style>('Realistic');
  const [errorDetails, setErrorDetails] = useState<string | null>(null);
  const [filename, setFilename] = useState('');
  const [isLoaded, setIsLoaded] = useState(false);
  const [savedItems, setSavedItems] = useState<SavedRealistic[]>([]);

  // Persistence
  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('image-to-realistic');
      if (savedState) {
        setImage(savedState.image || null);
        setResultImage(savedState.resultImage || null);
        setStyle(savedState.style || 'Realistic');
        setSavedItems(savedState.savedItems || []);
        setFilename(savedState.filename || '');
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('image-to-realistic', { image, resultImage, style, savedItems, filename });
    }
  }, [image, resultImage, style, savedItems, filename, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResultImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaste = async () => {
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith('image/')) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onloadend = () => {
              setImage(reader.result as string);
              setResultImage(null);
            };
            reader.readAsDataURL(blob);
            return;
          }
        }
      }
      alert('No image found in clipboard. Please copy an image first.');
    } catch (err) {
      console.error('Failed to read clipboard: ', err);
      alert('Failed to paste image. Please ensure you have allowed clipboard access.');
    }
  };

  const downloadImage = () => {
    if (resultImage) {
      const link = document.createElement('a');
      link.href = resultImage;
      link.download = getDownloadFilename(filename, 'transformed', 'png');
      link.click();
    }
  };
  const convertToRealistic = async () => {
    if (!image) return;
    setIsProcessing(true);
    setErrorDetails(null);

    try {
      const apiKey = getGeminiApiKey();
      const ai = new GoogleGenAI({ apiKey });
      const base64Data = image.split(',')[1];
      const mimeType = image.split(';')[0].split(':')[1];
      
      let prompt = `Transform this image into a highly ${style.toLowerCase()} version. 
      Maintain the exact composition, pose, and features of the subject. 
      Use professional lighting, textures, and details.
      IMPORTANT: Remove any paper lines, grid lines, notebook lines, or paper texture artifacts. Ensure the background is clean and professional.`;

      if (style === 'Realistic') {
        prompt += ` If it's a drawing, sketch, or anime, make it look like a real-life high-resolution photograph.`;
      } else if (style === 'Drawing') {
        prompt += ` Make it look like a professional artistic drawing with vibrant colors.`;
      } else if (style === 'Sketch') {
        prompt += ` Make it look like a high-quality black and white pencil sketch. Do not use any colors.`;
      } else if (style === 'Anime') {
        prompt += ` Make it look like high-quality modern anime art style.`;
      }

      // Create a timeout promise
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Request timed out. Please check your internet connection or API key.")), 60000)
      );

      const response = await withRetry(async () => {
        return await Promise.race([
          ai.models.generateContent({
            model: "gemini-2.5-flash-image",
            contents: {
              parts: [
                {
                  inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                  }
                },
                { text: prompt }
              ]
            }
          }),
          timeoutPromise
        ]);
      }) as any;

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            const base64EncodeString: string = part.inlineData.data;
            setResultImage(`data:image/png;base64,${base64EncodeString}`);
            break;
          }
        }
      } else {
        throw new Error("The AI did not return an image. It might have been blocked by safety filters.");
      }
    } catch (error: any) {
      setErrorDetails(handleGeminiError(error));
    } finally {
      setIsProcessing(false);
    }
  };

  const saveToHistory = () => {
    if (!image || !resultImage) return;
    const newItem: SavedRealistic = {
      id: Math.random().toString(36).substring(7),
      image,
      resultImage,
      style,
      timestamp: Date.now()
    };
    setSavedItems(prev => [newItem, ...prev]);
  };

  const deleteSaved = (id: string) => {
    setSavedItems(prev => prev.filter(item => item.id !== id));
  };

  const styles: Style[] = ['Realistic', 'Drawing', 'Sketch', 'Anime'];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Wand2 className="w-5 h-5 text-indigo-500" />
          <h2>Image Style Changer</h2>
        </div>
        <div className="flex items-center gap-2">
          {resultImage && (
            <button
              onClick={saveToHistory}
              className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
              title="Save to History"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
          {(image || resultImage) && (
            <button
              onClick={() => {
                setImage(null);
                setResultImage(null);
              }}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6 overflow-y-auto custom-scrollbar">
        {errorDetails && (
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/30 rounded-xl p-4 flex items-center gap-3 text-red-700 dark:text-red-400 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{errorDetails}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Source Image</label>
            <div className={`relative border-2 border-dashed rounded-2xl transition-all flex flex-col items-center justify-center p-8 text-center ${image ? 'border-indigo-200 dark:border-indigo-900/50 bg-indigo-50/30 dark:bg-indigo-900/10' : 'border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 bg-slate-50 dark:bg-slate-950'}`}>
              {image ? (
                <>
                  <img src={image} alt="Source" className="max-h-64 object-contain rounded-lg shadow-sm" />
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-slate-400 dark:text-slate-600" />
                    <p className="text-sm font-medium text-slate-400 dark:text-slate-500">
                      <button onClick={() => document.getElementById('file-upload')?.click()} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Upload</button>
                      {" or "}
                      <button onClick={handlePaste} className="text-blue-600 dark:text-blue-400 underline hover:text-blue-700 dark:hover:text-blue-300">Paste</button>
                      {" an image"}
                    </p>
                  </div>
                  <input id="file-upload" type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Target Style</label>
              <div className="flex flex-wrap gap-2">
                {styles.map(s => (
                  <button
                    key={s}
                    onClick={() => setStyle(s)}
                    className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${style === s ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={convertToRealistic}
              disabled={!image || isProcessing}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-indigo-100 dark:shadow-none disabled:opacity-50"
            >
              {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              Transform Style
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 ml-1">Transformed Result</label>
              {resultImage && (
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={filename}
                      onChange={(e) => setFilename(e.target.value)}
                      placeholder="Enter Filename (Optional)"
                      className="w-32 px-2 py-1 text-[10px] border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 rounded focus:ring-1 focus:ring-indigo-500 outline-none text-slate-700 dark:text-slate-200"
                    />
                    <span className="absolute right-1.5 top-1 text-[10px] text-slate-400 dark:text-slate-600 pointer-events-none">.png</span>
                  </div>
                  <button
                    onClick={downloadImage}
                    className="text-xs flex items-center gap-1.5 text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              )}
            </div>
            <div className="bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 min-h-[300px] flex items-center justify-center p-4 transition-colors shadow-inner">
              {resultImage ? (
                <div className="relative group">
                  <img src={resultImage} alt="Result" className="max-h-full object-contain rounded-lg shadow-sm" />
                </div>
              ) : (
                <div className="text-slate-400 dark:text-slate-600 text-center opacity-50">
                  <ImageIcon className="w-12 h-12 mx-auto mb-2" />
                  <p className="text-sm">Transformed version will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* History Section */}
        {savedItems.length > 0 && (
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider ml-1">History</h3>
              <button 
                onClick={() => {
                  if (confirm('Clear all history?')) setSavedItems([]);
                }}
                className="text-xs text-red-500 hover:text-red-700 font-medium"
              >
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {savedItems.map((item) => (
                <div key={item.id} className="group relative bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden aspect-square transition-colors">
                  <img src={item.resultImage} alt="Saved result" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-2">
                    <p className="text-[10px] text-white font-bold uppercase tracking-wider">{item.style}</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setImage(item.image);
                          setResultImage(item.resultImage);
                          setStyle(item.style);
                        }}
                        className="p-1.5 bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-50 dark:hover:bg-slate-700 transition-colors"
                        title="Load"
                      >
                        <Upload className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => deleteSaved(item.id)}
                        className="p-1.5 bg-white dark:bg-slate-800 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-slate-700 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
