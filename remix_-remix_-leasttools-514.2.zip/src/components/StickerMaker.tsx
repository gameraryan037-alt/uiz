import React, { useState, useRef, useEffect } from 'react';
import { Image as ImageIcon, Download, Trash2, Eraser, Layers, Maximize, MousePointer2, Plus, Minus, RotateCcw, Sticker } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { saveToolState, loadToolState } from '../utils/db';

export default function StickerMaker() {
  const [image, setImage] = useState<string | null>(null);
  const [outlineWidth, setOutlineWidth] = useState(15);
  const [outlineColor, setOutlineColor] = useState('#ffffff');
  const [shadowBlur, setShadowBlur] = useState(10);
  const [shadowOpacity, setShadowOpacity] = useState(0.3);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const init = async () => {
      const savedState = await loadToolState('sticker-maker');
      if (savedState) {
        setOutlineWidth(savedState.outlineWidth || 15);
        setOutlineColor(savedState.outlineColor || '#ffffff');
        setShadowBlur(savedState.shadowBlur || 10);
        setShadowOpacity(savedState.shadowOpacity || 0.3);
      }
      setIsLoaded(true);
    };
    init();
  }, []);

  useEffect(() => {
    if (isLoaded) {
      saveToolState('sticker-maker', { outlineWidth, outlineColor, shadowBlur, shadowOpacity });
    }
  }, [outlineWidth, outlineColor, shadowBlur, shadowOpacity, isLoaded]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeBackgroundByColor = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current || !image) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * canvas.width);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    const targetIdx = (y * canvas.width + x) * 4;
    const targetR = data[targetIdx];
    const targetG = data[targetIdx + 1];
    const targetB = data[targetIdx + 2];
    const targetA = data[targetIdx + 3];

    // Simple color matching with tolerance
    const tolerance = 30;
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const a = data[i + 3];

      const dist = Math.sqrt(
        Math.pow(r - targetR, 2) +
        Math.pow(g - targetG, 2) +
        Math.pow(b - targetB, 2)
      );

      if (dist < tolerance) {
        data[i + 3] = 0; // Make transparent
      }
    }

    ctx.putImageData(imageData, 0, 0);
    // Update the image state with the new transparent version
    setImage(canvas.toDataURL());
  };

  const generateSticker = () => {
    if (!image || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      // We need extra space for the outline and shadow
      const padding = outlineWidth + shadowBlur + 20;
      canvas.width = img.width + padding * 2;
      canvas.height = img.height + padding * 2;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Draw the outline (Sticker Effect)
      // We draw the image multiple times in a circle to create a thick stroke
      ctx.save();
      ctx.shadowColor = outlineColor;
      ctx.shadowBlur = 0;
      
      // Draw outline by drawing the image shifted in many directions
      const steps = 32;
      for (let i = 0; i < steps; i++) {
        const angle = (i / steps) * Math.PI * 2;
        const dx = Math.cos(angle) * outlineWidth;
        const dy = Math.sin(angle) * outlineWidth;
        
        // Use a temporary canvas or globalCompositeOperation to make it solid color
        // But for simplicity, we can just draw it many times if it's already transparent
        ctx.drawImage(img, padding + dx, padding + dy);
      }
      
      // Fill the inside of the outline to ensure it's solid
      // This is a bit hacky but works for simple shapes
      ctx.globalCompositeOperation = 'source-in';
      ctx.fillStyle = outlineColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.restore();

      // 2. Add Drop Shadow to the whole sticker
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tempCtx = tempCanvas.getContext('2d');
      if (tempCtx) {
        tempCtx.drawImage(canvas, 0, 0);
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.shadowColor = `rgba(0,0,0,${shadowOpacity})`;
        ctx.shadowBlur = shadowBlur;
        ctx.shadowOffsetX = 5;
        ctx.shadowOffsetY = 5;
        ctx.drawImage(tempCanvas, 0, 0);
        ctx.restore();
      }

      // 3. Draw the original image on top
      ctx.drawImage(img, padding, padding);
    };
    img.src = image;
  };

  useEffect(() => {
    if (image) {
      generateSticker();
    }
  }, [image, outlineWidth, outlineColor, shadowBlur, shadowOpacity]);

  const downloadSticker = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = 'my-sticker.png';
    link.href = canvasRef.current.toDataURL('image/png');
    link.click();
  };

  const reset = () => {
    setImage(null);
    setOutlineWidth(15);
    setShadowBlur(10);
    setShadowOpacity(0.3);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <Sticker className="w-5 h-5 text-pink-500" />
          <h2>Sticker Maker</h2>
        </div>
        <div className="flex items-center gap-2">
          {image && (
            <button
              onClick={reset}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="p-6 space-y-8 overflow-y-auto custom-scrollbar">
        {!image ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-12 flex flex-col items-center justify-center gap-4 hover:border-pink-500 hover:bg-pink-50/50 dark:hover:bg-pink-900/10 transition-all cursor-pointer group"
          >
            <div className="w-20 h-20 bg-pink-50 dark:bg-pink-900/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
              <Plus className="w-10 h-10 text-pink-500" />
            </div>
            <div className="text-center">
              <p className="text-slate-700 dark:text-slate-200 font-bold text-lg">Upload an Image</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm">PNG or JPG works best. Transparent PNGs are ideal!</p>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              accept="image/*" 
              className="hidden" 
            />
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Controls */}
            <div className="lg:col-span-1 space-y-6">
              <div className="p-6 bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-6 shadow-sm">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Outline Width</label>
                    <span className="text-xs font-mono text-pink-500">{outlineWidth}px</span>
                  </div>
                  <input 
                    type="range" min="0" max="50" 
                    value={outlineWidth} 
                    onChange={(e) => setOutlineWidth(parseInt(e.target.value))}
                    className="w-full accent-pink-500"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Shadow Blur</label>
                    <span className="text-xs font-mono text-pink-500">{shadowBlur}px</span>
                  </div>
                  <input 
                    type="range" min="0" max="30" 
                    value={shadowBlur} 
                    onChange={(e) => setShadowBlur(parseInt(e.target.value))}
                    className="w-full accent-pink-500"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Shadow Opacity</label>
                    <span className="text-xs font-mono text-pink-500">{Math.round(shadowOpacity * 100)}%</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.05"
                    value={shadowOpacity} 
                    onChange={(e) => setShadowOpacity(parseFloat(e.target.value))}
                    className="w-full accent-pink-500"
                  />
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-3">Outline Color</label>
                  <div className="flex gap-2 flex-wrap">
                    {['#ffffff', '#000000', '#ff00ff', '#00ffff', '#ffff00'].map(color => (
                      <button
                        key={color}
                        onClick={() => setOutlineColor(color)}
                        className={`w-8 h-8 rounded-full border-2 transition-all ${outlineColor === color ? 'border-pink-500 scale-110' : 'border-transparent'}`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                    <input 
                      type="color" 
                      value={outlineColor} 
                      onChange={(e) => setOutlineColor(e.target.value)}
                      className="w-8 h-8 rounded-full cursor-pointer overflow-hidden border-none p-0"
                    />
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-900/20 rounded-2xl flex items-start gap-3">
                <Eraser className="w-5 h-5 text-amber-500 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-xs font-bold text-amber-900 dark:text-amber-100 uppercase tracking-wider">Background Removal</p>
                  <p className="text-[10px] text-amber-700/70 dark:text-amber-300/50 leading-relaxed">
                    Click on any solid color in the preview to make it transparent. This works best for images with solid backgrounds (like white or green).
                  </p>
                </div>
              </div>
            </div>

            {/* Preview */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white dark:bg-slate-950 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden group">
                {/* Transparency Grid Background */}
                <div className="absolute inset-0 opacity-10" style={{ 
                  backgroundImage: 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)',
                  backgroundSize: '20px 20px',
                  backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
                }} />
                
                <div className="relative z-10 max-w-full max-h-full overflow-auto custom-scrollbar p-4">
                  <canvas 
                    ref={canvasRef} 
                    onClick={removeBackgroundByColor}
                    className="max-w-full h-auto cursor-crosshair shadow-2xl rounded-lg"
                    title="Click to remove color"
                  />
                </div>

                <div className="absolute bottom-6 right-6 flex gap-2">
                  <button
                    onClick={downloadSticker}
                    className="flex items-center gap-2 px-6 py-3 bg-pink-600 hover:bg-pink-700 text-white rounded-xl shadow-lg shadow-pink-500/20 transition-all font-bold text-sm"
                  >
                    <Download className="w-4 h-4" />
                    Save Sticker
                  </button>
                </div>

                <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1.5 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border border-slate-200 dark:border-slate-800 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  <MousePointer2 className="w-3 h-3" />
                  Click to remove bg color
                </div>
              </div>

              <div className="flex items-center justify-center gap-4">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs font-bold text-slate-500 hover:text-pink-500 transition-colors flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Change Image
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleImageUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
