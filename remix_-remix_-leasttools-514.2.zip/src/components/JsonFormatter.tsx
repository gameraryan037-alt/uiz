import React, { useState } from 'react';
import { FileCode, Clipboard, Check, Trash2, AlertCircle, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function JsonFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const formatJson = () => {
    setError(null);
    try {
      if (!input.trim()) {
        setOutput('');
        return;
      }
      const parsed = JSON.parse(input);
      setOutput(JSON.stringify(parsed, null, 2));
    } catch (e: any) {
      setError(e.message);
      setOutput('');
    }
  };

  const validateJson = () => {
    setError(null);
    try {
      if (!input.trim()) return;
      JSON.parse(input);
      alert('JSON is valid!');
    } catch (e: any) {
      setError(e.message);
    }
  };

  const copyToClipboard = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const clear = () => {
    setInput('');
    setOutput('');
    setError(null);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col h-full transition-colors"
    >
      <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-200/50 dark:bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200 font-medium">
          <FileCode className="w-5 h-5 text-amber-500" />
          <h2>JSON Formatter & Validator</h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={clear}
            className="p-2 text-slate-400 hover:text-red-500 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={copyToClipboard}
            disabled={!output}
            className="p-2 text-slate-400 hover:text-amber-500 transition-colors disabled:opacity-30"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Clipboard className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full min-h-[400px]">
          {/* Input */}
          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Input JSON</label>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder='Paste your messy JSON here...'
              className="flex-1 p-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl font-mono text-sm focus:ring-2 focus:ring-amber-500 outline-none resize-none"
            />
          </div>

          {/* Output */}
          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Formatted Output</label>
            <div className="flex-1 relative">
              <textarea
                readOnly
                value={output}
                placeholder='Formatted JSON will appear here...'
                className="w-full h-full p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl font-mono text-sm outline-none resize-none"
              />
              {error && (
                <div className="absolute inset-0 bg-red-500/10 backdrop-blur-[1px] flex items-center justify-center p-6 rounded-2xl">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-200 dark:border-red-900 shadow-xl flex items-start gap-3 max-w-xs">
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-red-600 dark:text-red-400">Invalid JSON</p>
                      <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">{error}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="flex gap-4">
          <button
            onClick={formatJson}
            className="flex-1 py-4 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-bold shadow-lg shadow-amber-500/20 transition-all"
          >
            Format JSON
          </button>
          <button
            onClick={validateJson}
            className="flex-1 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition-all"
          >
            Validate
          </button>
        </div>
      </div>
    </motion.div>
  );
}
