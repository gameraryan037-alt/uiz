/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import TxtConverter from './components/TxtConverter';
import PdfConverter from './components/PdfConverter';
import WordCounter from './components/WordCounter';
import SearchInText from './components/SearchInText';
import CollageMaker from './components/CollageMaker';
import GrammarCorrection from './components/GrammarCorrection';
import TextExtractor from './components/TextExtractor';
import UnitConverter from './components/UnitConverter';
import ImageEnhancer from './components/ImageEnhancer';
import ManualImageEnhancer from './components/ManualImageEnhancer';
import ImageExpander from './components/ImageExpander';
import ImageToRealistic from './components/ImageToRealistic';
import ImageToPrompt from './components/ImageToPrompt';
import Summarizer from './components/Summarizer';
import Translator from './components/Translator';
import StoryGenerator from './components/StoryGenerator';
import ExamChecker from './components/ExamChecker';
import ExamSolver from './components/ExamSolver';
import StatsCalculator from './components/StatsCalculator';
import QuizMaker from './components/QuizMaker';
import TaxCalculator from './components/TaxCalculator';
import PriceComparator from './components/PriceComparator';
import WatermarkRemover from './components/WatermarkRemover';
import StickerMaker from './components/StickerMaker';
import QRCodeGenerator from './components/QRCodeGenerator';
import BarcodeGenerator from './components/BarcodeGenerator';
import TextToImage from './components/TextToImage';
import OttApps from './components/OttApps';
import PdfToWord from './components/PdfToWord';
import PercentageCalculator from './components/PercentageCalculator';
import PomodoroTimer from './components/PomodoroTimer';
import BudgetCalculator from './components/BudgetCalculator';
import LoanCalculator from './components/LoanCalculator';
import TimeZoneConverter from './components/TimeZoneConverter';
import HabitTracker from './components/HabitTracker';
import PdfToolkit from './components/PdfToolkit';
import InvoiceGenerator from './components/InvoiceGenerator';
import JsonFormatter from './components/JsonFormatter';
import ColorPaletteGenerator from './components/ColorPaletteGenerator';
import MarkdownPreviewer from './components/MarkdownPreviewer';
import Base64Tool from './components/Base64Tool';
import GlassmorphismGenerator from './components/GlassmorphismGenerator';
import NeumorphismPlayground from './components/NeumorphismPlayground';
import SvgWaveGenerator from './components/SvgWaveGenerator';
import CssPatternMaker from './components/CssPatternMaker';
import GoldenRatioCalculator from './components/GoldenRatioCalculator';
import SpirographSimulator from './components/SpirographSimulator';
import FractalTreeGenerator from './components/FractalTreeGenerator';
import TessellationMaker from './components/TessellationMaker';
import ParticlePhysicsSandbox from './components/ParticlePhysicsSandbox';
import SvgFilterKitchen from './components/SvgFilterKitchen';
import ImageLegoizer from './components/ImageLegoizer';
import AspectRatioVisualizer from './components/AspectRatioVisualizer';
import ColorBlindnessSimulator from './components/ColorBlindnessSimulator';
import AdvancedPdfTools from './components/AdvancedPdfTools';
import PdfFlipbook from './components/PdfFlipbook';
import PyqSolver from './components/PyqSolver';
import ApiKeyModal from './components/ApiKeyModal';
import Auth from './components/Auth';
import { Logo } from './components/Logo';
import { ArrowRightLeft, FileText, Upload, AlignLeft, ArrowLeft, Search, Grid, Languages, Image as ImageIcon, Type, Sparkles, ClipboardCheck, Zap, FileCode, HelpCircle, Maximize2, BookOpen, Sigma, Wand2, ScanLine, ImagePlus, ExternalLink, Tv, Sun, Moon, Calculator, Scale, Eraser, QrCode, ShieldCheck, Lock, Settings, Plus, X, FileType, Percent, Barcode, Sticker, Hash, Maximize, FileDigit, Brain, Wallet, Globe, FileStack, Receipt, Braces, Palette, FileEdit, Shield, Layers, Square, Waves, Grid3X3, Ratio, CircleDot, TreeDeciduous, LayoutGrid, Atom, ChefHat, Box, Eye } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type View = 'home' | 'secret-home' | 'txt-converter' | 'pdf-converter' | 'pdf-to-word' | 'word-counter' | 'search-in-text' | 'collage-maker' | 'grammar-correction' | 'text-extractor' | 'unit-converter' | 'image-enhancer' | 'manual-image-enhancer' | 'image-expander' | 'image-to-realistic' | 'image-to-prompt' | 'translator' | 'summarizer' | 'story-generator' | 'exam-checker' | 'exam-solver' | 'stats-calculator' | 'quiz-maker' | 'tax-calculator' | 'price-comparator' | 'text-to-image' | 'watermark-remover' | 'qr-generator' | 'ott-apps' | 'percentage-calculator' | 'barcode-generator' | 'sticker-maker' | 'pomodoro-timer' | 'budget-calculator' | 'loan-calculator' | 'timezone-converter' | 'habit-tracker' | 'pdf-toolkit' | 'invoice-generator' | 'json-formatter' | 'color-palette' | 'markdown-preview' | 'base64-tool' | 'glassmorphism' | 'neumorphism' | 'svg-wave' | 'css-pattern' | 'golden-ratio' | 'spirograph' | 'fractal-tree' | 'tessellation' | 'particle-physics' | 'svg-filter' | 'image-legoizer' | 'aspect-ratio' | 'color-blindness' | 'advanced-pdf' | 'pdf-flipbook' | 'pyq-solver';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSecretButton, setShowSecretButton] = useState(false);
  const [lastUsedTool, setLastUsedTool] = useState<View | null>(null);
  const [secretToolIds, setSecretToolIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('secretToolIds');
    if (saved) return JSON.parse(saved);
    
    // Default: Move all AI-related tools to secret area
    return [
      'grammar-correction', 'translator', 'summarizer', 'story-generator', 
      'text-extractor', 'exam-checker', 'quiz-maker', 'pyq-solver',
      'image-enhancer', 'image-expander', 'image-to-realistic', 
      'image-to-prompt', 'text-to-image', 'watermark-remover'
    ];
  });
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    // Default to light mode (false) if no saved preference
    return saved === 'dark';
  });
  const homeScrollPos = React.useRef(0);
  const searchInputRef = React.useRef<HTMLInputElement>(null);

  // Apply theme to document
  React.useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.body.style.backgroundColor = '#020617'; // slate-950
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#f8fafc'; // slate-50
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  // Load last used tool from localStorage on mount
  React.useEffect(() => {
    const saved = localStorage.getItem('lastUsedTool');
    if (saved && saved !== 'home' && saved !== 'secret-home') {
      setLastUsedTool(saved as View);
    }
  }, []);

  const tools = [
    // Document & Text Utilities
    // Productivity & Office Tools
    {
      id: 'pomodoro-timer',
      title: 'Pomodoro Timer',
      description: 'A customizable focus timer with nature sounds (White/Pink/Brown noise).',
      icon: Brain,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      hoverBorder: 'hover:border-red-200',
      category: '🛠️ Productivity & Office Tools'
    },
    {
      id: 'qr-generator',
      title: 'QR Code Generator',
      description: 'Generate custom QR codes for links, text, WiFi, and more.',
      icon: QrCode,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🛠️ Productivity & Office Tools'
    },
    {
      id: 'barcode-generator',
      title: 'Barcode Generator',
      description: 'Generate various barcode formats (CODE128, EAN, UPC) instantly.',
      icon: Barcode,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🛠️ Productivity & Office Tools'
    },
    {
      id: 'habit-tracker',
      title: 'Habit Tracker',
      description: 'A simple grid where users can check off daily goals offline.',
      icon: ClipboardCheck,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🛠️ Productivity & Office Tools'
    },
    // Developer & Design Utilities
    {
      id: 'json-formatter',
      title: 'JSON Formatter',
      description: 'Format, validate, and beautify messy JSON data instantly.',
      icon: Braces,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '💻 Developer & Design Utilities'
    },
    {
      id: 'color-palette',
      title: 'Color Palette',
      description: 'Generate harmonious color schemes using math-based color theory.',
      icon: Palette,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '💻 Developer & Design Utilities'
    },
    {
      id: 'markdown-preview',
      title: 'Markdown Preview',
      description: 'Write markdown and see live preview with professional styling.',
      icon: FileEdit,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '💻 Developer & Design Utilities'
    },
    {
      id: 'base64-tool',
      title: 'Base64 Tool',
      description: 'Encode and decode text to Base64 format securely.',
      icon: Shield,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '💻 Developer & Design Utilities'
    },
    // Document & Text
    {
      id: 'pdf-toolkit',
      title: 'PDF Toolkit',
      description: 'Simple PDF merging, splitting, and page rotation instantly.',
      icon: FileStack,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      hoverBorder: 'hover:border-red-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'advanced-pdf',
      title: 'Pro PDF Suite',
      description: 'Advanced tools: Booklet Maker, Overlay, Bates Numbering, and more.',
      icon: ShieldCheck,
      color: 'text-red-700',
      bgColor: 'bg-red-50',
      hoverBorder: 'hover:border-red-300',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'pdf-flipbook',
      title: 'PDF Flipbook',
      description: 'Convert static PDFs into interactive 3D flipbooks.',
      icon: BookOpen,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'word-counter',
      title: 'Word Counter',
      description: 'Analyze text stats like word count, characters, and top 5 words.',
      icon: FileDigit,
      color: 'text-orange-500',
      bgColor: 'bg-orange-50',
      hoverBorder: 'hover:border-orange-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'txt-converter',
      title: 'Text to TXT',
      description: 'Convert text to .txt files and read .txt files into text instantly.',
      icon: FileCode,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'pdf-converter',
      title: 'PDF Converter',
      description: 'Convert images to PDF and extract images from PDF files.',
      icon: FileText,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      hoverBorder: 'hover:border-red-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'pdf-to-word',
      title: 'PDF to Word',
      description: 'Convert PDF documents to editable Word (.docx) files locally.',
      icon: FileType,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '📄 Document & Text Utilities'
    },
    {
      id: 'search-in-text',
      title: 'Search in Text',
      description: 'Find occurrences of words or phrases and see them highlighted.',
      icon: Search,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '📄 Document & Text Utilities'
    },
    // AI & Language Tools
    {
      id: 'grammar-correction',
      title: 'Grammar Fix',
      description: 'Correct grammar in English, Hindi, and Hinglish instantly.',
      icon: Languages,
      color: 'text-pink-500',
      bgColor: 'bg-pink-50',
      hoverBorder: 'hover:border-pink-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'translator',
      title: 'AI Translator',
      description: 'Translate text between English, Hindi, and Hinglish with AI.',
      icon: Languages,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'summarizer',
      title: 'AI Summarizer',
      description: 'Summarize long notes and text into a short, concise form instantly.',
      icon: AlignLeft,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'story-generator',
      title: 'Story Maker',
      description: 'Generate creative stories from keywords in multiple languages.',
      icon: BookOpen,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'text-extractor',
      title: 'Text Extractor',
      description: 'Extract text from images, PDFs, or text files using advanced AI.',
      icon: ScanLine,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'exam-checker',
      title: 'Exam Checker',
      description: 'Grade answers against questions and get detailed feedback.',
      icon: ClipboardCheck,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'exam-solver',
      title: 'AI Exam Solver',
      description: 'Analyze questions and diagrams to provide step-by-step solutions.',
      icon: Zap,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      hoverBorder: 'hover:border-yellow-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'quiz-maker',
      title: 'Quiz Maker',
      description: 'Generate interactive quizzes from any text or topic using AI.',
      icon: HelpCircle,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🤖 AI & Language Tools'
    },
    {
      id: 'pyq-solver',
      title: 'AI PYQ Solver',
      description: 'Get step-by-step solutions for Previous Year Questions of any chapter.',
      icon: Zap,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      hoverBorder: 'hover:border-amber-200',
      category: '🤖 AI & Language Tools'
    },
    // Creative & Visual
    {
      id: 'collage-maker',
      title: 'Quick Collage',
      description: 'Create beautiful photo grids and collages in seconds.',
      icon: Grid,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50',
      hoverBorder: 'hover:border-purple-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'image-enhancer',
      title: 'AI Photo Enhancer',
      description: 'Enhance and sharpen your photos with AI clarity.',
      icon: Sparkles,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'manual-image-enhancer',
      title: 'Image Enhancer',
      description: 'Improve image quality, sharpness, and clarity instantly.',
      icon: Maximize,
      color: 'text-amber-500',
      bgColor: 'bg-amber-50',
      hoverBorder: 'hover:border-amber-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'image-expander',
      title: 'AI Expander',
      description: 'Expand image backgrounds to any aspect ratio with AI.',
      icon: Maximize2,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      hoverBorder: 'hover:border-purple-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'image-to-realistic',
      title: 'Image Style Changer',
      description: 'Convert drawings or anime art into realistic photographs.',
      icon: Wand2,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'image-to-prompt',
      title: 'Image to Prompt',
      description: 'Generate highly detailed AI prompts from any image for precise recreation.',
      icon: ScanLine,
      color: 'text-pink-500',
      bgColor: 'bg-pink-50',
      hoverBorder: 'hover:border-pink-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'text-to-image',
      title: 'Text to Image',
      description: 'Find the best AI image generation tools and resources.',
      icon: ImagePlus,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      hoverBorder: 'hover:border-purple-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'watermark-remover',
      title: 'Watermark Remover',
      description: 'Remove watermarks, logos, and text from images using AI.',
      icon: Eraser,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'sticker-maker',
      title: 'Sticker Maker',
      description: 'Create stickers with outlines and shadows. Remove background colors easily.',
      icon: Sticker,
      color: 'text-pink-500',
      bgColor: 'bg-pink-50',
      hoverBorder: 'hover:border-pink-200',
      category: '🎨 Creative & Visual Tools'
    },
    {
      id: 'ott-apps',
      title: 'OTT Apps',
      description: 'Stream your favorite content with premium OTT apps.',
      icon: Tv,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎨 Creative & Visual Tools'
    },
    // Design & Aesthetic Tools
    {
      id: 'glassmorphism',
      title: 'Glassmorphism',
      description: 'Create "frosted glass" effects with CSS backdrop-filter.',
      icon: Layers,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '🎨 Design & Aesthetic Tools'
    },
    {
      id: 'neumorphism',
      title: 'Neumorphism',
      description: 'Generate "soft UI" elements with light and dark box-shadows.',
      icon: Square,
      color: 'text-slate-500',
      bgColor: 'bg-slate-50',
      hoverBorder: 'hover:border-slate-200',
      category: '🎨 Design & Aesthetic Tools'
    },
    {
      id: 'svg-wave',
      title: 'SVG Wave Generator',
      description: 'Generate smooth organic shapes or wave footers using math.',
      icon: Waves,
      color: 'text-cyan-500',
      bgColor: 'bg-cyan-50',
      hoverBorder: 'hover:border-cyan-200',
      category: '🎨 Design & Aesthetic Tools'
    },
    {
      id: 'css-pattern',
      title: 'CSS Pattern Maker',
      description: 'Create geometric patterns entirely with CSS gradients.',
      icon: Grid3X3,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎨 Design & Aesthetic Tools'
    },
    {
      id: 'golden-ratio',
      title: 'Golden Ratio Calc',
      description: 'Overlay Fibonacci spiral on images for perfect composition.',
      icon: Ratio,
      color: 'text-amber-500',
      bgColor: 'bg-amber-50',
      hoverBorder: 'hover:border-amber-200',
      category: '🎨 Design & Aesthetic Tools'
    },
    // Mathematical Art Tools
    {
      id: 'spirograph',
      title: 'Spirograph',
      description: 'Draw complex geometric curves with a digital spirograph.',
      icon: CircleDot,
      color: 'text-pink-500',
      bgColor: 'bg-pink-50',
      hoverBorder: 'hover:border-pink-200',
      category: '📐 Mathematical Art Tools'
    },
    {
      id: 'fractal-tree',
      title: 'Fractal Tree',
      description: 'Recursive drawing tool to create infinite, unique trees.',
      icon: TreeDeciduous,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '📐 Mathematical Art Tools'
    },
    {
      id: 'tessellation',
      title: 'Tessellation Maker',
      description: 'Draw in one tile and see it repeated across the screen.',
      icon: LayoutGrid,
      color: 'text-purple-500',
      bgColor: 'bg-purple-50',
      hoverBorder: 'hover:border-purple-200',
      category: '📐 Mathematical Art Tools'
    },
    {
      id: 'particle-physics',
      title: 'Particle Sandbox',
      description: 'Interactive particle background with gravity and friction.',
      icon: Atom,
      color: 'text-blue-400',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '📐 Mathematical Art Tools'
    },
    // Photo & Image Utilities
    {
      id: 'svg-filter',
      title: 'SVG Filter Kitchen',
      description: 'Apply advanced SVG effects like Turbulence and Color Matrix.',
      icon: ChefHat,
      color: 'text-orange-500',
      bgColor: 'bg-orange-50',
      hoverBorder: 'hover:border-orange-200',
      category: '🎞️ Photo & Image Utilities'
    },
    {
      id: 'image-legoizer',
      title: 'Image Lego-izer',
      description: 'Pixelate images and map colors to standard LEGO bricks.',
      icon: Box,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      hoverBorder: 'hover:border-red-200',
      category: '🎞️ Photo & Image Utilities'
    },
    {
      id: 'aspect-ratio',
      title: 'Aspect Ratio',
      description: 'Visual comparison of different aspect ratios for planning.',
      icon: Maximize2,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🎞️ Photo & Image Utilities'
    },
    {
      id: 'color-blindness',
      title: 'Color Blindness',
      description: 'Simulate how images look with color vision deficiencies.',
      icon: Eye,
      color: 'text-slate-600',
      bgColor: 'bg-slate-50',
      hoverBorder: 'hover:border-slate-200',
      category: '🎞️ Photo & Image Utilities'
    },
    // Utilities & Calculators
    {
      id: 'invoice-generator',
      title: 'Invoice Generator',
      description: 'Generate professional PDF invoices for freelancers and businesses.',
      icon: Receipt,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'budget-calculator',
      title: 'Budget Calculator',
      description: 'A "Zero-Based" budgeting tool where users input income and expenses.',
      icon: Wallet,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'unit-converter',
      title: 'Unit Converter',
      description: 'Universal converter: Pixels to REM, Bytes to GB, Temp, and more.',
      icon: ArrowRightLeft,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'loan-calculator',
      title: 'Loan/EMI Calculator',
      description: 'Calculates monthly payments and total interest for student or home loans.',
      icon: Calculator,
      color: 'text-blue-500',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'timezone-converter',
      title: 'Time Zone Converter',
      description: 'Meeting planner showing overlapping work hours for different cities.',
      icon: Globe,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'stats-calculator',
      title: 'Stats Calculator',
      description: 'Calculate mean, median, mode, and range with live results.',
      icon: Sigma,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      hoverBorder: 'hover:border-blue-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'tax-calculator',
      title: 'Tax Calculator',
      description: 'Calculate standard tax (VAT/GST) for different countries instantly.',
      icon: Calculator,
      color: 'text-indigo-500',
      bgColor: 'bg-indigo-50',
      hoverBorder: 'hover:border-indigo-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'percentage-calculator',
      title: 'Percentage Calc',
      description: 'Calculate percentages, increases, decreases, and additions instantly.',
      icon: Percent,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🧮 Utilities & Calculators'
    },
    {
      id: 'price-comparator',
      title: 'Price Comparator',
      description: 'Compare effective prices between two countries including taxes and currency.',
      icon: Scale,
      color: 'text-emerald-500',
      bgColor: 'bg-emerald-50',
      hoverBorder: 'hover:border-emerald-200',
      category: '🧮 Utilities & Calculators'
    }
  ];

  const handleViewSelect = (view: View) => {
    if (currentView === 'home' || currentView === 'secret-home') {
      homeScrollPos.current = window.scrollY;
    }
    setCurrentView(view);
    if (view !== 'home' && view !== 'secret-home') {
      setLastUsedTool(view);
      localStorage.setItem('lastUsedTool', view);
    }
  };

  // Scroll to top when opening a tool
  React.useEffect(() => {
    if (currentView !== 'home' && currentView !== 'secret-home') {
      window.scrollTo(0, 0);
    }
  }, [currentView]);

  // Global keyboard shortcuts
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + B to go back home OR open most recent tool if on home
      if (e.ctrlKey && e.key.toLowerCase() === 'b') {
        e.preventDefault();
        if (currentView === 'home' || currentView === 'secret-home') {
          if (lastUsedTool) {
            setCurrentView(lastUsedTool);
          }
        } else {
          setCurrentView('home');
        }
      }

      // / to focus search if on home
      if (e.key === '/' && (currentView === 'home' || currentView === 'secret-home')) {
        // Only focus if not already typing in an input
        if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
          e.preventDefault();
          searchInputRef.current?.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentView, lastUsedTool]);

  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (val === '514069') {
      setShowSecretButton(true);
    } else {
      setShowSecretButton(false);
    }
  };

  const toggleSecretTool = (id: string) => {
    setSecretToolIds(prev => {
      const next = prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id];
      localStorage.setItem('secretToolIds', JSON.stringify(next));
      return next;
    });
  };

  const renderView = () => {
    switch (currentView) {
      case 'txt-converter':
        return <TxtConverter />;
      case 'pdf-converter':
        return <PdfConverter />;
      case 'pdf-to-word':
        return <PdfToWord />;
      case 'word-counter':
        return <WordCounter />;
      case 'search-in-text':
        return <SearchInText />;
      case 'collage-maker':
        return <CollageMaker />;
      case 'grammar-correction':
        return <GrammarCorrection />;
      case 'text-extractor':
        return <TextExtractor />;
      case 'unit-converter':
        return <UnitConverter />;
      case 'image-enhancer':
        return <ImageEnhancer />;
      case 'manual-image-enhancer':
        return <ManualImageEnhancer />;
      case 'image-expander':
        return <ImageExpander />;
      case 'image-to-realistic':
        return <ImageToRealistic />;
      case 'image-to-prompt':
        return <ImageToPrompt />;
      case 'translator':
        return <Translator />;
      case 'summarizer':
        return <Summarizer />;
      case 'story-generator':
        return <StoryGenerator />;
      case 'exam-checker':
        return <ExamChecker />;
      case 'exam-solver':
        return <ExamSolver />;
      case 'stats-calculator':
        return <StatsCalculator />;
      case 'quiz-maker':
        return <QuizMaker />;
      case 'tax-calculator':
        return <TaxCalculator />;
      case 'price-comparator':
        return <PriceComparator />;
      case 'text-to-image':
        return <TextToImage />;
      case 'watermark-remover':
        return <WatermarkRemover />;
      case 'sticker-maker':
        return <StickerMaker />;
      case 'qr-generator':
        return <QRCodeGenerator />;
      case 'barcode-generator':
        return <BarcodeGenerator />;
      case 'ott-apps':
        return <OttApps />;
      case 'percentage-calculator':
        return <PercentageCalculator />;
      case 'pomodoro-timer':
        return <PomodoroTimer />;
      case 'budget-calculator':
        return <BudgetCalculator />;
      case 'loan-calculator':
        return <LoanCalculator />;
      case 'timezone-converter':
        return <TimeZoneConverter />;
      case 'habit-tracker':
        return <HabitTracker />;
      case 'pdf-toolkit':
        return <PdfToolkit />;
      case 'invoice-generator':
        return <InvoiceGenerator />;
      case 'json-formatter':
        return <JsonFormatter />;
      case 'color-palette':
        return <ColorPaletteGenerator />;
      case 'markdown-preview':
        return <MarkdownPreviewer />;
      case 'base64-tool':
        return <Base64Tool />;
      case 'glassmorphism':
        return <GlassmorphismGenerator />;
      case 'neumorphism':
        return <NeumorphismPlayground />;
      case 'svg-wave':
        return <SvgWaveGenerator />;
      case 'css-pattern':
        return <CssPatternMaker />;
      case 'golden-ratio':
        return <GoldenRatioCalculator />;
      case 'spirograph':
        return <SpirographSimulator />;
      case 'fractal-tree':
        return <FractalTreeGenerator />;
      case 'tessellation':
        return <TessellationMaker />;
      case 'particle-physics':
        return <ParticlePhysicsSandbox />;
      case 'svg-filter':
        return <SvgFilterKitchen />;
      case 'image-legoizer':
        return <ImageLegoizer />;
      case 'aspect-ratio':
        return <AspectRatioVisualizer />;
      case 'color-blindness':
        return <ColorBlindnessSimulator />;
      case 'advanced-pdf':
        return <AdvancedPdfTools />;
      case 'pdf-flipbook':
        return <PdfFlipbook />;
      case 'pyq-solver':
        return <PyqSolver />;
      case 'secret-home':
        return <Home onViewSelect={handleViewSelect} searchQuery={searchQuery} tools={tools} initialScroll={homeScrollPos.current} isSecret secretToolIds={secretToolIds} onToggleSecret={toggleSecretTool} />;
      default:
        return <Home onViewSelect={handleViewSelect} searchQuery={searchQuery} tools={tools} initialScroll={homeScrollPos.current} secretToolIds={secretToolIds} onToggleSecret={toggleSecretTool} />;
    }
  };

  const currentTool = tools.find(t => t.id === currentView);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col font-sans text-slate-900 dark:text-slate-100 transition-colors duration-300">
      <div className="flex-1 flex flex-col max-w-6xl mx-auto w-full px-4 md:px-8">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row items-center justify-between gap-4 py-6 border-b border-slate-200/60 dark:border-slate-800/60">
          <div className="flex items-center gap-3 w-full md:w-auto">
            {currentView !== 'home' && currentView !== 'secret-home' && (
              <button 
                onClick={() => setCurrentView('home')}
                className="mr-2 p-2 -ml-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="relative group cursor-pointer" onClick={() => setCurrentView('home')}>
              <div className="p-1 bg-white dark:bg-slate-900 rounded-2xl shadow-xl shadow-indigo-200/50 dark:shadow-indigo-900/20 relative z-10 border border-slate-100 dark:border-slate-800 transition-transform group-hover:scale-110">
                <Logo className="w-10 h-10" />
              </div>
              <div className="absolute -inset-2 bg-indigo-400/10 blur-xl rounded-full -z-0 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 dark:from-white dark:via-indigo-200 dark:to-white">
                {currentView === 'home' ? 'Leasttools' : currentView === 'secret-home' ? 'Secret Area' : currentTool?.title}
              </h1>
              {(currentView === 'home' || currentView === 'secret-home') && (
                <p className="text-slate-500 dark:text-slate-400 text-xs font-medium uppercase tracking-widest opacity-70">
                  {currentView === 'secret-home' ? 'Restricted Access' : 'Premium Apps & Tools'}
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            {/* Top Right Search Bar (Desktop) */}
            {(currentView === 'home' || currentView === 'secret-home') && (
              <div className="relative flex-1 md:w-64 lg:w-80">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  ref={searchInputRef}
                  type="text"
                  className="block w-full pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-800 rounded-lg leading-5 bg-white dark:bg-slate-900 placeholder-slate-400 focus:outline-none focus:placeholder-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all shadow-sm dark:text-white"
                  placeholder="Search tools..."
                  value={searchQuery}
                  onChange={(e) => handleSearchChange(e.target.value)}
                />
                
                <AnimatePresence>
                  {showSecretButton && (
                    <motion.button
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      onClick={() => {
                        setCurrentView('secret-home');
                        setSearchQuery('');
                        setShowSecretButton(false);
                      }}
                      className="absolute top-full left-0 right-0 mt-2 p-2 bg-indigo-600 text-white text-xs font-bold rounded-lg shadow-lg hover:bg-indigo-700 transition-colors z-50 flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-3 h-3" />
                      Enter Secret Area
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Theme Toggle Button */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm"
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <Auth />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentView}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              {renderView()}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Footer */}
        <footer className="text-center text-slate-400 dark:text-slate-500 text-[10px] md:text-xs py-4 border-t border-slate-100 dark:border-slate-800">
          <p>Files are processed locally in your browser. No data is uploaded to any server.</p>
        </footer>
      </div>
      <ApiKeyModal />
    </div>
  );
}

function Home({ onViewSelect, searchQuery, tools, initialScroll = 0, isSecret = false, secretToolIds = [], onToggleSecret }: { onViewSelect: (view: View) => void, searchQuery: string, tools: any[], initialScroll?: number, isSecret?: boolean, secretToolIds?: string[], onToggleSecret?: (id: string) => void }) {
  const [showManageTools, setShowManageTools] = useState(false);

  // Restore scroll position when Home mounts
  React.useLayoutEffect(() => {
    if (initialScroll > 0) {
      window.scrollTo(0, initialScroll);
    }
  }, [initialScroll]);

  const publicTools = tools.filter(t => !secretToolIds.includes(t.id));
  const secretTools = tools.filter(t => secretToolIds.includes(t.id));

  const displayTools = isSecret ? secretTools : publicTools;

  if (isSecret && secretTools.length === 0 && !showManageTools) {
    return (
      <div className="space-y-8">
        <div className="p-8 bg-indigo-600/5 border border-indigo-500/20 rounded-3xl text-center space-y-4">
          <div className="w-16 h-16 bg-indigo-600/10 rounded-2xl flex items-center justify-center mx-auto">
            <ShieldCheck className="w-8 h-8 text-indigo-600" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Secret Admin Area</h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm max-w-md mx-auto">No tools have been moved to the secret area yet. Add tools from the main app to hide them from public view.</p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => setShowManageTools(true)}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
            >
              <Settings className="w-4 h-4" />
              Manage Tools
            </button>
            <button 
              onClick={() => onViewSelect('home')}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-xl font-bold hover:bg-slate-300 dark:hover:bg-slate-700 transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (isSecret && showManageTools) {
    const aiToolIds = [
      'grammar-correction', 'translator', 'summarizer', 'story-generator', 
      'text-extractor', 'exam-checker', 'exam-solver', 'quiz-maker', 'pyq-solver',
      'image-enhancer', 'image-expander', 'image-to-realistic', 
      'image-to-prompt', 'text-to-image', 'watermark-remover'
    ];

    const moveAllAI = () => {
      aiToolIds.forEach(id => {
        if (!secretToolIds.includes(id)) onToggleSecret?.(id);
      });
    };

    const resetAll = () => {
      secretToolIds.forEach(id => onToggleSecret?.(id));
    };

    return (
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
              <Settings className="w-5 h-5 text-indigo-600" />
            </div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Manage Tool Visibility</h2>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={moveAllAI}
              className="px-3 py-1.5 bg-indigo-600 text-white text-[10px] font-bold rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3 h-3" />
              Move All AI
            </button>
            <button 
              onClick={resetAll}
              className="px-3 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-[10px] font-bold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
              Reset All
            </button>
            <button 
              onClick={() => setShowManageTools(false)}
              className="p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Public Tools */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-500 rounded-full" />
              Public Tools ({publicTools.length})
            </h3>
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {publicTools.map(tool => (
                <div key={tool.id} className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 ${tool.bgColor} dark:bg-slate-800 rounded-lg`}>
                      <tool.icon className={`w-4 h-4 ${tool.color}`} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900 dark:text-white">{tool.title}</p>
                      <p className="text-[10px] text-slate-500 truncate max-w-[150px]">{tool.category}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => onToggleSecret?.(tool.id)}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-colors"
                    title="Move to Secret Area"
                  >
                    <Lock className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Secret Tools */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <div className="w-2 h-2 bg-indigo-500 rounded-full" />
              Secret Tools ({secretTools.length})
            </h3>
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {secretTools.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl text-slate-400 text-xs">
                  No secret tools yet
                </div>
              ) : (
                secretTools.map(tool => (
                  <div key={tool.id} className="flex items-center justify-between p-3 bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-200/50 dark:border-indigo-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 ${tool.bgColor} dark:bg-slate-800 rounded-lg`}>
                        <tool.icon className={`w-4 h-4 ${tool.color}`} />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900 dark:text-white">{tool.title}</p>
                        <p className="text-[10px] text-slate-500 truncate max-w-[150px]">{tool.category}</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => onToggleSecret?.(tool.id)}
                      className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors"
                      title="Move to Public Area"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  const filteredTools = displayTools.filter(tool =>
    tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tool.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = Array.from(new Set(displayTools.map(t => t.category)));

  return (
    <div className="space-y-12">
      {isSecret && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-lg">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <p className="text-indigo-600 dark:text-indigo-400 font-black text-sm uppercase tracking-widest">Secret Area Activated</p>
              <p className="text-slate-500 dark:text-slate-400 text-xs">These tools are hidden from the main page.</p>
            </div>
          </div>
          <button 
            onClick={() => setShowManageTools(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-800 transition-all shadow-sm"
          >
            <Settings className="w-4 h-4" />
            Manage Tools
          </button>
        </div>
      )}
      {searchQuery ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTools.map((tool) => (
            <button
              key={tool.id}
              onClick={() => tool.externalUrl ? window.open(tool.externalUrl, '_blank') : onViewSelect(tool.id as View)}
              className={`text-left p-6 bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 transition-all hover:shadow-md hover:-translate-y-1 ${tool.hoverBorder} dark:hover:border-slate-700 group relative`}
            >
              {tool.externalUrl && (
                <div className="absolute top-4 right-4 text-slate-300 dark:text-slate-600 group-hover:text-slate-400 transition-colors">
                  <ExternalLink className="w-4 h-4" />
                </div>
              )}
              <div className={`w-12 h-12 ${tool.bgColor} dark:bg-slate-800 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <tool.icon className={`w-6 h-6 ${tool.color}`} />
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{tool.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{tool.description}</p>
            </button>
          ))}
          {filteredTools.length === 0 && (
            <div className="col-span-full text-center py-12 text-slate-400">
              <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>No tools found matching "{searchQuery}"</p>
            </div>
          )}
        </div>
      ) : (
        categories.length === 0 ? (
          <div className="text-center py-20 text-slate-400">
            <Lock className="w-16 h-16 mx-auto mb-4 opacity-10" />
            <p className="text-lg font-medium">No tools in this area</p>
            <p className="text-sm">Click "Manage Tools" to add some.</p>
          </div>
        ) : (
          categories.map(category => {
            const categoryTools = displayTools.filter(t => t.category === category);
            return (
              <section key={category} className="space-y-6">
                <div className="flex items-center gap-4">
                  <h2 className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">{category}</h2>
                  <div className="h-px bg-slate-200 dark:bg-slate-800 flex-1" />
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {categoryTools.map((tool) => (
                    <button
                      key={tool.id}
                      onClick={() => tool.externalUrl ? window.open(tool.externalUrl, '_blank') : onViewSelect(tool.id as View)}
                      className={`text-left p-6 bg-slate-100/80 dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 transition-all hover:shadow-md hover:-translate-y-1 ${tool.hoverBorder} dark:hover:border-slate-700 group relative`}
                    >
                      {tool.externalUrl && (
                        <div className="absolute top-4 right-4 text-slate-300 dark:text-slate-600 group-hover:text-slate-400 transition-colors">
                          <ExternalLink className="w-4 h-4" />
                        </div>
                      )}
                      <div className={`w-12 h-12 ${tool.bgColor} dark:bg-slate-800 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <tool.icon className={`w-6 h-6 ${tool.color}`} />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{tool.title}</h3>
                      <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed">{tool.description}</p>
                    </button>
                  ))}
                </div>
              </section>
            );
          })
        )
      )}
    </div>
  );
}

