import { GenerateContentResponse } from "@google/genai";

/**
 * Cleans the response text from Gemini to extract valid JSON.
 * Sometimes models wrap JSON in markdown code blocks even when requested not to.
 */
export function cleanAIJsonResponse(response: GenerateContentResponse): any {
  const text = response.text;
  if (!text) return {};

  let cleanJson = text.trim();
  
  // Remove markdown code blocks if present
  if (cleanJson.startsWith('```')) {
    cleanJson = cleanJson.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim();
  }

  try {
    return JSON.parse(cleanJson);
  } catch (e) {
    console.error("Failed to parse AI JSON response:", cleanJson);
    throw new Error("The AI returned an invalid response format. Please try again.");
  }
}

/**
 * Gets the API key from environment variables or localStorage with fallbacks.
 */
export function getGeminiApiKey(): string {
  // 1. Check localStorage (User provided key via Modal)
  const localKey = typeof window !== 'undefined' ? localStorage.getItem('USER_GEMINI_API_KEY') : null;
  if (localKey && localKey !== 'undefined' && localKey !== 'null' && localKey !== '') {
    return localKey;
  }

  // 2. Check process.env (injected by Vite define)
  const key = process.env.GEMINI_API_KEY;
  
  // 3. Check import.meta.env (standard Vite way)
  const viteKey = (import.meta as any).env?.VITE_GEMINI_API_KEY;

  const finalKey = (key && key !== 'undefined' && key !== 'null' && key !== '') 
    ? key 
    : viteKey;

  if (!finalKey || finalKey === 'undefined' || finalKey === 'null' || finalKey === '') {
    throw new Error("Gemini API Key is missing. Please enter your key in the settings (bottom right) or set it in Netlify.");
  }
  return finalKey;
}

/**
 * Handles Gemini API errors and returns a user-friendly message.
 */
export function handleGeminiError(error: any): string {
  console.error("Gemini API Error:", error);
  
  const message = error.message || error.toString() || "";
  
  if (message.includes("429") || message.includes("quota") || message.includes("RESOURCE_EXHAUSTED")) {
    return "AI Rate Limit Reached. Please wait a few seconds or switch to a different API key in the Key Manager (bottom right).";
  }
  
  if (message.includes("503") || message.includes("UNAVAILABLE")) {
    return "AI is currently overloaded. Please try again in a few seconds.";
  }

  if (message.includes("API Key is missing")) {
    return "Gemini API Key is missing. Please enter your key in the settings (bottom right).";
  }

  if (message.includes("Safety") || message.includes("HARM_CATEGORY")) {
    return "The AI blocked this request due to safety filters. Please try a different prompt or image.";
  }

  if (message.includes("invalid") || message.includes("key") || message.includes("401") || message.includes("403")) {
    return "Invalid API Key. Please check your key in settings (bottom right). Make sure you copied the full key without extra spaces.";
  }

  if (message.includes("not found") || message.includes("404")) {
    return `Model Error: The AI model is not available for your API key. Try a different key or wait for access.`;
  }

  return `AI Error: ${message.slice(0, 150)}${message.length > 150 ? '...' : ''}. Please try again.`;
}

/**
 * Helper to retry an AI operation if it hits a rate limit (429).
 */
export async function withRetry<T>(operation: () => Promise<T>, maxRetries = 2): Promise<T> {
  let lastError: any;
  for (let i = 0; i <= maxRetries; i++) {
    try {
      return await operation();
    } catch (error: any) {
      lastError = error;
      const message = error.message || "";
      const isRateLimit = message.includes("429") || message.includes("quota") || message.includes("RESOURCE_EXHAUSTED");
      
      if (isRateLimit && i < maxRetries) {
        // Wait 2 seconds before retrying
        console.log(`Rate limit hit. Retrying in 2s... (Attempt ${i + 1}/${maxRetries})`);
        await new Promise(resolve => setTimeout(resolve, 2000));
        continue;
      }
      throw error;
    }
  }
  throw lastError;
}
