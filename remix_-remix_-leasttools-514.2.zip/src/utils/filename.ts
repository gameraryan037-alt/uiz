/**
 * Utility to generate filenames for downloads.
 * If the user provides a filename, it uses that.
 * If the user leaves it empty, it generates a default one starting with 'leasttv'.
 */

export function getDownloadFilename(
  input: string,
  toolName: string,
  extension: string
): string {
  const cleanInput = input.trim();
  
  if (!cleanInput) {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0].replace(/-/g, '');
    const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    
    // Format: leasttv-toolname-YYYYMMDD-HHMMSS-RRR.ext
    return `leasttv-${toolName}-${dateStr}-${timeStr}-${random}.${extension}`;
  }

  // If user provided a filename, ensure it has the correct extension
  const extWithDot = extension.startsWith('.') ? extension : `.${extension}`;
  if (cleanInput.toLowerCase().endsWith(extWithDot.toLowerCase())) {
    return cleanInput;
  }
  
  return `${cleanInput}${extWithDot}`;
}
