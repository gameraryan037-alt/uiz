import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { getFirebaseAuth, getFirestoreDb, isFirebaseConfigured } from '../lib/firebase';
import { doc, setDoc, getDoc, deleteDoc } from 'firebase/firestore';

interface CollageDB extends DBSchema {
  images: {
    key: string;
    value: {
      id: string;
      file: File;
      isExpanded?: boolean;
      order?: number;
    };
  };
  toolStates: {
    key: string;
    value: {
      id: string;
      state: any;
      updatedAt: number;
    };
  };
}

const DB_NAME = 'text-utils-db';
const COLLAGE_STORE = 'images';
const STATE_STORE = 'toolStates';

let dbPromise: Promise<IDBPDatabase<CollageDB>> | null = null;

const getDB = () => {
  if (!dbPromise) {
    dbPromise = openDB<CollageDB>(DB_NAME, 2, {
      upgrade(db, oldVersion) {
        if (!db.objectStoreNames.contains(COLLAGE_STORE)) {
          db.createObjectStore(COLLAGE_STORE, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STATE_STORE)) {
          db.createObjectStore(STATE_STORE, { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
};

// Collage Specific
export const saveImagesToDB = async (images: { id: string; file: File; isExpanded?: boolean }[]) => {
  const db = await getDB();
  const tx = db.transaction(COLLAGE_STORE, 'readwrite');
  const store = tx.objectStore(COLLAGE_STORE);
  await store.clear();
  for (let i = 0; i < images.length; i++) {
    await store.add({ ...images[i], order: i });
  }
  await tx.done;
};

export const loadImagesFromDB = async () => {
  const db = await getDB();
  const images = await db.getAll(COLLAGE_STORE);
  return images.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
};

export const clearImagesFromDB = async () => {
  const db = await getDB();
  await db.clear(COLLAGE_STORE);
};

// Generic Tool State
export const saveToolState = async (toolId: string, state: any) => {
  const db = await getDB();
  const updatedAt = Date.now();
  
  // Save to IndexedDB
  await db.put(STATE_STORE, {
    id: toolId,
    state,
    updatedAt
  });

  // Sync to Firestore if logged in and configured
  if (isFirebaseConfigured()) {
    try {
      const auth = getFirebaseAuth();
      const firestore = getFirestoreDb();
      const user = auth.currentUser;
      if (user) {
        const userDocRef = doc(firestore, `users/${user.uid}/toolStates`, toolId);
        await setDoc(userDocRef, {
          state,
          updatedAt
        });
      }
    } catch (error) {
      console.error("Firestore sync failed:", error);
    }
  }
};

export const loadToolState = async (toolId: string) => {
  const db = await getDB();
  
  // Try to get from IndexedDB first
  const localResult = await db.get(STATE_STORE, toolId);
  
  // If logged in and configured, try to get from Firestore and sync if newer
  if (isFirebaseConfigured()) {
    try {
      const auth = getFirebaseAuth();
      const firestore = getFirestoreDb();
      const user = auth.currentUser;
      if (user) {
        const userDocRef = doc(firestore, `users/${user.uid}/toolStates`, toolId);
        const docSnap = await getDoc(userDocRef);
        
        if (docSnap.exists()) {
          const remoteData = docSnap.data();
          if (!localResult || remoteData.updatedAt > localResult.updatedAt) {
            // Update local DB with remote data
            await db.put(STATE_STORE, {
              id: toolId,
              state: remoteData.state,
              updatedAt: remoteData.updatedAt
            });
            return remoteData.state;
          }
        }
      }
    } catch (error) {
      console.error("Firestore load failed:", error);
    }
  }
  
  return localResult?.state || null;
};

export const clearToolState = async (toolId: string) => {
  const db = await getDB();
  await db.delete(STATE_STORE, toolId);

  if (isFirebaseConfigured()) {
    try {
      const auth = getFirebaseAuth();
      const firestore = getFirestoreDb();
      const user = auth.currentUser;
      if (user) {
        const userDocRef = doc(firestore, `users/${user.uid}/toolStates`, toolId);
        await deleteDoc(userDocRef);
      }
    } catch (error) {
      console.error("Firestore delete failed:", error);
    }
  }
};
