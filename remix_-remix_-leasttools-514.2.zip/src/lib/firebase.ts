import { initializeApp, FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, Auth } from "firebase/auth";
import { getFirestore, Firestore } from "firebase/firestore";

let app: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;
let googleProviderInstance: GoogleAuthProvider | null = null;

function getFirebaseConfig() {
  return {
    apiKey: (import.meta as any).env.VITE_FIREBASE_API_KEY,
    authDomain: (import.meta as any).env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: (import.meta as any).env.VITE_FIREBASE_PROJECT_ID,
    storageBucket: (import.meta as any).env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: (import.meta as any).env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: (import.meta as any).env.VITE_FIREBASE_APP_ID,
  };
}

export function isFirebaseConfigured() {
  const config = getFirebaseConfig();
  return !!config.apiKey && config.apiKey !== '';
}

function initFirebase() {
  if (!app) {
    const config = getFirebaseConfig();
    if (!config.apiKey) {
      throw new Error("Firebase API Key is missing. Please set VITE_FIREBASE_API_KEY in your environment variables.");
    }
    app = initializeApp(config);
  }
  return app;
}

export const getFirebaseAuth = (): Auth => {
  if (!authInstance) {
    authInstance = getAuth(initFirebase());
  }
  return authInstance;
};

export const getFirestoreDb = (): Firestore => {
  if (!dbInstance) {
    dbInstance = getFirestore(initFirebase());
  }
  return dbInstance;
};

export const getGoogleProvider = (): GoogleAuthProvider => {
  if (!googleProviderInstance) {
    googleProviderInstance = new GoogleAuthProvider();
  }
  return googleProviderInstance;
};
