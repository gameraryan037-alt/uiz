
export interface CountryData {
  name: string;
  code: string;
  currency: string;
  symbol: string;
  taxRate: number;
  rateToUSD: number;
}

export const ALL_COUNTRIES: CountryData[] = [
  {
    "name": "Afghanistan",
    "code": "AF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Åland Islands",
    "code": "AX",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Albania",
    "code": "AL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Algeria",
    "code": "DZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "American Samoa",
    "code": "AS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Andorra",
    "code": "AD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Angola",
    "code": "AO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Anguilla",
    "code": "AI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Antarctica",
    "code": "AQ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Antigua and Barbuda",
    "code": "AG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Argentina",
    "code": "AR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Armenia",
    "code": "AM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Aruba",
    "code": "AW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Australia",
    "code": "AU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Austria",
    "code": "AT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Azerbaijan",
    "code": "AZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bahamas",
    "code": "BS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bahrain",
    "code": "BH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bangladesh",
    "code": "BD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Barbados",
    "code": "BB",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Belarus",
    "code": "BY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Belgium",
    "code": "BE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Belize",
    "code": "BZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Benin",
    "code": "BJ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bermuda",
    "code": "BM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bhutan",
    "code": "BT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bolivia",
    "code": "BO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bosnia and Herzegovina",
    "code": "BA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Botswana",
    "code": "BW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bouvet Island",
    "code": "BV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Brazil",
    "code": "BR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "British Indian Ocean Territory",
    "code": "IO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "British Virgin Islands",
    "code": "VG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Brunei",
    "code": "BN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Bulgaria",
    "code": "BG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Burkina Faso",
    "code": "BF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Burundi",
    "code": "BI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cambodia",
    "code": "KH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cameroon",
    "code": "CM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Canada",
    "code": "CA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cape Verde",
    "code": "CV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Caribbean Netherlands",
    "code": "BQ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cayman Islands",
    "code": "KY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Central African Republic",
    "code": "CF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Chad",
    "code": "TD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Chile",
    "code": "CL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "China",
    "code": "CN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Christmas Island",
    "code": "CX",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cocos (Keeling) Islands",
    "code": "CC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Colombia",
    "code": "CO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Comoros",
    "code": "KM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Congo",
    "code": "CG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cook Islands",
    "code": "CK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Costa Rica",
    "code": "CR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Croatia",
    "code": "HR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cuba",
    "code": "CU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Curaçao",
    "code": "CW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Cyprus",
    "code": "CY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Czechia",
    "code": "CZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Denmark",
    "code": "DK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Djibouti",
    "code": "DJ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Dominica",
    "code": "DM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Dominican Republic",
    "code": "DO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Dubai (UAE)",
    "code": "DXB",
    "currency": "AED",
    "symbol": "د.إ",
    "taxRate": 5,
    "rateToUSD": 3.67
  },
  {
    "name": "DR Congo",
    "code": "CD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ecuador",
    "code": "EC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Egypt",
    "code": "EG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "El Salvador",
    "code": "SV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Equatorial Guinea",
    "code": "GQ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Eritrea",
    "code": "ER",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Estonia",
    "code": "EE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Eswatini",
    "code": "SZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ethiopia",
    "code": "ET",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Falkland Islands",
    "code": "FK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Faroe Islands",
    "code": "FO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Fiji",
    "code": "FJ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Finland",
    "code": "FI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "France",
    "code": "FR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "French Guiana",
    "code": "GF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "French Polynesia",
    "code": "PF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "French Southern and Antarctic Lands",
    "code": "TF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Gabon",
    "code": "GA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Gambia",
    "code": "GM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Georgia",
    "code": "GE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Germany",
    "code": "DE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ghana",
    "code": "GH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Gibraltar",
    "code": "GI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Greece",
    "code": "GR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Greenland",
    "code": "GL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Grenada",
    "code": "GD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guadeloupe",
    "code": "GP",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guam",
    "code": "GU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guatemala",
    "code": "GT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guernsey",
    "code": "GG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guinea",
    "code": "GN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guinea-Bissau",
    "code": "GW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Guyana",
    "code": "GY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Haiti",
    "code": "HT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Heard Island and McDonald Islands",
    "code": "HM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Honduras",
    "code": "HN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Hong Kong",
    "code": "HK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Hungary",
    "code": "HU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Iceland",
    "code": "IS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "India",
    "code": "IN",
    "currency": "INR",
    "symbol": "₹",
    "taxRate": 18,
    "rateToUSD": 83.3
  },
  {
    "name": "Indonesia",
    "code": "ID",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Iran",
    "code": "IR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Iraq",
    "code": "IQ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ireland",
    "code": "IE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Isle of Man",
    "code": "IM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Israel",
    "code": "IL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Italy",
    "code": "IT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ivory Coast",
    "code": "CI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Jamaica",
    "code": "JM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Japan",
    "code": "JP",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Jersey",
    "code": "JE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Jordan",
    "code": "JO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kazakhstan",
    "code": "KZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kenya",
    "code": "KE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kiribati",
    "code": "KI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kosovo",
    "code": "XK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kuwait",
    "code": "KW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Kyrgyzstan",
    "code": "KG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Laos",
    "code": "LA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Latvia",
    "code": "LV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Lebanon",
    "code": "LB",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Lesotho",
    "code": "LS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Liberia",
    "code": "LR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Libya",
    "code": "LY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Liechtenstein",
    "code": "LI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Lithuania",
    "code": "LT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Luxembourg",
    "code": "LU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Macau",
    "code": "MO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Madagascar",
    "code": "MG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Malawi",
    "code": "MW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Malaysia",
    "code": "MY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Maldives",
    "code": "MV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mali",
    "code": "ML",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Malta",
    "code": "MT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Marshall Islands",
    "code": "MH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Martinique",
    "code": "MQ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mauritania",
    "code": "MR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mauritius",
    "code": "MU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mayotte",
    "code": "YT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mexico",
    "code": "MX",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Micronesia",
    "code": "FM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Moldova",
    "code": "MD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Monaco",
    "code": "MC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mongolia",
    "code": "MN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Montenegro",
    "code": "ME",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Montserrat",
    "code": "MS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Morocco",
    "code": "MA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Mozambique",
    "code": "MZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Myanmar",
    "code": "MM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Namibia",
    "code": "NA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Nauru",
    "code": "NR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Nepal",
    "code": "NP",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Netherlands",
    "code": "NL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "New Caledonia",
    "code": "NC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "New Zealand",
    "code": "NZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Nicaragua",
    "code": "NI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Niger",
    "code": "NE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Nigeria",
    "code": "NG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Niue",
    "code": "NU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Norfolk Island",
    "code": "NF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "North Korea",
    "code": "KP",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "North Macedonia",
    "code": "MK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Northern Mariana Islands",
    "code": "MP",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Norway",
    "code": "NO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Oman",
    "code": "OM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Pakistan",
    "code": "PK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Palau",
    "code": "PW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Palestine",
    "code": "PS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Panama",
    "code": "PA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Papua New Guinea",
    "code": "PG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Paraguay",
    "code": "PY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Peru",
    "code": "PE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Philippines",
    "code": "PH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Pitcairn Islands",
    "code": "PN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Poland",
    "code": "PL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Portugal",
    "code": "PT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Puerto Rico",
    "code": "PR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Qatar",
    "code": "QA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Réunion",
    "code": "RE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Romania",
    "code": "RO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Russia",
    "code": "RU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Rwanda",
    "code": "RW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Barthélemy",
    "code": "BL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Helena, Ascension and Tristan da Cunha",
    "code": "SH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Kitts and Nevis",
    "code": "KN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Lucia",
    "code": "LC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Martin",
    "code": "MF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Pierre and Miquelon",
    "code": "PM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saint Vincent and the Grenadines",
    "code": "VC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Samoa",
    "code": "WS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "San Marino",
    "code": "SM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "São Tomé and Príncipe",
    "code": "ST",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Saudi Arabia",
    "code": "SA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Senegal",
    "code": "SN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Serbia",
    "code": "RS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Seychelles",
    "code": "SC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Sierra Leone",
    "code": "SL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Singapore",
    "code": "SG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Sint Maarten",
    "code": "SX",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Slovakia",
    "code": "SK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Slovenia",
    "code": "SI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Solomon Islands",
    "code": "SB",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Somalia",
    "code": "SO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "South Africa",
    "code": "ZA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "South Georgia",
    "code": "GS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "South Korea",
    "code": "KR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "South Sudan",
    "code": "SS",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Spain",
    "code": "ES",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Sri Lanka",
    "code": "LK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Sudan",
    "code": "SD",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Suriname",
    "code": "SR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Svalbard and Jan Mayen",
    "code": "SJ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Sweden",
    "code": "SE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Switzerland",
    "code": "CH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Syria",
    "code": "SY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Taiwan",
    "code": "TW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tajikistan",
    "code": "TJ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tanzania",
    "code": "TZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Thailand",
    "code": "TH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Timor-Leste",
    "code": "TL",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Togo",
    "code": "TG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tokelau",
    "code": "TK",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tonga",
    "code": "TO",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Trinidad and Tobago",
    "code": "TT",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tunisia",
    "code": "TN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Türkiye",
    "code": "TR",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Turkmenistan",
    "code": "TM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Turks and Caicos Islands",
    "code": "TC",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Tuvalu",
    "code": "TV",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Uganda",
    "code": "UG",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Ukraine",
    "code": "UA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "United Arab Emirates",
    "code": "AE",
    "currency": "AED",
    "symbol": "د.إ",
    "taxRate": 5,
    "rateToUSD": 3.67
  },
  {
    "name": "United Kingdom",
    "code": "GB",
    "currency": "GBP",
    "symbol": "£",
    "taxRate": 20,
    "rateToUSD": 0.79
  },
  {
    "name": "United States",
    "code": "US",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "United States Minor Outlying Islands",
    "code": "UM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "United States Virgin Islands",
    "code": "VI",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Uruguay",
    "code": "UY",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Uzbekistan",
    "code": "UZ",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Vanuatu",
    "code": "VU",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Vatican City",
    "code": "VA",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Venezuela",
    "code": "VE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Vietnam",
    "code": "VN",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Wallis and Futuna",
    "code": "WF",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Western Sahara",
    "code": "EH",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Yemen",
    "code": "YE",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Zambia",
    "code": "ZM",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  },
  {
    "name": "Zimbabwe",
    "code": "ZW",
    "currency": "USD",
    "symbol": "$",
    "taxRate": 15,
    "rateToUSD": 1
  }
];
